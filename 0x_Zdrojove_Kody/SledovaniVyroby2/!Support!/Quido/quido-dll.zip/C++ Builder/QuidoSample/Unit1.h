//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "q_QuidoDllMap.h"
#include <CheckLst.hpp>
#include <ExtCtrls.hpp> //Hlavi�kov� soubor funkc� Quida
//---------------------------------------------------------------------------
const WM_QuidoEvent = WM_USER + 3;
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TGroupBox *GroupBox1;
        TEdit *ConnectionString;
        TButton *cmdDlg;
        TButton *cmdCreate;
        TEdit *txtParams;
        TLabel *Label1;
        TButton *cmdOpen;
        TButton *cmdClose;
        TGroupBox *gbQuido;
        TGroupBox *GroupBox2;
        TLabel *Label2;
        TGroupBox *GroupBox3;
        TComboBox *ComboBoxOut;
        TGroupBox *GroupBox4;
        TComboBox *ComboBoxIn;
        TCheckBox *chOut;
        TShape *InIndik;
        TGroupBox *GroupBox5;
        TLabel *lblCounter;
        TLabel *lblCounterValue;
        TCheckBox *chAutoNotify;
        TButton *cmdReset;
        TButton *cmdSPInfo;
        void __fastcall cmdCreateClick(TObject *Sender);
        void __fastcall cmdDlgClick(TObject *Sender);
        void __fastcall cmdOpenClick(TObject *Sender);
        void __fastcall cmdCloseClick(TObject *Sender);
        void __fastcall FormDestroy(TObject *Sender);
        void __fastcall ComboBoxOutChange(TObject *Sender);
        void __fastcall chOutClick(TObject *Sender);
        void __fastcall ComboBoxInChange(TObject *Sender);
        void __fastcall chAutoNotifyClick(TObject *Sender);
        void __fastcall cmdResetClick(TObject *Sender);
        void __fastcall cmdSPInfoClick(TObject *Sender);
private:
        QHandle QuidoHandle; //Handle vytbo�en�ho Quida
protected:
      void __fastcall WMQuidoEvent(TMessage & Msg); //Pro p��jem ud�lost� z Quida
      BEGIN_MESSAGE_MAP
          //Namapov�n� ud�lost� z Quida
          MESSAGE_HANDLER(WM_QuidoEvent,TMessage,WMQuidoEvent)
      END_MESSAGE_MAP(TComponent)
public:
        __fastcall TForm1(TComponent* Owner);
        void __fastcall OnQuidoOpen(); //Metoda pro p��jem ud�losti Otev�en� komunika�n�ho rozhran�
        void __fastcall OnQuidoClose(); //Metoda pro p��jem ud�losti Zav�en� komunika�n�ho rozhran�
        void __fastcall OnInputChange(int Index);//Metoda pro p��jem ud�losti Zm�na vstupu Quida
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
 