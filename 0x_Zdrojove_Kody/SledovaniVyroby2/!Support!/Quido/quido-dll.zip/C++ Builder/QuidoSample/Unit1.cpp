//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "q_QuidoDllMap.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
   QuidoHandle = 0;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::cmdCreateClick(TObject *Sender)
{
  //Vytvo�it Quido

  if (!QDllOK()) throw Exception(QDllInitMsg()); //Zji�t�n� zda byla spr�vn� namapov�na knihovna (p�i prvn�m vol�n� funcke QDllOK se knihovna namapuje)

  if (QuidoHandle){ //Pokud je vytvo�en� jin� Quido ...
    qReleaseQuido(QuidoHandle); //... zru�� se ...
    QuidoHandle = 0; //... vynuluje se handle ...
    OnQuidoClose(); //... shov� se z formul��e ovl�d�n� quida
  }
  QuidoHandle = qCreateQuido(ConnectionString->Text.c_str(),txtParams->Text.c_str());
  //-- Vytvo�� se Quido podle p�ipojovac�ho �et�zce, kter� definuje komunika�n� rozhran�. d�le se p�ed� adresa Quida v parametrech quida

  if (QuidoHandle){
     //-- pokud bylo quido vytvo�eno, zaregistruje se zas�l�n� ud�lost� pomoc� Windows zpr�v
     qRegisterMsgNotifications(QuidoHandle,(unsigned int)this->Handle,WM_QuidoEvent,0);
  } else ShowMessage("Quido nebylo vytvo�eno"); //pokud Quido nelze podle p�ipojovac�ho �et�zce vytvo�it
}

void __fastcall TForm1::WMQuidoEvent(TMessage & Msg){ //Zasl�n� ud�losti Quidem
  switch(Msg.LParamLo){
    case qev_CIOpen: //P�i otev�en� komunika�n�ho rozhran�
          OnQuidoOpen();
          break;
    case qev_CIClose: //P�i zav�en� komunika�n�ho rozhran�
          OnQuidoClose();
          break;
    case qev_InputChange: //P�i zji�t�n� zm�n� vstupu
          OnInputChange(Msg.LParamHi & 0xFF);
          break;
  }
}

//---------------------------------------------------------------------------

void __fastcall TForm1::cmdDlgClick(TObject *Sender)
{
  //Nastaven� p�ipojovac�ho �et�zce vestav�n�m dialogem

  if (!QDllOK()) throw Exception(QDllInitMsg()); //Zji�t�n� zda byla spr�vn� na�tena knihovna
  char ConnStr[513]="";
  int Len = 512;
  int Ret=0;
  //Vyvol�n� dialogu pro vytvo�en� p�ipojovac�ho �et�zce
  if ((ciGetConnectionStringDlg(ConnStr,Len,Ret,ConnectionString->Text.c_str(),NULL)==0) && Ret){
     //Pokud bylo stisknuto OK, op�e se �et�zec do textov�ho pole
     ConnStr[Len]=0;
     ConnectionString->Text = ConnStr;
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::cmdOpenClick(TObject *Sender)
{
  if (!QuidoHandle){
    ShowMessage("Quido nen� vytvo�eno");
    return;
  }
  qOpen(QuidoHandle); //Otev�e se komunika�n� rozhran�
}
//---------------------------------------------------------------------------
void __fastcall TForm1::OnQuidoOpen(){ //P�i ud�losti otev�en� rozhran�
  char Buf[128];
  int Ln;
  int Cnt;
  Ln=128;
  if (qInfo(QuidoHandle,Buf,Ln)==0){ //Na�ten� identifika�n�ho �et�zce
    Buf[Ln]=0;
    Label2->Caption = Buf;
  }else throw Exception("Nebylo na�teno info z Quida.");

  if (qGetAutoNotify(QuidoHandle,Cnt)==0){ //Zjist� stav automatick�ho vys�l�n�
     chAutoNotify->Checked = Cnt;
  }else chAutoNotify->State = cbGrayed;
  ComboBoxOut->Clear();
  //Zji�t�n� po�tu v�stup� a vyps�n� do ComboBoxu
  if ((Cnt=qOutputsCount(QuidoHandle))<0) throw Exception("Nebyl zji�t�n po�et v�stup�");
  for (int i=0;i<Cnt;i++){
    ComboBoxOut->Items->Add("V�stup "+IntToStr(i+1));
  }
  if (Cnt>0){
   //Nastaven� prvn�ho v�stupu
   ComboBoxOut->ItemIndex = 0;
   ComboBoxOutChange(ComboBoxOut);
  }

  ComboBoxIn->Clear();
  //Zji�t�n� po�tu vstup� a vyps�n� do ComboBoxu
  if ((Cnt=qInputsCount(QuidoHandle))<0) throw Exception("Nebyl zji�t�n po�et vstup�");
  for (int i=0;i<Cnt;i++){
    ComboBoxIn->Items->Add("Vstup "+IntToStr(i+1));
  }
  if (Cnt>0){
   //Nastaven� prvn�ho vstupu
   ComboBoxIn->ItemIndex = 0;
   ComboBoxInChange(ComboBoxIn);
  }

  //Zobrazen� ovl�d�n� Quida
  gbQuido->Visible = true;
}

void __fastcall TForm1::OnQuidoClose(){ //P�i ud�losti zav�en� rozhran�
  //Schov�n� ovl�d�n� Quida
  gbQuido->Visible = false;
}

void __fastcall TForm1::OnInputChange(int Index){ //P�i ud�losti zm�ny vstupu
  if (Index==ComboBoxIn->ItemIndex){ //Pokud je zm�n�n� vstup vybran� (zobrazen�)
      int OS,R,F;
      //Zjist� se naposledy zn�m� stav vstupu (po t�to ud�losti by m�l b�t aktu�ln�, nen� t�eba znovu komunikovat s Quidem)
      if (qGetRecentInputByIndex(QuidoHandle,ComboBoxIn->ItemIndex,OS)==0){
         InIndik->Brush->Color = OS?clRed:clGray;
         //Zji�t�n� stavu ��ta�e
         if (qInputCounterValueByIndex(QuidoHandle,Index,OS,0)==0)
            lblCounterValue->Caption = IntToStr(OS);
            else lblCounterValue->Caption = "";
         //Zji�t�n� nastaven� ��ta�e
         if (qGetCounterSetting(QuidoHandle,Index,R,F)==0){
            if (R && F) lblCounter->Caption = "��ta�: Ob� hrany";
            else if (R) lblCounter->Caption = "��ta�: N�b�n� hrana";
            else if (F) lblCounter->Caption = "��ta�: Sestupn� hrana";
            else lblCounter->Caption = "��ta� vypnut";
         }else lblCounter->Caption = "��ta� nen�";
      }
  }
}
//-----------------


void __fastcall TForm1::cmdCloseClick(TObject *Sender)
{
  if (!QuidoHandle){
    ShowMessage("Quido nen� vytvo�eno");
    return;
  }
  qClose(QuidoHandle); //Zav�en� komunika�n�ho rozhran� s Quidem

}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormDestroy(TObject *Sender)
{
  //P�i ukon�en� zru�it Quido
  if (QuidoHandle) qReleaseQuido(QuidoHandle);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ComboBoxOutChange(TObject *Sender)
{
  //P�i zm�n� v�b�ru v�stupu
  if (QuidoHandle)
    if (ComboBoxOut->ItemIndex>=0){
      chOut->Caption = "V�stup " + IntToStr(ComboBoxOut->ItemIndex+1);
      int OS;
      //Zjistit stav vybran�ho v�stupu
      if (qOutputStateByIndex(QuidoHandle,ComboBoxOut->ItemIndex,OS)!=0) throw Exception("Nelze zjistit stav v�stupu.");
      //Zobrazit
      chOut->Checked = OS;
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::chOutClick(TObject *Sender)
{
  //Zm�nit stav vybran�ho v�stupu

  if (QuidoHandle) // (je vytvo�eno Quido?)
    if (ComboBoxOut->ItemIndex>=0){ //(je vybr�n v�stup?)
      int OS=(int)chOut->Checked; //Zjistit stav za�krt�v�tka
      if (qSetOutput(QuidoHandle,ComboBoxOut->ItemIndex,OS)!=0) throw Exception("V�stup nebyl nastaven.");
      //Nastavit v�stup Quida
    }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::ComboBoxInChange(TObject *Sender)
{
  //P�i zm�n� v�b�ru vstupu
  if (QuidoHandle)
    if (ComboBoxIn->ItemIndex>=0){ //Vybran� vstup
      int OS,R,F;
      //Zjistit stav vybran�ho vstupu
      if (qInputStateByIndex(QuidoHandle,ComboBoxIn->ItemIndex,OS)!=0) throw Exception("Nelze zjistit stav v�stupu.");
      //Zm�nit barvu indik�toru (�erven�=vstup aktivn�, �ed�= vstup neaktivn�)
      InIndik->Brush->Color = OS?clRed:clGray;
      //Zji�t�n� stavu ��ta�e
      if (qInputCounterValueByIndex(QuidoHandle,ComboBoxIn->ItemIndex,OS,0)==0)
         lblCounterValue->Caption = IntToStr(OS);
         else lblCounterValue->Caption = "";
      //Zji�t�n� nastaven� ��ta�e
      if (qGetCounterSetting(QuidoHandle,ComboBoxIn->ItemIndex,R,F)==0){
         if (R && F) lblCounter->Caption = "��ta�: Ob� hrany";
         else if (R) lblCounter->Caption = "��ta�: N�b�n� hrana";
         else if (F) lblCounter->Caption = "��ta�: Sestupn� hrana";
         else lblCounter->Caption = "��ta� vypnut";
      }else lblCounter->Caption = "��ta� nen�";
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::chAutoNotifyClick(TObject *Sender)
{
  if (chAutoNotify->State != cbGrayed){
    int Ch = chAutoNotify->Checked?1:0;
    //Nastaven� automatick�ho vys�l�n�
    if (qSetAutoNotify(QuidoHandle,Ch)!=0) ShowMessage("Automatick� vys�l�n� nebylo nastaveno.");
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::cmdResetClick(TObject *Sender)
{
  //Restartov�n� Quida
  if (qReset(QuidoHandle)!=0) ShowMessage("Nezda�ilo se resetovat");
}
//---------------------------------------------------------------------------

void __fastcall TForm1::cmdSPInfoClick(TObject *Sender)
{
  //Uk�zka pou��t� funkce qSndRcvSpin97
  //Tuto funkci je vhodn� pou��vat v p��padech, kdy je t�eba prov�st p��kaz, kter� nem� implementovanou speci�ln� funkci
  //p��klad po�le spinel instrukci 0xF3 pro zj�sk�n� identifika�n�ho �et�zce Quida (to je implementov�no funkc� qInfo)
  char Info[128];
  int Len=128;
  unsigned char Ack;
  int Ret = qSndRcvSpin97(QuidoHandle,0xF3,NULL,0,Ack,Info,Len,1000);
  //funkci se p�ed� handle Quida, instrukce (0xF3), data a jejich d�ka (v t�to instrukci se data nep�ed�vaj�, jsou tedy NULL a d�lka 0), Ack pro z�sk�n� n�vratov�ho k�du (0=OK),
  //buffer Info pro p��jem vr�cen�ch dat o velikosti Len (pokud se neo�ek�vaj� vr�cen� data, m��e b�t NULL a velikost 0). Len se zm�n� na aktu�ln� velikost vr�cen�ch dat.

  if (Ret==0){ //pokud byla instrukce provedena (a potvrzena)
     if (Ack==0){ //pokud je n�vratov� k�d Ack = 0 (OK)
        Info[Len]=0; //P�id� se za p�ijat� data 0 (p�ijat� data jsou v t�to instrukci �et�zec, je t�eba ho ukon�it)
        ShowMessage(Info); //Zobraz� se p�ijat� �et�zec
     }else ShowMessage("Instrukce nebyla �sp�n� vykon�na");
  }else ShowMessage("Bez odezvy");
}
//---------------------------------------------------------------------------

