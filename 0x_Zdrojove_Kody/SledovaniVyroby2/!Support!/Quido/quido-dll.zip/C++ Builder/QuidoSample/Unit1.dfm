object Form1: TForm1
  Left = 192
  Top = 107
  BorderIcons = [biSystemMenu, biMinimize]
  BorderStyle = bsSingle
  Caption = 'Quido Dll sample'
  ClientHeight = 445
  ClientWidth = 355
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 13
  object GroupBox1: TGroupBox
    Left = 8
    Top = 8
    Width = 337
    Height = 137
    Caption = 'P'#345'ipojovac'#237' '#345'et'#283'zec'
    TabOrder = 0
    object Label1: TLabel
      Left = 8
      Top = 48
      Width = 78
      Height = 13
      Caption = 'Parametry Quida'
    end
    object ConnectionString: TEdit
      Left = 8
      Top = 24
      Width = 273
      Height = 21
      TabOrder = 0
      Text = 'provider=TCP_CLIENT;host=192.168.1.254;port=10001'
    end
    object cmdDlg: TButton
      Left = 288
      Top = 25
      Width = 41
      Height = 21
      Caption = '...'
      TabOrder = 1
      OnClick = cmdDlgClick
    end
    object cmdCreate: TButton
      Left = 8
      Top = 96
      Width = 121
      Height = 25
      Caption = 'Vytvo'#345'it Quido'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = [fsBold]
      ParentFont = False
      TabOrder = 2
      OnClick = cmdCreateClick
    end
    object txtParams: TEdit
      Left = 8
      Top = 64
      Width = 121
      Height = 21
      TabOrder = 3
      Text = 'addr=$FE'
    end
    object cmdOpen: TButton
      Left = 152
      Top = 96
      Width = 75
      Height = 25
      Caption = 'Otev'#345#237't'
      TabOrder = 4
      OnClick = cmdOpenClick
    end
    object cmdClose: TButton
      Left = 232
      Top = 96
      Width = 75
      Height = 25
      Caption = 'Zav'#345#237't'
      TabOrder = 5
      OnClick = cmdCloseClick
    end
  end
  object gbQuido: TGroupBox
    Left = 8
    Top = 152
    Width = 337
    Height = 289
    Caption = 'Quido'
    TabOrder = 1
    Visible = False
    object GroupBox2: TGroupBox
      Left = 8
      Top = 48
      Width = 321
      Height = 41
      Caption = 'Info'
      TabOrder = 0
      object Label2: TLabel
        Left = 40
        Top = 16
        Width = 32
        Height = 13
        Caption = 'Label2'
      end
    end
    object GroupBox3: TGroupBox
      Left = 8
      Top = 96
      Width = 321
      Height = 57
      Caption = 'V'#253'stupy'
      TabOrder = 1
      object ComboBoxOut: TComboBox
        Left = 16
        Top = 24
        Width = 121
        Height = 21
        Style = csDropDownList
        ItemHeight = 13
        TabOrder = 0
        OnChange = ComboBoxOutChange
      end
      object chOut: TCheckBox
        Left = 144
        Top = 27
        Width = 97
        Height = 17
        TabOrder = 1
        OnClick = chOutClick
      end
    end
    object GroupBox4: TGroupBox
      Left = 8
      Top = 160
      Width = 321
      Height = 121
      Caption = 'Vstupy'
      TabOrder = 2
      object InIndik: TShape
        Left = 144
        Top = 40
        Width = 25
        Height = 25
        Shape = stCircle
      end
      object ComboBoxIn: TComboBox
        Left = 16
        Top = 40
        Width = 121
        Height = 21
        Style = csDropDownList
        ItemHeight = 13
        TabOrder = 0
        OnChange = ComboBoxInChange
      end
      object GroupBox5: TGroupBox
        Left = 16
        Top = 72
        Width = 257
        Height = 41
        Caption = #268#237'ta'#269
        TabOrder = 1
        object lblCounter: TLabel
          Left = 16
          Top = 16
          Width = 3
          Height = 13
        end
        object lblCounterValue: TLabel
          Left = 128
          Top = 16
          Width = 3
          Height = 13
        end
      end
      object chAutoNotify: TCheckBox
        Left = 16
        Top = 16
        Width = 273
        Height = 17
        Caption = 'Automatick'#233' vys'#237'l'#225'n'#237' p'#345'i zm'#283'n'#283' stavu vstup'#367
        TabOrder = 2
        OnClick = chAutoNotifyClick
      end
    end
    object cmdReset: TButton
      Left = 56
      Top = 16
      Width = 75
      Height = 25
      Caption = 'Reset'
      TabOrder = 3
      OnClick = cmdResetClick
    end
    object cmdSPInfo: TButton
      Left = 144
      Top = 16
      Width = 75
      Height = 25
      Caption = 'SP Info'
      TabOrder = 4
      OnClick = cmdSPInfoClick
    end
  end
end
