﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Papouch.w32_Dll;

namespace QuidoDemo2
{
    public partial class FormQuidoDemoDLL2Example : Form
    {
        public FormQuidoDemoDLL2Example()
        {
            InitializeComponent();
        }

        private Quido quido = null;

        private void LogMsg(string text, params object[] args)
        {
            textBoxLog.Text += String.Format(text+"\r\n",args);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                quido = new Quido(textBoxConnectionString.Text, textBoxDeviceString.Text);

                if (quido!=null)
                {
                    LogMsg("Quido object created sucesfully");
                    LogMsg("ConnectionString \t:  {0}",quido.ConnectionString);
                    LogMsg("DeviceString \t:  {0}", quido.DeviceString);
                }

            }
            catch (Exception ex)
            {
                LogMsg("Exception: {0}",ex.Message);
            }
        }

        private void buttonConnect_Click(object sender, EventArgs e)
        {
            if (quido != null)
            {
                if (quido.Open())
                {
                    LogMsg("Quido CI (communication interface) open - ok");
                }
                else
                {
                    LogMsg("Quido CI (communication interface) open - error");
                }
            }
        }

        private void buttonDisconnect_Click(object sender, EventArgs e)
        {
            if (quido != null)
            {
                if (quido.Close())
                {
                    LogMsg("Quido CI (communication interface) close - ok");
                }
                else
                {
                    LogMsg("Quido CI (communication interface) close - error");
                }
            }
        }

        private void buttonDestroy_Click(object sender, EventArgs e)
        {
            quido = null;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool[] outputs;
            QuidoStack_Dll.reStat result = quido.GetOutputs(out outputs);

            if (result == QuidoStack_Dll.reStat.err_Ok)
            {
                LogMsg("Get {0} OUTPUTS", outputs.Length);

                int i = 1;
                foreach (bool output in outputs)
                {
                    LogMsg("OUTPUT {0} = {1}", i, output);
                    i++;
                }
            }
            else
            {
                LogMsg("Quido method 'GetOutputs' - error code: {0}", result);
            }
        }

        private void buttonGetInputs_Click(object sender, EventArgs e)
        {
            
            bool[] inputs;
            QuidoStack_Dll.reStat result = quido.GetInputs(out inputs);

            if (result == QuidoStack_Dll.reStat.err_Ok)
            {
                LogMsg("Get {0} INPUTS", inputs.Length);

                int i = 1;
                foreach (bool input in inputs)
                {
                    LogMsg("INPUT {0} = {1}", i, input);
                    i++;
                }
            }
            else
            {
                LogMsg("Quido method 'GetInputs' - error code: {0}", result);
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (checkBoxTimered.Checked)
            {
                byte timer = (byte)(numericUpDownOutputTimer.Value * 2);
                quido.SetOutput((int)numericUpDownOutputIndex.Value, true, timer);
            }
            else
            {
                quido.SetOutput((int)numericUpDownOutputIndex.Value, true);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (checkBoxTimered.Checked)
            {
                byte timer = (byte)(numericUpDownOutputTimer.Value * 2);
                quido.SetOutput((int)numericUpDownOutputIndex.Value, false, timer);
            }
            else
            {
                quido.SetOutput((int)numericUpDownOutputIndex.Value, false);
            }
        }

        private void numericUpDownOutputTimer_ValueChanged(object sender, EventArgs e)
        {

        }

    }
}
