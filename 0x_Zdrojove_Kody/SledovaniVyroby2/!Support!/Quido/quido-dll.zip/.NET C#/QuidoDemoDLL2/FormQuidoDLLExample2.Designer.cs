﻿namespace QuidoDemo2
{
    partial class FormQuidoDemoDLL2Example
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxLog = new System.Windows.Forms.TextBox();
            this.textBoxDeviceString = new System.Windows.Forms.TextBox();
            this.textBoxConnectionString = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonDestroy = new System.Windows.Forms.Button();
            this.buttonDisconnect = new System.Windows.Forms.Button();
            this.buttonConnect = new System.Windows.Forms.Button();
            this.buttonCreateQuido = new System.Windows.Forms.Button();
            this.buttonGetOutputs = new System.Windows.Forms.Button();
            this.buttonGetInputs = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.numericUpDownOutputTimer = new System.Windows.Forms.NumericUpDown();
            this.checkBoxTimered = new System.Windows.Forms.CheckBox();
            this.buttonSetOutputOff = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.numericUpDownOutputIndex = new System.Windows.Forms.NumericUpDown();
            this.buttonSetOutputOn = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownOutputTimer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownOutputIndex)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxLog
            // 
            this.textBoxLog.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxLog.Location = new System.Drawing.Point(12, 233);
            this.textBoxLog.Multiline = true;
            this.textBoxLog.Name = "textBoxLog";
            this.textBoxLog.Size = new System.Drawing.Size(706, 187);
            this.textBoxLog.TabIndex = 9;
            // 
            // textBoxDeviceString
            // 
            this.textBoxDeviceString.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxDeviceString.Location = new System.Drawing.Point(104, 48);
            this.textBoxDeviceString.Name = "textBoxDeviceString";
            this.textBoxDeviceString.Size = new System.Drawing.Size(266, 20);
            this.textBoxDeviceString.TabIndex = 8;
            this.textBoxDeviceString.Text = "addr=$FE";
            // 
            // textBoxConnectionString
            // 
            this.textBoxConnectionString.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxConnectionString.Location = new System.Drawing.Point(104, 22);
            this.textBoxConnectionString.Name = "textBoxConnectionString";
            this.textBoxConnectionString.Size = new System.Drawing.Size(266, 20);
            this.textBoxConnectionString.TabIndex = 7;
            this.textBoxConnectionString.Text = "provider=SERIAL_PORT;comport=20;baudrate=115200";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Device string:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Connection string:";
            // 
            // buttonDestroy
            // 
            this.buttonDestroy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonDestroy.Location = new System.Drawing.Point(619, 20);
            this.buttonDestroy.Name = "buttonDestroy";
            this.buttonDestroy.Size = new System.Drawing.Size(75, 48);
            this.buttonDestroy.TabIndex = 10;
            this.buttonDestroy.Text = "Destroy";
            this.buttonDestroy.UseVisualStyleBackColor = true;
            this.buttonDestroy.Click += new System.EventHandler(this.buttonDestroy_Click);
            // 
            // buttonDisconnect
            // 
            this.buttonDisconnect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonDisconnect.Location = new System.Drawing.Point(538, 21);
            this.buttonDisconnect.Name = "buttonDisconnect";
            this.buttonDisconnect.Size = new System.Drawing.Size(75, 46);
            this.buttonDisconnect.TabIndex = 11;
            this.buttonDisconnect.Text = "Disconnect";
            this.buttonDisconnect.UseVisualStyleBackColor = true;
            this.buttonDisconnect.Click += new System.EventHandler(this.buttonDisconnect_Click);
            // 
            // buttonConnect
            // 
            this.buttonConnect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonConnect.Location = new System.Drawing.Point(457, 21);
            this.buttonConnect.Name = "buttonConnect";
            this.buttonConnect.Size = new System.Drawing.Size(75, 46);
            this.buttonConnect.TabIndex = 12;
            this.buttonConnect.Text = "Connect";
            this.buttonConnect.UseVisualStyleBackColor = true;
            this.buttonConnect.Click += new System.EventHandler(this.buttonConnect_Click);
            // 
            // buttonCreateQuido
            // 
            this.buttonCreateQuido.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCreateQuido.Location = new System.Drawing.Point(376, 22);
            this.buttonCreateQuido.Name = "buttonCreateQuido";
            this.buttonCreateQuido.Size = new System.Drawing.Size(75, 46);
            this.buttonCreateQuido.TabIndex = 13;
            this.buttonCreateQuido.Text = "Create";
            this.buttonCreateQuido.UseVisualStyleBackColor = true;
            this.buttonCreateQuido.Click += new System.EventHandler(this.button4_Click);
            // 
            // buttonGetOutputs
            // 
            this.buttonGetOutputs.Location = new System.Drawing.Point(263, 19);
            this.buttonGetOutputs.Name = "buttonGetOutputs";
            this.buttonGetOutputs.Size = new System.Drawing.Size(75, 46);
            this.buttonGetOutputs.TabIndex = 14;
            this.buttonGetOutputs.Text = "GetOutputs";
            this.buttonGetOutputs.UseVisualStyleBackColor = true;
            this.buttonGetOutputs.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonGetInputs
            // 
            this.buttonGetInputs.Location = new System.Drawing.Point(269, 19);
            this.buttonGetInputs.Name = "buttonGetInputs";
            this.buttonGetInputs.Size = new System.Drawing.Size(75, 46);
            this.buttonGetInputs.TabIndex = 15;
            this.buttonGetInputs.Text = "GetInputs";
            this.buttonGetInputs.UseVisualStyleBackColor = true;
            this.buttonGetInputs.Click += new System.EventHandler(this.buttonGetInputs_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonCreateQuido);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBoxConnectionString);
            this.groupBox1.Controls.Add(this.buttonConnect);
            this.groupBox1.Controls.Add(this.textBoxDeviceString);
            this.groupBox1.Controls.Add(this.buttonDisconnect);
            this.groupBox1.Controls.Add(this.buttonDestroy);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(706, 81);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Initialization / Deinitialization";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.buttonGetInputs);
            this.groupBox2.Location = new System.Drawing.Point(12, 99);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(350, 128);
            this.groupBox2.TabIndex = 17;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "INPUTS";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.numericUpDownOutputTimer);
            this.groupBox3.Controls.Add(this.checkBoxTimered);
            this.groupBox3.Controls.Add(this.buttonSetOutputOff);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.numericUpDownOutputIndex);
            this.groupBox3.Controls.Add(this.buttonSetOutputOn);
            this.groupBox3.Controls.Add(this.buttonGetOutputs);
            this.groupBox3.Location = new System.Drawing.Point(368, 99);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(350, 128);
            this.groupBox3.TabIndex = 18;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "OUTPUTS";
            // 
            // numericUpDownOutputTimer
            // 
            this.numericUpDownOutputTimer.DecimalPlaces = 1;
            this.numericUpDownOutputTimer.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.numericUpDownOutputTimer.Location = new System.Drawing.Point(83, 96);
            this.numericUpDownOutputTimer.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
            this.numericUpDownOutputTimer.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.numericUpDownOutputTimer.Name = "numericUpDownOutputTimer";
            this.numericUpDownOutputTimer.Size = new System.Drawing.Size(56, 20);
            this.numericUpDownOutputTimer.TabIndex = 20;
            this.numericUpDownOutputTimer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDownOutputTimer.Value = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.numericUpDownOutputTimer.ValueChanged += new System.EventHandler(this.numericUpDownOutputTimer_ValueChanged);
            // 
            // checkBoxTimered
            // 
            this.checkBoxTimered.AutoSize = true;
            this.checkBoxTimered.Location = new System.Drawing.Point(20, 96);
            this.checkBoxTimered.Name = "checkBoxTimered";
            this.checkBoxTimered.Size = new System.Drawing.Size(63, 17);
            this.checkBoxTimered.TabIndex = 19;
            this.checkBoxTimered.Text = "timered:";
            this.checkBoxTimered.UseVisualStyleBackColor = true;
            // 
            // buttonSetOutputOff
            // 
            this.buttonSetOutputOff.Location = new System.Drawing.Point(263, 71);
            this.buttonSetOutputOff.Name = "buttonSetOutputOff";
            this.buttonSetOutputOff.Size = new System.Drawing.Size(75, 46);
            this.buttonSetOutputOff.TabIndex = 18;
            this.buttonSetOutputOff.Text = "SetOutput\r\n( false )";
            this.buttonSetOutputOff.UseVisualStyleBackColor = true;
            this.buttonSetOutputOff.Click += new System.EventHandler(this.button2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "Input:";
            // 
            // numericUpDownOutputIndex
            // 
            this.numericUpDownOutputIndex.Location = new System.Drawing.Point(83, 71);
            this.numericUpDownOutputIndex.Name = "numericUpDownOutputIndex";
            this.numericUpDownOutputIndex.Size = new System.Drawing.Size(56, 20);
            this.numericUpDownOutputIndex.TabIndex = 16;
            this.numericUpDownOutputIndex.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttonSetOutputOn
            // 
            this.buttonSetOutputOn.Location = new System.Drawing.Point(182, 71);
            this.buttonSetOutputOn.Name = "buttonSetOutputOn";
            this.buttonSetOutputOn.Size = new System.Drawing.Size(75, 46);
            this.buttonSetOutputOn.TabIndex = 15;
            this.buttonSetOutputOn.Text = "SetOutput\r\n( true )";
            this.buttonSetOutputOn.UseVisualStyleBackColor = true;
            this.buttonSetOutputOn.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // FormQuidoDemoDLL2Example
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(730, 432);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBoxLog);
            this.Name = "FormQuidoDemoDLL2Example";
            this.Text = "Quido DLL example 2";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownOutputTimer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownOutputIndex)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxLog;
        private System.Windows.Forms.TextBox textBoxDeviceString;
        private System.Windows.Forms.TextBox textBoxConnectionString;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonDestroy;
        private System.Windows.Forms.Button buttonDisconnect;
        private System.Windows.Forms.Button buttonConnect;
        private System.Windows.Forms.Button buttonCreateQuido;
        private System.Windows.Forms.Button buttonGetOutputs;
        private System.Windows.Forms.Button buttonGetInputs;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button buttonSetOutputOn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numericUpDownOutputIndex;
        private System.Windows.Forms.Button buttonSetOutputOff;
        private System.Windows.Forms.CheckBox checkBoxTimered;
        private System.Windows.Forms.NumericUpDown numericUpDownOutputTimer;

    }
}

