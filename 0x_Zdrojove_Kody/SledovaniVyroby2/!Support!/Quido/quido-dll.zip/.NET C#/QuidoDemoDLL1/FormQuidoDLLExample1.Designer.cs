﻿namespace QuidoDemo
{
    partial class FormQuidoDLLExample1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelCS = new System.Windows.Forms.Label();
            this.labelDS = new System.Windows.Forms.Label();
            this.textBoxConnectionString = new System.Windows.Forms.TextBox();
            this.textBoxDeviceString = new System.Windows.Forms.TextBox();
            this.textBoxLog = new System.Windows.Forms.TextBox();
            this.buttonTest1 = new System.Windows.Forms.Button();
            this.buttonTest2 = new System.Windows.Forms.Button();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.buttonGenerateCS = new System.Windows.Forms.Button();
            this.pageSetupDialog1 = new System.Windows.Forms.PageSetupDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // labelCS
            // 
            this.labelCS.AutoSize = true;
            this.labelCS.Location = new System.Drawing.Point(12, 9);
            this.labelCS.Name = "labelCS";
            this.labelCS.Size = new System.Drawing.Size(92, 13);
            this.labelCS.TabIndex = 0;
            this.labelCS.Text = "Connection string:";
            // 
            // labelDS
            // 
            this.labelDS.AutoSize = true;
            this.labelDS.Location = new System.Drawing.Point(12, 35);
            this.labelDS.Name = "labelDS";
            this.labelDS.Size = new System.Drawing.Size(72, 13);
            this.labelDS.TabIndex = 1;
            this.labelDS.Text = "Device string:";
            // 
            // textBoxConnectionString
            // 
            this.textBoxConnectionString.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxConnectionString.Location = new System.Drawing.Point(102, 6);
            this.textBoxConnectionString.Name = "textBoxConnectionString";
            this.textBoxConnectionString.Size = new System.Drawing.Size(310, 20);
            this.textBoxConnectionString.TabIndex = 2;
            this.textBoxConnectionString.Text = "provider=SERIAL_PORT;comport=9;baudrate=115200";
            // 
            // textBoxDeviceString
            // 
            this.textBoxDeviceString.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxDeviceString.Location = new System.Drawing.Point(102, 32);
            this.textBoxDeviceString.Name = "textBoxDeviceString";
            this.textBoxDeviceString.Size = new System.Drawing.Size(354, 20);
            this.textBoxDeviceString.TabIndex = 3;
            this.textBoxDeviceString.Text = "addr=$FE";
            // 
            // textBoxLog
            // 
            this.textBoxLog.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxLog.Location = new System.Drawing.Point(102, 132);
            this.textBoxLog.Multiline = true;
            this.textBoxLog.Name = "textBoxLog";
            this.textBoxLog.Size = new System.Drawing.Size(354, 282);
            this.textBoxLog.TabIndex = 4;
            // 
            // buttonTest1
            // 
            this.buttonTest1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonTest1.Location = new System.Drawing.Point(102, 58);
            this.buttonTest1.Name = "buttonTest1";
            this.buttonTest1.Size = new System.Drawing.Size(354, 31);
            this.buttonTest1.TabIndex = 5;
            this.buttonTest1.Text = "Ukázka práce s funkcemi knihovny DLL";
            this.buttonTest1.UseVisualStyleBackColor = true;
            this.buttonTest1.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonTest2
            // 
            this.buttonTest2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonTest2.Location = new System.Drawing.Point(102, 95);
            this.buttonTest2.Name = "buttonTest2";
            this.buttonTest2.Size = new System.Drawing.Size(354, 31);
            this.buttonTest2.TabIndex = 6;
            this.buttonTest2.Text = "Ukázka práce s objektem zapouzdřující DLL funkce";
            this.buttonTest2.UseVisualStyleBackColor = true;
            this.buttonTest2.Click += new System.EventHandler(this.buttonTest2_Click);
            // 
            // buttonGenerateCS
            // 
            this.buttonGenerateCS.Location = new System.Drawing.Point(418, 6);
            this.buttonGenerateCS.Name = "buttonGenerateCS";
            this.buttonGenerateCS.Size = new System.Drawing.Size(38, 23);
            this.buttonGenerateCS.TabIndex = 7;
            this.buttonGenerateCS.Text = "...";
            this.buttonGenerateCS.UseVisualStyleBackColor = true;
            this.buttonGenerateCS.Click += new System.EventHandler(this.buttonGenerateCS_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // FormQuidoDLLExample1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(468, 426);
            this.Controls.Add(this.buttonGenerateCS);
            this.Controls.Add(this.buttonTest2);
            this.Controls.Add(this.buttonTest1);
            this.Controls.Add(this.textBoxLog);
            this.Controls.Add(this.textBoxDeviceString);
            this.Controls.Add(this.textBoxConnectionString);
            this.Controls.Add(this.labelDS);
            this.Controls.Add(this.labelCS);
            this.Name = "FormQuidoDLLExample1";
            this.Text = "Quido DLL example 1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelCS;
        private System.Windows.Forms.Label labelDS;
        private System.Windows.Forms.TextBox textBoxConnectionString;
        private System.Windows.Forms.TextBox textBoxDeviceString;
        private System.Windows.Forms.TextBox textBoxLog;
        private System.Windows.Forms.Button buttonTest1;
        private System.Windows.Forms.Button buttonTest2;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Button buttonGenerateCS;
        private System.Windows.Forms.PageSetupDialog pageSetupDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}

