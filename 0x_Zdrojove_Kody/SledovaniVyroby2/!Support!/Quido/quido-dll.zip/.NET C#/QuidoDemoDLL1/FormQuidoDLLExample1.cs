﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Papouch.w32_Dll;

namespace QuidoDemo
{
    public partial class FormQuidoDLLExample1 : Form
    {
        public FormQuidoDLLExample1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            // ukázka komunikace pomocí DLL knihoven "ComIntfDll.dll" a "QuidoStackDll.dll" 
            // funkce jsou namapované v statické třídě "QuidoDll" ve jmenném prostoru "Papouch.Quido"
            // 

            textBoxLog.Clear();

            // inicializace Quida + Komunikačního rozhraní

            int QuidoHandle = QuidoStack_Dll.qCreateQuido(textBoxConnectionString.Text, textBoxDeviceString.Text);

            textBoxLog.Text += String.Format("QUIDO Create - handle:\t{0}\r\n",     QuidoHandle);
            textBoxLog.Text += String.Format("QUIDO Open \t\t{0}\r\n",       QuidoStack_Dll.qOpen(QuidoHandle));

            bool bIsOpen = false;
            textBoxLog.Text += String.Format("QUIDO IsOpen \t\t{0}\t{1}\r\n", QuidoStack_Dll.qIsOpened(QuidoHandle, out bIsOpen), bIsOpen);

            
            // Sepnut relé  {rozepnutí je na konci této metody}

            textBoxLog.Text += String.Format("QUIDO Output Set \t\t{0}\r\n", QuidoStack_Dll.qSetOutput(QuidoHandle, 0, true));


            // Dotaz na počet vstupů

            textBoxLog.Text += String.Format("QUIDO Inputs count \t{0}\r\n", QuidoStack_Dll.qInputsCount(QuidoHandle));


            // Dotazy na jednotlivé vstupy ( indexováno od 0 )

            bool b;
            textBoxLog.Text += String.Format("QUIDO Input 1 stat \t{0}\tStat = {1}\r\n", QuidoStack_Dll.qInputStateByIndex(QuidoHandle, 0, out b), b);
            textBoxLog.Text += String.Format("QUIDO Input 2 stat \t{0}\tStat = {1}\r\n", QuidoStack_Dll.qInputStateByIndex(QuidoHandle, 1, out b), b);


            // Dotaz na stav všech vstupů

            bool[] inputs = null;
            textBoxLog.Text += String.Format("QUIDO Inputs \t{0}\r\n", QuidoStack_Dll.qGetInputs(QuidoHandle, out inputs));

            if ((inputs!=null) && (inputs.Length>0))
            {
                int i = 0;
                foreach (bool Input in inputs)
                {
                    textBoxLog.Text += String.Format("QUIDO Input {0} \t{1}\r\n", i++, Input);
                }
            }
            // Dotaz na  stav všech výstupů

            
            bool[] outputs;
            textBoxLog.Text += String.Format("QUIDO Inputs \t{0}\r\n", QuidoStack_Dll.qGetOutputs(QuidoHandle, out outputs));

            if ((outputs!=null) && (outputs.Length > 0))
            {
                int j = 0;
                foreach (bool Output in outputs)
                {
                    textBoxLog.Text += String.Format("QUIDO Output {0} \t{1}\r\n", j++, Output);
                }
            }

            int temp;
            textBoxLog.Text += String.Format("QUIDO Get Temperature \t\t{0}\t{1}\r\n", QuidoStack_Dll.qGetTemperature(QuidoHandle, 1, out temp),temp);


            // 1.5 sec počkat

            System.Threading.Thread.Sleep(2500);

            // Rozepnutí relé 

            textBoxLog.Text += String.Format("QUIDO Output Set \t\t{0}\r\n", QuidoStack_Dll.qSetOutput(QuidoHandle, 0, false));


            // deinicializace Quida a Komunikačního rozhraní

            textBoxLog.Text += String.Format("QUIDO Close \t\t{0}\r\n", QuidoStack_Dll.qClose(QuidoHandle));
            textBoxLog.Text += String.Format("QUIDO Release \t\t{0}\r\n", QuidoStack_Dll.qReleaseQuido(QuidoHandle));
        }

        private void buttonTest2_Click(object sender, EventArgs e)
        {
            Quido quido = new Quido(textBoxConnectionString.Text, textBoxDeviceString.Text);

            quido.Open();

            quido.SetOutput(0,true);
            System.Threading.Thread.Sleep(500);
            quido.SetOutput(0, false);

            quido.Close();

            quido.Release();
        }

        private void buttonGenerateCS_Click(object sender, EventArgs e)
        {
            string Caption = this.Text;
            string DefConnStr = textBoxConnectionString.Text;
            string ConnStr = textBoxConnectionString.Text;

            Boolean OkResult = false;

            Papouch.w32_Dll.CommIntf_Dll.ConnectionStringDlga(out ConnStr, out OkResult, DefConnStr, Caption);

            if (OkResult)
            {
                textBoxConnectionString.Text = ConnStr;
            }

        }
    }
}
