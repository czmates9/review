﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Papouch.w32_Dll
{

    public class Quido
    {
        private int qHandle = 0;

        public int handle
        {
            get
            {
                return qHandle;
            }
        }

        private string fConnectionString = "";
        private string fDeviceString = "";

        public string ConnectionString
        {
            get { return fConnectionString; }
        }
        public string DeviceString
        {
            get { return fDeviceString; }
        }

        public Quido(String connectionString, String deviceString)
        {
            fConnectionString = connectionString;
            fDeviceString = deviceString;

            qHandle = QuidoStack_Dll.qCreateQuido(connectionString, deviceString);
            if (qHandle == 0)
            {
                throw new Exception("Quido cannot create");
            }
        }

        ~Quido()
        {
            Release();
        }

        public void Release()
        {
            if (qHandle != 0)
            {
                Close();
                QuidoStack_Dll.qReleaseQuido(qHandle);
                qHandle = 0;
            }
        }

        public bool Close()
        {
            if (qHandle != 0)
            {
                return (QuidoStack_Dll.qClose(qHandle) == QuidoStack_Dll.reStat.err_Ok);
            }
            else return false;
        }

        public bool Open()
        {
            if (qHandle != 0)
            {
                return (QuidoStack_Dll.qOpen(qHandle) == QuidoStack_Dll.reStat.err_Ok);
            }
            else return false;
        }

        public QuidoStack_Dll.reStat GetInputs(out bool[] inputs)
        {
            return QuidoStack_Dll.qGetInputs(qHandle, out inputs);
        }

        public QuidoStack_Dll.reStat GetOutputs(out bool[] outputs)
        {
            return QuidoStack_Dll.qGetOutputs(qHandle, out outputs);
        }

        public QuidoStack_Dll.reStat SetOutput(int index, bool state)
        {
            return QuidoStack_Dll.qSetOutput(qHandle, index, state);
        }

        public QuidoStack_Dll.reStat SetOutput(int index, bool state, byte timer)
        {
            return QuidoStack_Dll.qSetOutputTimered(qHandle, index, state, timer);
        }
    }
}
