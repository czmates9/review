﻿using System;
using System.Runtime.InteropServices;

namespace Papouch.w32_Dll
{
    public class CommIntf_Dll
    {
        private const string CommIntfDll = "CommIntfDll.dll";

        #region Konstanty pro typ události komunikačního rozhraní

        public const int ciev_Base = 256;
        public const int ciev_Open = ciev_Base + 1;
        public const int ciev_Close = ciev_Base + 2;
        public const int ciev_DataRcv = ciev_Base + 3;
        public const int ciev_Error = ciev_Base + 4;

        #endregion

        #region Konstanty pro návratový typ funkcí reStat

        public enum reStat
        {
            err_Ok = 0,
            err_Base = 0x20000000,
            err_Undefined = err_Base + 1,
            err_MoreSize = err_Base + 4,
            err_InvalidHandle = err_Base + 5,
            err_BadConnParams = err_Base + 6,
            err_IndexOutOfBand = err_Base + 7,
            err_UnavailableData = err_Base + 8,
            err_BadParam = err_Base + 9,
            err_MissingDllLibrary = err_Base + 21,
            err_ConnectionFailure = err_Base + 18,
            err_ConnectionNotOpened = err_Base + 23,
            err_BadSpinelPacket = err_Base + 24,
            err_DeviceNotResponse = err_Base + 17,
            err_CriticalError = err_Base + 22,
            err_DLLCallFailure = 0x10000000,
            err_DLLCallException = err_DLLCallFailure + 1
        }

        #endregion

        /// <summary>
        /// Funkce CICreate vytvoří komunikační rozhranní podle zadaného připojovacího řetězce, tzv. "connection string". Connection string je řetězec pro vytvoření komunikačního rozhranní, určuje typ komunikačního rozhraní a jeho parametry (sériový port, tcp, udp, nebo ftd_usb) Tvorba connection stringu: Jsou to hodnoty ve tvaru "parametr=hodnota" odděleny středníkem. Nejdůležitějším parametrem je "provider", určuje typ rozhranní. Může to být SERIAL_PORT, TCP_CLIENT, UDP_CLIENT nebo FTD_USB Každé rozhraní pak může mít další parametry podle typu: - SERIAL_PORT (comport=číslo portu;baudrate=rychlost - nemusí být zadáno) - TCP_CLIENT (host=ip adresa zařízení;port=tcp port zařízení), UDP_CLIENT(stejné jako TCP) - FTD_USB (index=pořadové číslo zařízení; nebo device=část názvu zařízení; nebo serial_number=sériové číslo zařízení; nebo vid=vid;pid=pid; nebo nemusí mít žádný parametr, vezme se první připojené zařízení typu FTD_USB Návratová hodnota funkce je madlo, tzv. "handle" na vytvořené komunikační rozhranní, který se předává ostatním funkcím jako identifikátor vytvořeného rozhraní. Pokud se rozhraní nepodaří vytvořit, funkce vrátí 0. 
        /// </summary>
        /// <param name="connectionString">Pointer na připojovací řetězec. Určuje typ a parametry rozhraní.</param>
        /// <returns>Funkce vrací handle na vytvořené rozhraní. Pokud se vytvoření rozhraní nezdaří, vrací 0.</returns>
        [DllImport(CommIntfDll, CharSet = CharSet.Auto)]
        public static extern int ciCreate(IntPtr connectionstring);

        /// <summary>
        /// Funkce CICreate vytvoří komunikační rozhranní podle zadaného připojovacího řetězce, tzv. "connection string". Connection string je řetězec pro vytvoření komunikačního rozhranní, určuje typ komunikačního rozhraní a jeho parametry (sériový port, tcp, udp, nebo ftd_usb) Tvorba connection stringu: Jsou to hodnoty ve tvaru "parametr=hodnota" odděleny středníkem. Nejdůležitějším parametrem je "provider", určuje typ rozhranní. Může to být SERIAL_PORT, TCP_CLIENT, UDP_CLIENT nebo FTD_USB Každé rozhraní pak může mít další parametry podle typu: - SERIAL_PORT (comport=číslo portu;baudrate=rychlost - nemusí být zadáno) - TCP_CLIENT (host=ip adresa zařízení;port=tcp port zařízení), UDP_CLIENT(stejné jako TCP) - FTD_USB (index=pořadové číslo zařízení; nebo device=část názvu zařízení; nebo serial_number=sériové číslo zařízení; nebo vid=vid;pid=pid; nebo nemusí mít žádný parametr, vezme se první připojené zařízení typu FTD_USB Návratová hodnota funkce je madlo, tzv. "handle" na vytvořené komunikační rozhranní, který se předává ostatním funkcím jako identifikátor vytvořeného rozhraní. Pokud se rozhraní nepodaří vytvořit, funkce vrátí 0. 
        /// </summary>
        /// <param name="connectionString">Připojovací řetězec. Určuje typ a parametry rozhraní.</param>
        /// <returns>Funkce vrací handle na vytvořené rozhraní. Pokud se vytvoření rozhraní nezdaří, vrací 0.</returns>
        public static int ciCreate(string connectionString)
        {
            IntPtr pConnectionString = Marshal.StringToHGlobalAnsi(connectionString);

            int result = ciCreate(pConnectionString);

            Marshal.FreeHGlobal(pConnectionString);

            return result;
        }

        /// <summary>
        /// otevře komunikační kanál (otevře port, naváže tcp spojení, ... podle typu komunikačního rozhraní; nutno před započetím komunikace; vrátí 0 pokud OK, chybový kód v opačném případě Jako handle se předává handle získané z funkcí ciCreate 
        /// </summary>
        /// <param name="ciHandle">Madlo na komunikační rozhraní</param>
        /// <returns>Funkce vrací O pokud se podaří rozhraní otevřít, jinak vrací chybový kód.</returns>
        [DllImport(CommIntfDll, CharSet = CharSet.Auto)]
        public static extern reStat ciOpen(int ciHandle);

        /// <summary>
        /// Zavře komunikační kanál 
        /// </summary>
        /// <param name="ciHandle">Madlo na komunikační rozhraní</param>
        /// <returns>Funkce vrací O pokud proběhne v pořádku, jinak vrací chybový kód.</returns>
        [DllImport(CommIntfDll, CharSet = CharSet.Auto)]
        public static extern reStat ciClose(int ciHandle);

        /// <summary>
        /// Zruší komunikační rozhraní a příslušné madlo 
        /// </summary>
        /// <param name="ciHandle">Madlo na komunikační rozhraní</param>
        /// <returns>Funkce vrací O pokud proběhne v pořádku, jinak vrací chybový kód.</returns>
        [DllImport(CommIntfDll, CharSet = CharSet.Auto)]
        public static extern reStat ciRelease(int ciHandle);

        /// <summary>
        /// Zjistí, zda je komunikační rozhranní otevřeno.
        /// </summary>
        /// <param name="ciHandle">Madlo na komunikační rozhraní</param>
        /// <param name="active">Reference na 32-bitovou logickou proměnnou, do kterého se uloží stav 1 (true) znamená že rozhraní je otevřeno, 0 (false) znamená že není.</param>
        /// <returns>Funkce vrací O pokud se podaří zjistit stav, jinak vrací chybový kód</returns>
        [DllImport(CommIntfDll, CharSet = CharSet.Auto)]
        public static extern reStat ciIsActive(int ciHandle, out bool active);

        /// <summary>
        /// Spustí se konfigurační dialog konkrétního komunikačního rozhranní, přes který lze upravit jeho parametry
        /// </summary>
        /// <param name="ciHandle">Madlo komunikačního rozhraní</param>
        /// <returns></returns>
        [DllImport(CommIntfDll, CharSet = CharSet.Auto)]
        public static extern bool ciExecuteConfigDialog(int ciHandle);

        /// <summary>
        /// Zjistí, zda rozhraní podporuje konfigurační dialog.
        /// </summary>
        /// <param name="ciHandle">Madlo rozhraní</param>
        /// <returns>Funkce vrací true, pokud rozhraní podporuje konfigurační dialog, jinak false (všechny současné typy ho podporují)</returns>
        [DllImport(CommIntfDll, CharSet = CharSet.Auto)]
        public static extern bool ciConfigDialogAvailable(int ciHandle);

        /// <summary>
        /// Načte příchozí data. Size se nastaví na velikost bufferu, vráti se počet načtených bytů. 
        /// </summary>
        /// <param name="ciHandle">Madlo na komunikační rozhraní</param>
        /// <param name="buffer">Ukazatel na místo v paměti, kam se načtou přijatá data</param>
        /// <param name="size">Velikost bufferu (maximální počet bytů, které budou načteny) - funkce tuto hodnotu nastaví na hodnotu odpovídající počtu načtených dat</param>
        /// <returns>Funkce vrací O pokud se podaří zjistit stav, jinak vrací chybový kód</returns>
        [DllImport(CommIntfDll, CharSet = CharSet.Auto)]
        public static extern reStat ciRead(int ciHandle, IntPtr buffer, ref int size);

        /// <summary>
        /// Načte příchozí data. Size se nastaví na velikost bufferu, vráti se počet načtených bytů.
        /// </summary>
        /// <param name="ciHandle">Madlo na otevřené rozhraní</param>
        /// <param name="buffer">Načtená data</param>
        /// <returns>Funkce vrací O pokud čtení proběhne v pořádku, jinak chybový kód</returns>
        public static reStat ciRead(int ciHandle, out byte[] buffer)
        {
            buffer = null;
            int len = 0;
            reStat result = reStat.err_DLLCallFailure;
            IntPtr ptr = IntPtr.Zero;
            result = ciRead(ciHandle, ptr, ref len);
            if (result == 0)
            {
                ptr = Marshal.AllocHGlobal(len);
                result = ciRead(ciHandle, ptr, ref len);
                buffer = new byte[len];
                Marshal.Copy(ptr, buffer, 0, len);
                Marshal.FreeHGlobal(ptr);
            }
            return result;
        }

        /// <summary>
        /// Zapíše data na komunikační rozhraní.
        /// </summary>
        /// <param name="ciHandle">Madlo na komunikační rozhraní</param>
        /// <param name="buffer">Ukazatel na data, která budou zapsána</param>
        /// <param name="size">Počet bytů, které budou zapsány</param>
        /// <returns>Funkce vrací 0 pokud proběhne v pořádku, jinak chybový kód</returns>
        [DllImport(CommIntfDll, CharSet = CharSet.Auto)]
        public static extern reStat ciWrite(int ciHandle, IntPtr buffer, int size);

        /// <summary>
        /// Zapíše data na komunikační rozhraní.
        /// </summary>
        /// <param name="ciHandle">Madlo na komunikační rozhraní</param>
        /// <param name="buffer">Odesílaná data</param>
        /// <returns>Funkce vrací 0 pokud proběhne v pořádku, jinak chybový kód</returns>
        public static reStat ciWrite(int ciHandle, byte[] buffer)
        {
            int len = buffer.Length;
            IntPtr ptr = Marshal.AllocHGlobal(len);
            Marshal.Copy(buffer, 0, ptr, len);
            reStat result = ciWrite(ciHandle, ptr, len);
            Marshal.FreeHGlobal(ptr);
            return result;
        }

        /// <summary>
        /// Zjistí, kolik bytů je ve vstupním bufferu připraveno k načtení. 
        /// </summary>
        /// <param name="ciHandle">Madlo na komunikační rozhraní</param>
        /// <returns>Funkce vrací počet bytů, které jsou připraveny k načtení</returns>
        [DllImport(CommIntfDll, CharSet = CharSet.Auto)]
        public static extern reStat ciReadLength(int ciHandle);

        /// <summary>
        /// Zobrazí dialog pro vytvoření konfiguračního řetězce. OutConnStr = buffer pro uložení výsledku; Len = velikost bufferu OutConnStr, zpět vrátí aktuální velikost řetězce; OKReturn=vrátí, zda bylo stisknuto OK; DefaultValue = Výchozí konfigurační řetězec; Caption = Titulek okna konfiguračního řetězce
        /// </summary>
        /// <param name="OutConnStr">Buffer pro uložení výsledku</param>
        /// <param name="Len">Obsahuje velikost paměti alokované pro OutConnStr v bytech. Po zavolání funkce je do ní vrácen skutečný počet zapsaných bytů</param>
        /// <param name="OKReturn">Proměnná, do které bude uložena návratová hodnota dialogu (true = dialog potvrzen, false = dialog stornován)</param>
        /// <param name="DefaultValue">Ukazatel na nulou zakončený řetězec, který obsahuje výchozí konfigurační řetězec</param>
        /// <param name="Caption">Ukazatel na nulou zakončený řetězec, který obsahuje titulek dialogu</param>
        /// <returns>Funkce vrací 0 pokud proběhne v pořádku, jinak chybový kód.</returns>
        [DllImport(CommIntfDll, CharSet = CharSet.Auto)]
        public static extern reStat ciGetConnectionStringDlg(IntPtr OutConnStr, ref int Len, ref bool OKReturn, IntPtr DefaultValue, IntPtr Caption);
        
        /// <summary>
        /// Zobrazí dialog pro vytvoření konfiguračního řetězce. OutConnStr = buffer pro uložení výsledku; zpět vrátí aktuální velikost řetězce; OKReturn=vrátí, zda bylo stisknuto OK; DefaultValue = Výchozí konfigurační řetězec; Caption = Titulek okna konfiguračního řetězce
        /// </summary>
        /// <param name="OutConnStr"></param>
        /// <param name="OkResult"></param>
        /// <param name="DefaultConnStr"></param>
        /// <param name="Caption"></param>
        /// <returns></returns>
        public static reStat ConnectionStringDlga(out string OutConnStr, out bool OkResult, string DefaultConnStr, string Caption)
        {
            reStat result = reStat.err_DLLCallFailure;
            OkResult = false; 
            OutConnStr = "";
            int ptrOutConnStrLen = 2048;
            IntPtr ptrOutConnStr = Marshal.AllocHGlobal(ptrOutConnStrLen);
            IntPtr ptrDefautConnStr = Marshal.StringToHGlobalAnsi(DefaultConnStr);
            IntPtr ptrCaption = Marshal.StringToHGlobalAnsi(Caption);
            try
            {
                result = ciGetConnectionStringDlg(ptrOutConnStr, ref ptrOutConnStrLen, ref OkResult, ptrDefautConnStr, ptrCaption);
                if (result == reStat.err_Ok)
                {
                    OutConnStr = Marshal.PtrToStringAnsi(ptrOutConnStr);
                }
            }
            catch
            {
                result = reStat.err_DLLCallException;
            }

            Marshal.FreeHGlobal(ptrCaption);
            Marshal.FreeHGlobal(ptrDefautConnStr);
            Marshal.FreeHGlobal(ptrOutConnStr);

            return result;
        }
    }
}
