﻿using System;
using System.Runtime.InteropServices;

namespace Papouch.w32_Dll
{
    public class QuidoStack_Dll
    {
        private const string QuidoStackDll = "QuidoStackDll.dll";

        #region Konstanty pro návratový typ funkcí reStat

        public enum reStat
        {
            err_Ok = 0,
            err_DLLCallFailure = 0x10000000,
            err_DLLCallException = err_DLLCallFailure + 1,
            err_Base = 0x20000000,
            err_Undefined = err_Base + 1,
            err_MoreSize = err_Base + 4,
            err_InvalidHandle = err_Base + 5,
            err_BadConnParams = err_Base + 6,
            err_IndexOutOfBand = err_Base + 7,
            err_UnavailableData = err_Base + 8,
            err_BadParam = err_Base + 9,
            err_MissingDllLibrary = err_Base + 21,
            err_ConnectionFailure = err_Base + 18,
            err_ConnectionNotOpened = err_Base + 23,
            err_BadSpinelPacket = err_Base + 24,
            err_DeviceNotResponse = err_Base + 17,
            err_CriticalError = err_Base + 22
        }

        #endregion

        /// <summary>
        /// Zjistí počet vytvořených Quid (funkcemi qCreateQuido...)
        /// </summary>
        /// <returns>Vací počet vytvořených Quid (&ht;=0). -1 = chyba</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern int qHandlesCount();

        /// <summary>
        /// Zjistí madlo Quida podle indexu 
        /// </summary>
        /// <param name="Index">Index madla (0..qHandlesCount-1)</param>
        /// <returns>Vrací madlo Quida. 0 = neplatné madlo.</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern int qHandleByIndex(int index);


        /// <summary>
        /// Zjistí počet vytvořených komunikačních rozhraní (ať již společně s Quidem nebo zvlášť v CommIntfDll.dll)
        /// </summary>
        /// <returns>Vrací počet komunikačních rozhraní (>=0). -1 = chyba</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern int ciHandlesCount();

        /// <summary>
        /// Zjistí madlo na komunikační rozhraní podle indexu
        /// </summary>
        /// <param name="index">Index madla (0..ciHandlesCount-1)</param>
        /// <returns>Vrací madlo na komunikační rozhraní. 0 = neplatné madlo</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern int ciHandleByIndex(int index);

        /// <summary>
        /// Vytvoří objekt Quida.
        /// </summary>
        /// <remarks>Vrací handle vytvořeného objektu Quida; 0 = nepovedlo se vytvořit Tvorba connectionstringu : jsou to hodnoty ve tvaru "parametr=hodnota" odděleny středníkem. určují typ připojení nejdůležitějším parametrem je "provider", určuje typ komunikačního kanálu. může to být SERIAL_PORT, TCP_CLIENT, UDP_CLIENT nebo FTD_USB každý kanál pak může mít další parametry. SERIAL_PORT (comport=číslo portu;baudrate=rychlost - nemusí být zadáno), TCP_CLIENT(host=ip adresa zařízení;port=tcp port zařízení), UDP_CLIENT(stejné jako TCP), FTD_USB(index=pořadové číslo zařízení; nebo device=část názvu zařízení; nebo serial_number=sériové číslo zařízení; nebo vid=vid;pid=pid; nebo nemusí mít žádný parametr, vezme se první připojené zařízení typu FTD_USB příklady: "provider=SERIAL_PORT;comport=1", "provider=TCP_CLIENT;host=192.168.1.254;port=10001", "provider=UDP_CLIENT;host=192.168.1.254;port=10001", "provider=FTD_USB;device=Quido" Tvorba devicestringu: př. "addr=12", "addr=$FE" ($ - znamená číslo je zadáno v hexa, $FE=univerzální adresa) </remarks>
        /// <param name="connectionstring">Connection string je řetězec pro vytvoření komunikačního rozhranní, určuje komunikační kanál a jeho nastavení (sériový port, tcp, udp, nebo ftd_usb)</param>
        /// <param name="deviceString">Devicestring specifikuje parametry zařízení Quido (adresu. v případě že je na komunikačním kanálu pouze jedno zařízení, lze zadat univerzální adresu $FE)</param>
        /// <returns>Vrací madlo na Quido. 0 = neplatné madlo</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern int qCreateQuido(IntPtr connectionstring, IntPtr deviceString);

        /// <summary>
        /// Vytvoří objekt Quida.
        /// </summary>
        /// <example>qCreateQuido("provider=SERIAL_PORT;comport=20;baudrate=115200","addr=$FE");</example>
        /// <param name="connectionString">Connection string je řetězec pro vytvoření komunikačního rozhranní, určuje komunikační kanál a jeho nastavení (sériový port, tcp, udp, nebo ftd_usb)</param>
        /// <param name="deviceString">Devicestring specifikuje parametry zařízení Quido (adresu. v případě že je na komunikačním kanálu pouze jedno zařízení, lze zadat univerzální adresu $FE)</param>
        /// <returns>Vrací madlo na Quido. 0 = neplatné madlo</returns>
        public static int qCreateQuido(string connectionString, string deviceString)
        {
            IntPtr pConnectionString = Marshal.StringToHGlobalAnsi(connectionString);
            IntPtr pDeviceString = Marshal.StringToHGlobalAnsi(deviceString);

            int result = qCreateQuido(pConnectionString, pDeviceString);

            Marshal.FreeHGlobal(pConnectionString);
            Marshal.FreeHGlobal(pDeviceString);

            return result;
        }

        /// <summary>
        /// Vytvoří objekt Quida. Použije se komunikační rozhranní již explicitně vytvořené v CommIntfDll 
        /// </summary>
        /// <param name="ciHandle">Madlo na komunikační rozhraní</param>
        /// <param name="deviceString">Devicestring specifikuje parametry zařízení Quido (adresu)</param>
        /// <returns>Vrací madlo na Quido. 0 = neplatné madlo</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern int qCreateQuidoCI(int ciHandle, IntPtr deviceString);

        /// <summary>
        /// Vytvoří objekt Quida. Použije se komunikační rozhranní již explicitně vytvořené v CommIntfDll 
        /// </summary>
        /// <param name="ciHandle">Madlo na komunikační rozhraní</param>
        /// <param name="deviceString">Devicestring specifikuje parametry zařízení Quido (adresu)</param>
        /// <returns>Vrací madlo na Quido. 0 = neplatné madlo</returns>
        public static int qCreateQuidoCI(int ciHandle, String deviceString)
        {
            IntPtr pDeviceString = Marshal.StringToHGlobalAnsi(deviceString);

            int result = qCreateQuidoCI(ciHandle, pDeviceString);
            
            Marshal.FreeHGlobal(pDeviceString);
            
            return result;
        }

        /// <summary>
        /// Vytvoří objekt Quida. Umožňuje specifikovat způsob volání událostí mezi komunikačním rozhranním a objektem quida. 
        /// </summary>
        /// <param name="connectionstring">Connection string je řetězec pro vytvoření komunikačního rozhranní, určuje komunikační kanál a jeho nastavení (sériový port, tcp, udp, nebo ftd_usb)</param>
        /// <param name="deviceString">Devicestring specifikuje parametry zařízení Quido (adresu)</param>
        /// <param name="ciEventType">Typ volání mezi komunikačním rozhraním a Quidem. (0 - sendmessage, 1 - callback, 2 - postmessage)</param>
        /// <returns>Madlo na Quido. 0 = neplatné madlo</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern int qCreateQuidoEx(IntPtr connectionstring, IntPtr deviceString, uint ciEventType);

        /// <summary>
        /// Vytvoří objekt Quida. Použití explicitně vytvořeného komunikačního rozhranní, specifikace způsobu volání událostí. viz. qCreateQuidoCI a qCreateQuidoEx. 
        /// </summary>
        /// <param name="ciHandle">Madlo na komunikační rozhraní</param>
        /// <param name="deviceString">Devicestring specifikuje parametry zařízení Quido (adresu)</param>
        /// <param name="ciEventType">Typ volání mezi komunikačním rozhraním a Quidem. (0 - sendmessage, 1 - callback, 2 - postmessage)</param>
        /// <returns>Vrací madlo na Quido. 0 = neplatné madlo</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern int qCreateQuidoCIEx(int ciHandle, IntPtr deviceString, uint ciEventType);

        /// <summary>
        /// Vrátí handle komunikačního rozhraní připojenému ke Quidu.
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <returns>Vrací madlo na komunikační rozhraní. 0 = neplatné madlo</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern int qGetQuidoCIHandle(int qHandle);

        /// <summary>
        /// Otevře komunikační kanál Quida
        /// </summary>
        /// <remarks>(otevře port, naváže tcp spojení, ... podle typu komunikačního rozhraní. nutno pro komunikaci se zařízením; </remarks>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <returns>Vrátí 0 pokud se podaří otevřít, chybový kód v případě chyby</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qOpen(int qHandle);

        /// <summary>
        /// Zavře komunikační kanál Quida
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <returns>Vrátí 0 pokud se podaří otevřít, chybový kód v případě chyby</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qClose(int qHandle);

        /// <summary>
        /// Zjistí, zda je komunikační kanál Quida otevřen 
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Opened">Proměnná, do které se uloží stav komunikačního rozhraní Quida (true = otevřené, false = zavřené)</param>
        /// <returns>Vrací 0 pokud byl stav úspěně zjištěn, jinak chybový kód.</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qIsOpened(int qHandle, out bool opened);

        /// <summary>
        /// Zruší objekt quida (včetně příslušného komunikačního rozhraní - pokud nebylo zadáno při vytvoření explicitně pomocí handlu - qCreateQuidoCI) 
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qReleaseQuido(int qHandle);

        /// <summary>
        /// Vrátí počet vstupů Quida
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <returns>Vrací počet vstupů. -1 = chyba</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qInputsCount(int qHandle);

        /// <summary>
        /// Zjistí stav vstupu. 
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Index">Index vstupu (0..počet vstupů-1)</param>
        /// <param name="State">Proměnná, do které je vrácen stav vstupu. (true = sepnut, false = rozepnut)</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qInputStateByIndex(int qHandle, int index, out bool state);

        /// <summary>
        /// Zjistí hodnotu čítače vstupu.
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Index">Index čítače vstupu (0..počet čítačů-1)</param>
        /// <param name="Value">Proměnná, do které se zapíše hodnota čítače</param>
        /// <param name="NullCounter">Zda se má čítač po načtení hodnoty vynulovat (true = vynulovat čítač)</param>
        /// <returns>Vrátí 0 pokud proběhne v pořádku, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qInputCounterValueByIndex(int qHandle, int index, out uint value, bool nullCounter);

        /// <summary>
        /// Vrátí v poli stav všech vstupů.
        /// </summary>
        /// <remarks>
        /// Do [Inputs] je třeba zadat ukazatel na první byte pole alokované na [počet vstupů] bytů. Do [Len] je třeba zadat velikost tohoto pole. 
        /// - pokud je vše v pořádku, od Inputs se vyplní stavy vstupů, do Len se vyplní aktuální velikost pole a návratová hodnota je 0 
        /// - pokud se do Inputs zadá nil, do Len se vyplní potřebná velikost pole a návratová hodnota je 0 
        /// - pokud se vyskytne chyba (stav vstupů nelze zjistit, nebo zadaná velikost Len je nedostatečná), návratová hodnota je chybový kód &lt;&gt; 0
        /// </remarks>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Inputs">Ukazatel na pole bytů, do kterého budou uloženy stavy vstupů</param>
        /// <param name="Len">Velikost pole [Inputs] v bytech. Po volání funkce je vrácen aktuální počet zapsaných bytů do pole</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qGetInputs(int qHandle, IntPtr inputs, ref int len);

        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Inputs">Pole Bytů, do kterého budou uloženy stavy vstupů</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        public static reStat qGetInputs(int qHandle, out byte[] inputs)
        {
            inputs = null;
            int Len = 0;
            reStat result = reStat.err_DLLCallFailure;
            IntPtr ptr = IntPtr.Zero;                               // pri prvnim volanim predavame nil 
            result = qGetInputs(qHandle, ptr, ref Len);             // prvni dotaz je dotaz na potrebnou velikost pole
            if (result == 0)
            {
                ptr = Marshal.AllocHGlobal(Len);                    // pole je alokovane a predavane jako pointer 
                result = qGetInputs(qHandle, ptr, ref Len);         // druhy dotaz naplni pole 
                inputs = new byte[Len];
                Marshal.Copy(ptr, inputs, 0, Len);                  // prekopirovani pointeru do vysledneho pole
                Marshal.FreeHGlobal(ptr);                           // uvolneni alokovane poameti (pointeru)
            }
            return result;
        }

        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Inputs">Pole Booleanů, do kterého budou uloženy stavy vstupů</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        public static reStat qGetInputs(int qHandle, out bool[] inputs)
        {
            inputs = null;
            byte[] InputsBytes;
            reStat result = qGetInputs(qHandle, out InputsBytes);
            if (result == 0)
            {
                inputs = new bool[InputsBytes.Length];
                for (int i = 0; i < InputsBytes.Length; i++)
                {
                    inputs[i] = Convert.ToBoolean(InputsBytes[i]);
                }
            }
            return result;
        }

        /// <summary>
        /// Vrátí v poli stav všech výstupů
        /// </summary>
        /// <remarks>
        /// Do [Outputs] je třeba zadat ukazatel na první byte pole alokované na [počet výstupů] bytů. Do [Len] je třeba zadat velikost tohoto pole. 
        /// - pokud je vše v pořádku, od [Outputs] se vyplní stavy výstupů, do Len se vyplní aktuální velikost pole a návratová hodnota je 0 
        /// - pokud se do [Outputs] zadá nil, do [Len] se vyplní potřebná velikost pole a návratová hodnota je 0 - pokud se vyskytne chyba (stav výstupů nelze zjistit, nebo zadaná velikost [Len] je nedostatečná), návratová hodnota je chybový kód &lt;&gt; 0
        /// </remarks>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Outputs">Ukazatel na pole bytů, do kterého budou uloženy stavy výstupů</param>
        /// <param name="Len">Velikost pole [Outputs] v bytech. Po volání funkce je vrácen aktuální počet zapsaných bytů do pole</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qGetOutputs(int qHandle, IntPtr outputs, ref int len);

        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Outputs">Pole bytů, do kterého budou uloženy stavy výstupů</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        public static reStat qGetOutputs(int qHandle, out byte[] outputs)
        {
            outputs = null;
            int Len = 0;
            reStat result = reStat.err_DLLCallFailure;
            IntPtr ptr = IntPtr.Zero;                               // pri prvnim volanim predavame nil 
            result = qGetOutputs(qHandle, ptr, ref Len);            // prvni dotaz je dotaz na potrebnou velikost pole
            if (result == 0)
            {
                ptr = Marshal.AllocHGlobal(Len);                    // pole je alokovane a predavane jako pointer 
                result = qGetOutputs(qHandle, ptr, ref Len);        // druhy dotaz naplni pole
                outputs = new byte[Len];
                Marshal.Copy(ptr, outputs, 0, Len);                 // prekopirovani pointeru do vysledneho pole
                Marshal.FreeHGlobal(ptr);                           // uvolneni alokovane poameti (pointeru)
            }
            return result;
        }

        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Outputs">Pole Booleanů, do kterého budou uloženy stavy výstupů</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        public static reStat qGetOutputs(int qHandle, out bool[] outputs)
        {
            outputs = null;
            byte[] OutputsBytes;
            reStat result = qGetOutputs(qHandle, out OutputsBytes);   
            if (result == 0)
            {
                outputs = new bool[OutputsBytes.Length];
                for (int i = 0; i < OutputsBytes.Length; i++)
                {
                    outputs[i] = Convert.ToBoolean(OutputsBytes[i]);
                }
            }
            return result;
        }

        /// <summary>
        /// Nastaví stav výstupu Quida podle indexu
        /// </summary>
        /// <remarks>(State:true=sepnout,false=rozepnout). pokud je návratová hodnota 0=OK, jinach chyba</remarks>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Index">Integer výstupu (0..počet výstupů - 1)</param>
        /// <param name="State">Požadovaný stav výstupu (true = sepnout, false = rozepnout)</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qSetOutput(int qHandle, int index, bool state);

        /// <summary>
        /// Nastaví stav výstupu na určitý čas.
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Index">Index výstupu (0..počet výstupů - 1)</param>
        /// <param name="State">Požadovaný stav výstupu (true = sepnout, false = rozepnout)</param>
        /// <param name="Time">Čas ve vteřinách, po kterém se stav výstupu vrátí či změní na opačný</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qSetOutputTimered(int qHandle, int index, bool state, int time);

        /// <summary>
        /// Nastaví najednou stav všech výstupů
        /// </summary>
        /// <param name="qhandle">Vrací 0 v případě úspěchu, jinak chybový kód</param>
        /// <param name="Outputs">Ukazatel na pole o velikosti [Len] bytů, obsahující požadované stavy výstupů</param>
        /// <param name="Len">Velikost pole Outputs</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qSetOutputs(int qhandle, IntPtr outputs, int len);

        /// <summary>
        /// Vrátí v poli naposledy známí stav všech vstupů - stejně jako qGetInputs, akorát neprobíhá komunikace se zařízením, ale vrací naposledy zjištěný stav. vhodné např. po události qev_InputsChange.
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Inputs">Ukazatel na pole bytů, do kterého budou uloženy stavy vstupů</param>
        /// <param name="Len">Velikost pole [Inputs] v bytech. Po volání funkce je vrácen aktuální počet zapsaných bytů do pole.</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qGetRecentInputsState(int qHandle, IntPtr inputs, ref int len);

        /// <summary>
        /// Vrátí v poli naposledy známí stav všech výstupů - stejně jako qGetOutputs, akorát neprobíhá komunikace se zařízením, ale vrací naposledy zjištěný stav.
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Outputs">Ukazatel na pole bytů, do kterého budou uloženy stavy výstupů</param>
        /// <param name="Len">Velikost pole [Outputs] v bytech. Po volání funkce je vrácen aktuální počet zapsaných bytů do pole.</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qGetRecentOutputsState(int qHandle, IntPtr outputs, ref int len);

        /// <summary>
        /// Vrátí v poli naposledy známí stav čítače vstupu - stejně jako qInputCounterValueByIndex, akorát neprobíhá komunikace se zařízením, ale vrací naposledy zjištěný stav.
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Index">Index čítače vstupu (0..počet čítačů vstupu - 1)</param>
        /// <param name="Value">Proměnná, do které je vrácena hodnota čítače.</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qGetRecentCounterSettingByIndex(int qHandle, int index, out int value);


        /// <summary>
        /// Vrátí naposledy známý stav nastavení vstupu Quida podle Indexu 
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Index">Index čítače (0..počet čítačů-1)</param>
        /// <param name="Rising">Proměnná, do které se uloží, zda náběžná hrana vstupu zvýší hodnotu čítače o 1</param>
        /// <param name="Falling">Proměnná, do které se uloží, zda sestupná hrana vstupu zvýší hodnotu čítače o 1</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qGetRecentCounterSettingByIndex(int qHandle, int index, out bool rising, out bool falling);


        /// <summary>
        /// Zjistí ze zařízení aktuální stavy vstupů, výstupů, hodnoty čítačů a jejich nastavení. Tyto hodnoty lze pak zjistit pomocí příslušných funkcí začínajících qGetRecent...
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Inputs">Zda se mají aktualizovat informace o vstupech</param>
        /// <param name="Outputs">Zda se mají aktualizovat informace o výstupech</param>
        /// <param name="Counters">Zda se mají aktualizovat informace o čítačích</param>
        /// <param name="CountersSettings">Zda se mají aktualizovat informace o nastavení čítačů</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qRefreshRecentStates(int qHandle, bool inputs, bool outputs, bool counters, bool countersSettings);

        /// <summary>
        /// Zjistí nastavení automatického vysílání 
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Value">Proměnná, do které bude uloženo, zda je aktivováno automatické oznamování změny stavu vstupů</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qGetAutoNotify(int qHandle, out bool value);

        /// <summary>
        /// Nastaví nebo zruší automatické oznamování změny stavu vstupů 
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Value">Nastavení automatického oznamování změny vstupů (true = aktivovat, false = deaktivovat)</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qGetAutoNotify(int qHandle, bool value);

        /// <summary>
        /// Zjištění nastavení čítače
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Index">Index čítače (0..počet čítačů-1)</param>
        /// <param name="Rising">Zda se při náběžné hraně zvyšuje hodnota čítače o 1</param>
        /// <param name="Falling">Zda se při sestupné hraně zvyšuje hodnota čítače o 1</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qGetCounterSetting(int qHandle, int index, out bool rising, out bool falling);

        /// <summary>
        /// Nastavení čítače (na které hrany signálu se zvyšuje jeho hodnota) 
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Index">Index čítače (0..počet čítačů-1)</param>
        /// <param name="Rising">Zda se má při náběžné hraně vstupu zvýšit hodnota čítače o 1</param>
        /// <param name="Falling">Zda se má při sestupné hraně vstupu zvýšit hodnota čítače o 1</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qSetCounterSetting(int qHandle, int index, bool rising, bool falling);

        /// <summary>
        /// Resetování zařízení 
        /// </summary>
        /// <param name="qHandle">Madlo na Quido, které bude resetováno</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qReset(int qHandle);

        /// <summary>
        /// Zjištění adresy zařízení 
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Addr">Proměnná, do které se vrátí adresa zařízení</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qGetAddress(int qHandle, out int addr);

        /// <summary>
        /// Nastavení adresy zařízení
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Addr">Nová adresa zařízení (0-253)</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qSetAddress(int qHandle, int addr);

        /// <summary>
        /// Získání užívatelských dat (16 bytů) 
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="UserData">Ukazatel místo, kam budou uloženy uživatelská data</param>
        /// <param name="Len">Vracená délka uživatelských dat</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qGetUserData(int qHandle, IntPtr userData, ref int len);

        /// <summary>
        /// Zapsání uživatelských dat (16 bytů). Uživatelská data mohou být využita libovolným způsobem, např. k uživatelské identifikaci zařízení 
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="UserData">Ukazatel na uživatelská data</param>
        /// <param name="Len">Délka zapisovaných uživatelských dat v bytech</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qSetUserData(int qHandle, IntPtr userData, int len);

        /// <summary>
        /// Zjískání výrobních dat (sériového čísla,..) zařízení 
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="ProductID">Identifikační číslo výrobku</param>
        /// <param name="SerialNumber">Sériové číslo výrobku</param>
        /// <param name="FactoryData">Factory data</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qGetFactoryInfo(int qHandle, out int productID, out int serialNumber, out uint factoryData);

        /// <summary>
        /// Zjistí aktuální nastavení PWM výstupu - ! pouze pro HW/FW upravená Quida !
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Index">Index výstupu (0..počet výstupů-1)</param>
        /// <param name="pwm">Proměnná, do které je vrácen stav výstupu. (0..100%)</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qGetOutputPWM(int qHandle, int index, out int pwm);

        /// <summary>
        /// Nastaví stav PWM výstupu Quida podle indexu (PWM = 0..100%) - ! pouze pro HW/FW upravená Quida !
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="Index">Index výstupu (0..počet výstupů-1)</param>
        /// <param name="pwm">Požadovaný stav PWM výstupu (0..100%)</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qSetOutputPWM(int qHandle, int index, int pwm);


        /// <summary>
        /// Získání teploty z externího teplotního čidla
        /// </summary>
        /// <param name="qHandle">Madlo na Quido</param>
        /// <param name="index">pořadové číslo teplotního senzoru (většinou 1)</param>
        /// <param name="temperature">Teplota ve °C x10</param>
        /// <returns>Vrací 0 v případě úspěchu, jinak chybový kód</returns>
        [DllImport(QuidoStackDll, CharSet = CharSet.Auto)]
        public static extern reStat qGetTemperature(int qHandle, int index, out int temperature);

    }
}
