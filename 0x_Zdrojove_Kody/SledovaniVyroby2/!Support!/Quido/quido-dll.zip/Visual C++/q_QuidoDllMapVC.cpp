#include "q_QuidoDllMap.h"
#include "windows.h"
#include "string.h"

const char * QDLLName = "QuidoStackDll.dll";

bool DllInited=false;
HMODULE hDll = 0;
char  DllInitMsg[128] = "";

pChar (_stdcall *DllInfo)();// QDLLName; //-- vrac� informa�n� text o knihovn�

int (_stdcall *qHandlesCount)(); //-- vrac� po�et vytvo�en�ch Quid (funkcemi qCreateQuido...); -1 = chyba
QHandle (_stdcall *qHandleByIndex)(int index); //-- vrac� handle na Quido podle indexu (0..qHandlesCount-1); 0 = neplatn� handle
int (_stdcall *ciHandlesCount)(); //-- vrac� po�et vytvo�en�ch komunika�n�ch rozhran� (a� ji� spole�n� s Quidem nebo zvl᚝ v CommIntfDll.dll); -1=chyba
QHandle (_stdcall *ciHandleByIndex)(int Index); //-- vrac� handle na komunika�n� rozhran� podle indexu (0..ciHandlesCount-1); 0=chyba

QHandle (_stdcall *qCreateQuido)(pChar connectionstring,pChar deviceString);
    //-- vytvo�i objekt Quida. vrac� handle vytvo�en�ho objektu Quida; 0 = nepovedlo se vytvo�it
    //--       connection string je �et�zec pro vytvo�en� komunika�n�ho rozhrann�, ur�uje komunika�n� kan�l a jeho nastaven� (s�riov� port, tcp, udp, nebo ftd_usb)
    //--       devicestring specifikuje parametry za��zen� Quido (adresu. v p��pad� �e je na komunika�n�m kan�lu pouze jedno za��zen�, lze zadat univerz�ln� adresu $FE)
    //   Tvorba connectionstringu : jsou to hodnoty ve tvaru "parametr=hodnota" odd�leny st�edn�kem. ur�uj� typ p�ipojen�
    //          nejd�le�it�j��m parametrem je "provider", ur�uje typ komunika�n�ho kan�lu. m��e to b�t SERIAL_PORT, TCP_CLIENT, UDP_CLIENT nebo FTD_USB
    //          ka�d� kan�l pak m��e m�t dal�� parametry. SERIAL_PORT (comport=��slo portu;baudrate=rychlost - nemus� b�t zad�no), TCP_CLIENT(host=ip adresa za��zen�;port=tcp port za��zen�), UDP_CLIENT(stejn� jako TCP), FTD_USB(index=po�adov� ��slo za��zen�; nebo device=��st n�zvu za��zen�; nebo serial_number=s�riov� ��slo za��zen�; nebo vid=vid;pid=pid; nebo nemus� m�t ��dn� parametr, vezme se prvn� p�ipojen� za��zen� typu FTD_USB
    //          p��klady: "provider=SERIAL_PORT;comport=1", "provider=TCP_CLIENT;host=192.168.1.254;port=10001", "provider=UDP_CLIENT;host=192.168.1.254;port=10001", "provider=FTD_USB;device=Quido"
    //   Tvorba devicestringu: p�. "addr=12", "addr=$FE" ($ - znamen� ��slo je zad�no v hexa, $FE=univerz�ln� adresa)

QHandle (_stdcall *qCreateQuidoCI)(QHandle ciHandle,pChar devicestring); //-- Vytvo�� objekt Quida, pou�ije se komunika�n� rozhrann� ji� explicitn� vytvo�en� v CommIntfDll (ciHandle)
QHandle (_stdcall *qCreateQuidoEx)(pChar connectionstring,pChar deviceString, unsigned int ciEventType); //-- umo��uje specifikovat zp�sob vol�n� ud�lost� mezi komunika�n�m rozhrann�m a objektem quida  - ciEventType (0 - sendmessage, 1 - callback, 2 - postmessage). nedoporu�uje se pou��vat, pokud k tomu nen� d�vod
QHandle (_stdcall *qCreateQuidoCIEx)(QHandle ciHandle,pChar devicestring,unsigned int ciEventType); //-- pou�it� explicitn� vytvo�en�ho komunika�n�ho rozhrann�, specifikace zp�sobu vol�n� ud�lost�

QHandle (_stdcall *qGetQuidoCIHandle)(QHandle qHandle);  //-- vr�t� handle komunika�n�ho rozhran� p�ipojen�mu ke Quidu

reStat (_stdcall *qOpen)(QHandle qHandle); //-- otev�e komunika�n� kan�l Quida (otev�e port, nav�e tcp spojen�, ... podle typu komunika�n�ho rozhran�; nutno pro komunikaci se za��zen�m; vr�t� 0 pokud OK, chybov� k�d v opa�n�m p��pad� (plat� obecn� pro n�vratov� typ reStat (integer))
reStat (_stdcall *qClose)(QHandle qHandle); //-- zav�e komunika�n� kan�l Quida; vr�t� 0 pokud OK, chybov� k�d v opa�n�m p��pad�
reStat (_stdcall *qIsOpened)(QHandle qHandle,longbool & Opened); //-- zjist�, zda je komunika�n� kan�l quida otev�en
reStat (_stdcall *qReleaseQuido)(QHandle qHandle); //-- zru�� objekt quida (v�etn� p��slu�n�ho komunika�n�ho rozhran� - pokud nen� zad�no p�i vytvo�en� explicitn� pomoc� handlu - qCreateQuidoCI)

int (_stdcall *qInputsCount)(QHandle qHandle); //-- vr�t� po�et vstup� Quida; -1=chyba
int (_stdcall *qOutputsCount)(QHandle qHandle); //-- vr�t� po�et v�stup� Quida; -1=chyba
int (_stdcall *qInputCountersCount)(QHandle qHandle); //-- vr�t� po�et ��ta�� vstup�; -1=chyba; standardn� po�et ��ta�� vstup�=po�et vstup�, maxim�ln� v�ak 60

reStat (_stdcall *qInputStateByIndex)(QHandle qHandle,int Index,longbool & State);//-- vr�t� do State stav vstupu podle indexu (0..po�et vstup�-1) (true=je na vstupu nap�t�, false=neni); n�vratov� hodnota: 0-ok, jinak chyba
reStat (_stdcall *qOutputStateByIndex)(QHandle qHandle,int Index,longbool & State);//-- vr�t� do State stav v�stupu podle indexu (0..po�et vstup�-1)  (true=je na vstupu nap�t�, false=neni); n�vratov� hodnota: 0-ok, jinak chyba
reStat (_stdcall *qInputCounterValueByIndex)(QHandle qHandle,int Index,unsigned int & Value,longbool NullCounter); //-- vr�t� do Value hodnotu ��ta�e vstupu podle indexu (0..po�et ��ta��-1); pokud je NullCounter true, ��ta� se z�hy vynuluje

reStat (_stdcall *qGetInputs)(QHandle qHandle,bool * Inputs, int & Len); //-- vr�t� v poli stav v�ech vstup�. do inputs je t�eba zadat ukazatel na pole alokovan� na (po�et vstup�) byt�; do Len je t�eba zadat velikost tohoto pole; p�i pou�it� klasick�ho pole v delphi (array of boolean) je t�eba zadat ukazatel na prvn� prvek pole (@pole[0]);
             //---  pokud je v�e v po��dku, od Inputs se vypln� stavy vstup�, do Len se vypln� aktu�ln� velikost pole a n�vratov� hodnota je 0
             //---  pokud se do Inputs zad� nil, do Len se vypln� pot�ebn� velikost pole a n�vratov� hodnota je 0
             //---  pokud se vyskytne chyba (stav vstup� nelze zjistit, nebo zadan� velikost Len je nedostate�n�), n�vratov� hodnota je chybov� k�d <> 0
reStat (_stdcall *qGetOutputs)(QHandle qHandle,bool * Outputs,int & Len);//-- vr�t� v poli stav v�ech v�stup�. princip jako u qGetInputs

reStat (_stdcall *qSetOutput) (QHandle qHandle,int Index, longbool State);//-- Nastav� stav v�stupu Quida podle indexu (State:true=sepnout,false=rozepnout). pokud je n�vratov� hodnota 0=OK, jinach chyba
reStat (_stdcall *qSetOutputTimered)(QHandle qHandle,int Index,bool State,int Time);//-- Nastav� stav v�stupu na ur�it� �as (Time=�as ve vte�in�ch).pokud je n�vratov� hodnota 0=OK, jinach chyba

reStat (_stdcall *qSetOutputs)(QHandle qhandle,bool * Outputs, int Len);//-- Nastav� najednou stav v�ech v�stup�. do outputs se zad� pole boolen� (1 bytov�ch). Len ur�uje velikost pole; pokud je n�vratov� hodnota 0=OK, jinach chyba

reStat (_stdcall *qGetRecentInputsState)(QHandle qHandle, bool * Inputs,int & Len); //-- vr�t� v poli naposledy zn�m� stav vstup� - stejn� jako qGetInputs, akor�t se nedotazuje p��mo za��zen�, ale vrac� naposledy zji�t�n� stav. vhodn� nap�. po ud�losti qev_InputsChange.
reStat (_stdcall *qGetRecentOutputsState)(QHandle qHandle,bool * Outputs, int & Len); //-- vr�t� v poli naposledy zn�m� stav v�stup� - procuje jako qGetRecentInputsState

reStat (_stdcall *qGetRecentInputByIndex)(QHandle qHandle,int Index,longbool & State); //-- vr�t� naposledy zn�m� stav vstupu Quida podle Indexu (jako qGetInputStateByIndex, akor�t se nedotazuje p��mo za��zen�, ale vrac� naposledy zji�t�n� stav
reStat (_stdcall *qGetRecentOutputByIndex)(QHandle qHandle,int Index,longbool & State);//-- vr�t� naposledy zn�m� stav v�stupu Quida podle Indexu. pracuje jako qGetRecentInputByIndex
reStat (_stdcall *qGetRecentInputCounterByIndex)(QHandle qHandle,int Index,int & Value); //-- vr�t� naposledy zn�m� stav ��ta�e vstupu Quida podle Indexu.
reStat (_stdcall *qGetRecentCounterSettingByIndex)(QHandle qHandle,int Index,longbool & Rising,longbool & Falling); //-- vr�t� naposledy zn�m� stav nastaven� vstupu Quida podle Indexu

reStat (_stdcall *qRefreshRecentStates)(QHandle qHandle,longbool Inputs,longbool Outputs,longbool Counters,longbool CounterSettings);

reStat (_stdcall *qGetAutoNotify )(QHandle qHandle, longbool & Value); //-- vr�t� do Value zda je aktivov�no automatick� oznamov�n� zm�ny stavu vstup� (pokud je registrov�no oznamov�n� pomoc� qRegisterMsgNotifications nebo qRegisterCallBackNotifications;
reStat (_stdcall *qSetAutoNotify)(QHandle qHandle, longbool Value); //-- nastav� nebo zru�� automatick� oznamov�n� zm�ny stavu vstup� (true=nastavit, false=zru�it)

reStat (_stdcall *qSetCounterSetting ) (QHandle qHandle, int Index,longbool Rising,longbool Falling); //-- Nastaven� ��ta�e (na kter� hrany sign�lu se inkrementuje - rising=n�b�n�, falling=sestupn�)
reStat (_stdcall *qGetCounterSetting)(QHandle qHandle,int Index,longbool & Rising,longbool & Falling); //-- Zji�t�n� nastaven� ��ta�e

reStat (_stdcall *qRegisterMsgNotifications)(QHandle Handle,hwnd WHandle,unsigned int Msg,longbool blocking); //-- registruje zas�l�n� ud�lost� Quida pomoc� Windows zpr�v (Otev�en� a zav�en� komunika�n�ho kan�lu, zm�ny stav� vstup�, ...). zad�v� se hWnd okna, kter� zpr�vu p�ij�m� a identifikaci zpr�vy, kter� je zas�l�na. v parametru zpr�vy WParam je zasl�n handle Quida, kter� ji zas�l�, v LParamLo je zasl�n typ ud�losti, LParamHi p��padn� dodate�n� parametr
reStat (_stdcall *qUnregisterMsgNotifications)(QHandle Handle);  //-- ru�� zas�l�n� ud�lost� Quida pomoc� Windows zpr�v
reStat (_stdcall *qRegisterCallBackNotifications)(QHandle Handle, QHandleNotificationEvent CallBackEntryPoint, unsigned int CallBackID); //-- registruje zas�l�n� ud�lost� Quida pomoc� vol�n� callbackov� funkce form�tu QHandleNotificationEvent
reStat (_stdcall *qUnregisterCallBackNotifications )(QHandle Handle);//-- ru�� zas�l�n� ud�lost� Quida pomoc� callbackov� funkce

reStat (_stdcall *qInfo) (QHandle qHandle,pChar Info,int & Len); //-- vrac� textovou identifikaci za��zen� (Quida)
reStat (_stdcall *qReset)(QHandle qHandle); //-- Resetov�n� za��zen�
reStat (_stdcall *qGetAddress)(QHandle qHandle,int & Addr); //-- zji�t�n� adresy za��zen�
reStat (_stdcall *qSetAddress)(QHandle qHandle, int & Addr); //-- nastaven� adresy za��zen� (0-253)
reStat (_stdcall *qGetUserData)(QHandle qHandle,pChar UserData, int & Len); //-- z�sk�n� u��vatelsk�ch dat (16 byt�)
reStat (_stdcall *qSetUserData) (QHandle qHandle,pChar UserData,int Len); //-- nastaven� u�ivatelsk�ch dat (16 byt�)
reStat (_stdcall *qGetFactoryInfo)(QHandle qHandle,int & ProductID,int & SerialNumber,unsigned int & FactoryData); //-- zj�sk�n� v�robn�ch dat (s�riov�ho ��sla,..) za��zen�


reStat (_stdcall *ciGetConnectionStringDlg)(pChar OutConnStr, int & Len,longbool & OKReturn,pChar DefaultValue,pChar Caption); //-- Vyvol� dialogov� okno pro vytvo�en� p�ipojovac�ho �et�zce (connection string). Vrac� hodnotu<>0, pokud nastala chyba
                        //-- OutConStr:sem je vr�cen connectionstring, Len:velikost bufferu OutConStr, OKReturn:vr�ceno true, pokut bylo stisknuto OK, DefaultValue:p��padn� p�ednastaven� v�choz�ho connectionstringu, Caption: vlastn� titulek dialogu

reStat (_stdcall *qSndRcvSpin97)(QHandle qHandle,unsigned char Inst,void * Data,int DataLen,
                  unsigned char & RcvAck,void * RcvData,int & RcvDataLen, int MaxTimeOut);
                  //-- Za�le spinel paket, zadan� instrukc� Inst a daty Data (velikosti DataLen) a �ek� na odpov�� (maxim�ln� MaxTimeOut milisekund)
                  // Pokud p�ijde odpov��, n�vratov� hodnota je 0, do bufferu RcvData o velikosti RcvDataLen se zap�ou vr�cen� data spinel paketu a v RcvDataLen se vr�t� aktu�ln� velikost dat.
                  // RcvAck vr�t� k�d odpov�di (0 = OK)
                  // Pokud se paket neode�le, nebo se nevr�t� odpov��, nebo vznikne jin� chyba, n�vratov� hodnota <> 0

reStat (_stdcall *LastError)(); //-- vr�t� chybov� k�d naposledy volan� funkce. 0=funkce prob�hla v po��dku
reStat (_stdcall *LastErrorText)(pChar Text,int & Size); //-- vr�t� text chyby naposledy volan� funkce

bool Map(void ** ProcAddr,const char * Name)
{
    *ProcAddr=(void *)GetProcAddress((HMODULE)hDll,Name);
    if (!*ProcAddr){
     strcpy(DllInitMsg,"Can not map function ");
     strcat(DllInitMsg,Name);
     strcat(DllInitMsg," in ");
     strcat(DllInitMsg,QDLLName);
     return false;
    }
    return true;
}


bool QDllOK(){
  if (DllInited){
    return hDll!=0;
  }else{
    try{
      DllInited=true;
      DllInitMsg[0]=0;
      hDll = LoadLibraryA(QDLLName);
      if (hDll==0){
        strcpy(DllInitMsg,"Can't load library ");
        strcat(DllInitMsg,QDLLName);
        strcat(DllInitMsg,".");
        return false;
      }
      //Namapov�n� funkc�
      if (!Map((void **)&DllInfo,"DllInfo")) return false;
	  if (!Map((void **)&ciHandlesCount,"ciHandlesCount")) return false;
      if (!Map((void **)&ciHandleByIndex,"ciHandleByIndex")) return false;
      if (!Map((void **)&qHandlesCount,"qHandlesCount")) return false;
      if (!Map((void **)&qHandleByIndex,"qHandleByIndex")) return false;
      if (!Map((void **)&qCreateQuidoCI,"qCreateQuidoCI")) return false;
      if (!Map((void **)&qCreateQuido,"qCreateQuido")) return false;
      if (!Map((void **)&qCreateQuidoCIEx,"qCreateQuidoCIEx")) return false;
      if (!Map((void **)&qCreateQuidoEx,"qCreateQuidoEx")) return false;
      if (!Map((void **)&qGetQuidoCIHandle,"qGetQuidoCIHandle")) return false;
      if (!Map((void **)&qOpen,"qOpen")) return false;
      if (!Map((void **)&qClose,"qClose")) return false;
      if (!Map((void **)&qIsOpened,"qIsOpened")) return false;
      if (!Map((void **)&qReleaseQuido,"qReleaseQuido")) return false;
      if (!Map((void **)&qInputsCount,"qInputsCount")) return false;
      if (!Map((void **)&qOutputsCount,"qOutputsCount")) return false;
      if (!Map((void **)&qInputCountersCount,"qInputCountersCount")) return false;
      if (!Map((void **)&qInputStateByIndex,"qInputStateByIndex")) return false;
      if (!Map((void **)&qOutputStateByIndex,"qOutputStateByIndex")) return false;
      if (!Map((void **)&qInputCounterValueByIndex,"qInputCounterValueByIndex")) return false;
      if (!Map((void **)&qGetInputs,"qGetInputs")) return false;
      if (!Map((void **)&qGetOutputs,"qGetOutputs")) return false;
      if (!Map((void **)&qSetOutput,"qSetOutput")) return false;
      if (!Map((void **)&qSetOutputTimered,"qSetOutputTimered")) return false;
      if (!Map((void **)&qSetOutputs,"qSetOutputs")) return false;
      if (!Map((void **)&qGetRecentInputsState ,"qGetRecentInputsState")) return false;
      if (!Map((void **)&qGetRecentOutputsState,"qGetRecentOutputsState")) return false;
      if (!Map((void **)&qGetRecentInputByIndex,"qGetRecentInputByIndex")) return false;
      if (!Map((void **)&qGetRecentOutputByIndex,"qGetRecentOutputByIndex")) return false;
      if (!Map((void **)&qGetRecentInputCounterByIndex,"qGetRecentInputCounterByIndex")) return false;
      if (!Map((void **)&qGetRecentCounterSettingByIndex,"qGetRecentCounterSettingByIndex")) return false;
      if (!Map((void **)&qRefreshRecentStates,"qRefreshRecentStates")) return false;
      if (!Map((void **)&qGetAutoNotify,"qGetAutoNotify")) return false;
      if (!Map((void **)&qSetAutoNotify,"qSetAutoNotify")) return false;
      if (!Map((void **)&qRegisterMsgNotifications,"qRegisterMsgNotifications")) return false;
      if (!Map((void **)&qUnregisterMsgNotifications ,"qUnregisterMsgNotifications")) return false;
      if (!Map((void **)&qRegisterCallBackNotifications,"qRegisterCallBackNotifications")) return false;
      if (!Map((void **)&qUnregisterCallBackNotifications,"qUnregisterCallBackNotifications")) return false;
      if (!Map((void **)&qInfo,"qInfo")) return false;
      if (!Map((void **)&qReset,"qReset")) return false;
      if (!Map((void **)&qGetAddress,"qGetAddress")) return false;
      if (!Map((void **)&qSetAddress,"qSetAddress")) return false;
      if (!Map((void **)&qGetUserData,"qGetUserData")) return false;
      if (!Map((void **)&qSetUserData,"qSetUserData")) return false;
      if (!Map((void **)&qGetFactoryInfo,"qGetFactoryInfo")) return false;

      if (!Map((void **)&LastError,"LastError")) return false;
      if (!Map((void **)&LastErrorText,"LastErrorText")) return false;
      if (!Map((void **)&ciGetConnectionStringDlg,"ciGetConnectionStringDlg")) return false;
      if (!Map((void **)&qGetCounterSetting,"qGetCounterSetting")) return false;
      if (!Map((void **)&qSetCounterSetting,"qSetCounterSetting")) return false;

      if (!Map((void **)&qSndRcvSpin97,"qSndRcvSpin97")) return false;

      return true;
    }
    catch(...){
        if (hDll!=0){
           FreeLibrary(hDll);
           hDll = 0;
        }
        if (!DllInitMsg[0]) strcpy(DllInitMsg,"Fatal error during Dll loading.");
        return false;
    }
  }
}


pChar QDllInitMsg(){
  return DllInitMsg;
}
void QDTestInit(){
  if (!QDllOK())
   throw DllInitMsg;
}




