(*
  UserInterface - Zaobalen� funkc� knihovny CommIntfDll.dll
  Vytvo�eno pro Delphi 7

  Vydavatel :  Papouch s.r.o. - http://www.papouch.com/
  Autor     :  Martin Z�me�n�k zamecnik@papouch.com

  popis     : objekt umo��uje komunikaci nejen se za��zen�mi firmy papouch s.r.o. p�es s�riov� port, usb a ethernet (TCP nebo UDP)
              zaobaluje funkce knihovny CommIntfDll do objektu.

  Pozn�mky  : k pou�it� je pot�eba knihovna CommIntfDll.dll, a unita mapuj�c� funkce uci_IDLLMapD.pas
              v p��pad� pou�it� pro USB jsou pot�eba t� nainstalovan� ovlada�e FTD direct drivers a knihova FTD2XX.dll, nebo nainstalovan� virtu�ln� s�riov� port

*)
unit uUserInterface;

interface
uses uci_IDllMapD,Windows,Messages,sysutils,classes;
//--- Registered messages
const
      RegMsg = WM_USER + 67;


type

  TUserCommunicationInterface = class  //-- Objekt komunika�n�ho rozhran�
  private
    fonDataRcv:TNotifyEvent;
    fonOpen:TNotifyEvent;
    fonClose:TNotifyEvent;
  protected
    fHandle:THandle;
    MyWnd:HWND;
    function GetHandle:THandle;
    function GetProvider:string;
    procedure WinProc(var Msg:TMessage);
    function GetOnOpen:TNotifyEvent;
    procedure SetOnOpen(const Value:TNotifyEvent);
    procedure DoOnOpen;
    function GetOnClose:TNotifyEvent;
    procedure SetOnClose(const Value:TNotifyEvent);
    procedure DoOnClose;
    procedure SetOnDataRcv(const Value:TNotifyEvent);
    function GetOnDataRcv:TNotifyEvent;
    procedure DoOnDataRcv;
    function GetActive: Boolean;
    procedure SetActive(const Value:Boolean); virtual;
    function GetValid:Boolean;
    procedure SetValid(const Value: Boolean);
  public
    constructor Create(ConnectionString:string);  //-- Konstruktor, p�ed�v� se p�ipojovac� �et�zec
    //--       connection string je �et�zec pro vytvo�en� komunika�n�ho rozhrann�, ur�uje komunika�n� kan�l a jeho nastaven� (s�riov� port, tcp, udp, nebo ftd_usb)
    //   Tvorba connectionstringu : jsou to hodnoty ve tvaru "parametr=hodnota" odd�leny st�edn�kem. ur�uj� typ p�ipojen�
    //          nejd�le�it�j��m parametrem je "provider", ur�uje typ rozhrann�. m��e to b�t SERIAL_PORT, TCP_CLIENT, UDP_CLIENT nebo FTD_USB
    //          ka�d� kan�l pak m��e m�t dal�� parametry. SERIAL_PORT (comport=��slo portu;baudrate=rychlost - nemus� b�t zad�no), TCP_CLIENT(host=ip adresa za��zen�;port=tcp port za��zen�), UDP_CLIENT(stejn� jako TCP),
    //                                                    FTD_USB(index=po�adov� ��slo za��zen�; nebo device=��st n�zvu za��zen�; nebo serial_number=s�riov� ��slo za��zen�; nebo vid=vid;pid=pid; nebo nemus� m�t ��dn� parametr, vezme se prvn� p�ipojen� za��zen� typu FTD_USB
    //          p��klady: "provider=SERIAL_PORT;comport=1", "provider=TCP_CLIENT;host=192.168.1.254;port=10001", "provider=UDP_CLIENT;host=192.168.1.254;port=10001", "provider=FTD_USB;device=Quido"

    destructor Destroy;override;   //-- Destruktor
    property Handle:THandle read GetHandle;  //-- Origin�ln� Handle komunika�n�ho rozhran�
    property Provider:string read GetProvider;  //-- Typ rozhran� (SERIAL_PORT, TCP_CLIENT, UDP_CLIENT nebo FTD_USB)

    property OnOpen:TNotifyEvent read GetOnOpen write SetOnOpen; //-- Ud�lost - p�i otev�en� komunika�n�ho kan�lu rozhran�
    property OnClose:TNotifyEvent read GetOnClose write SetOnClose; //-- Ud�lost - p�i zav�en� komunika�n�ho kan�lu rozhran�
    property OnDataRcv:TNotifyEvent read GetOnDataRcv write SetOnDataRcv; //-- P�i p��jmu p��choz�ch dat

    function GetConfiguration:String; //-- Vr�t� kofigura�n� �et�zec

    function GetId: String; //-- Vr�t� identifikaci rozhran�
    function GetDescription:string; //-- Vr�ti popis rohran�

    property Active:boolean read GetActive write setActive; //-- Lze zjistit �i nastavit zda je rozhran� otev�eno �i zav�eno

    function Open: Boolean; //otev�e komunika�n� rozhran� (otev�e s�riov� port, nav�e tcp spojen�, ... podle typu komunika�n�ho rozhran�; nutno p�ed zapo�et�m komunikace;
    function Close(Force: Boolean=true): Boolean;  //zav�e komunika�n� rozhran�

    function ReadString: String; //P�e�te p�ijat� data
    function InBuffUsed: Cardinal; //Velikost p�ijat�ch dat (v bytech)
    function WriteString(str: String): Cardinal; //Ode�le data

    function SndRcv(const Data:string;MaxTimeOut:integer=500):string;
    //-- Ode�le data a �ek� na odpov��. n�vratov� hodnota = p�ijat� odpov��
    function SndRcvSpin97(var Adr:byte;var Sig:byte;var Inst_Ack:byte;var Data:string;MaxTimeOut:integer=500):boolean;
         //-- Ode�le Spinel paket a p�ijme odpov��. Vyslan� paked se slo�� z adresy(Adr), podpisu(Sig),instrukce(Inst_Ack) a Dat(Data)
         // Pokud byla odpov�� p�ijata, n�vratov� hodnota je true, nastav� p�ijatou adresu(Adr), podpis(Sig) a k�d odpov�di Ack(Inst_Ack) a data se zm�n� na p�ijat� Data
         // z vr�cen� hodnoty Ack (v Inst_Ack) lze ur�it, zda byl p��kaz �sp�n� vykon�n.
         // Pokud nebyla odpov�� p�ijata, n�vratov� hodnota je false.

    function ExecuteConfigDialog:Boolean; //Spust� konfigura�n� dialog podle typu rozhran�
    function ConfigDialogAvailable:Boolean; //Zjist�, zda rozhran� obsahuje konfigura�n� dialog

    class function ConnectionStringDlg(var ConnectionString:string;Caption:string=''):boolean; //-- Metoda t��dy, kter� vyvol� dialog pro vytvo�en� p�ipojovac�ho �et�zce a vr�t� ho v parametru. vrac� true, pokud bylo stisknuto OK
  end;

implementation

function TUserCommunicationInterface.Close(Force: Boolean): Boolean;
begin
  _ciClose(fHandle);
end;

function TUserCommunicationInterface.ConfigDialogAvailable: Boolean;
begin
  result:=ciConfigDialogAvailable(fHandle);
end;

class function TUserCommunicationInterface.ConnectionStringDlg(
  var ConnectionString: string; Caption: string): boolean;
begin
  if Caption='' then Caption:='Connection string';
  result:=_GetConnectionStringDlg(ConnectionString,Caption);
end;

constructor TUserCommunicationInterface.Create(ConnectionString: string);
begin
   if not CIDllOK then raise Exception.Create(CIDllInitMsg);
   inherited Create;
   MyWnd := AllocateHWnd(WinProc);
   fHandle := _ciCreate(ConnectionString,MyWnd,RegMsg);
   //ciRegisterNotifications(fHandle,MyWnd,RegMsg);
end;

destructor TUserCommunicationInterface.Destroy;
begin
 if fHandle<>0 then
 begin
  //ciClose(fHandle);
  ciRelease(fHandle);
 end;
 DeallocateHWnd(MyWnd);
 inherited;
end;

procedure TUserCommunicationInterface.DoOnClose;
begin
   if assigned(fOnClose) then fOnClose(self);
end;

procedure TUserCommunicationInterface.DoOnDataRcv;
begin
  if assigned(fOnDataRcv) then fonDataRcv(self);
end;

procedure TUserCommunicationInterface.DoOnOpen;
begin
  if assigned(fOnOpen) then fOnOpen(self);
end;

function TUserCommunicationInterface.ExecuteConfigDialog: Boolean;
begin
  result:=ciExecuteConfigDialog(fHandle);
end;

function TUserCommunicationInterface.GetActive: Boolean;
begin
  result:=_ciIsActive(fHandle);
end;

function TUserCommunicationInterface.GetConfiguration: String;
begin
end;

function TUserCommunicationInterface.GetDescription: string;
begin
  result:= _ciGetDescription(fHandle);
end;

function TUserCommunicationInterface.GetHandle: THandle;
begin
  result:=fHandle;
end;

function TUserCommunicationInterface.GetId: String;
begin
  result:=_ciGetID(fHandle);
end;

function TUserCommunicationInterface.GetOnClose: TNotifyEvent;
begin
  result:=fonClose;
end;

function TUserCommunicationInterface.GetOnDataRcv: TNotifyEvent;
begin
  result:=fonDataRcv;
end;

function TUserCommunicationInterface.GetOnOpen: TNotifyEvent;
begin
 result:=fonOpen;
end;

function TUserCommunicationInterface.GetProvider: string;
begin
  result:=_ciGetProvider(fHandle);
end;

function TUserCommunicationInterface.GetValid: Boolean;
begin
  result:=_ciGetValid(fHandle);
end;

function TUserCommunicationInterface.InBuffUsed: Cardinal;
begin
  result:= ciReadLength(fHandle);
end;

function TUserCommunicationInterface.Open: Boolean;
begin
 _ciOpen(fHandle);
end;

function TUserCommunicationInterface.ReadString: String;
begin
  result := _ciRead(fHandle);
end;

procedure TUserCommunicationInterface.SetActive(const Value: Boolean);
begin
  if Active then Close(true) else Open;
end;

procedure TUserCommunicationInterface.SetOnClose(
  const Value: TNotifyEvent);
begin
 fonClose := Value;
end;

procedure TUserCommunicationInterface.SetOnDataRcv(
  const Value: TNotifyEvent);
begin
  fonDataRcv := Value;
end;

procedure TUserCommunicationInterface.SetOnOpen(const Value: TNotifyEvent);
begin
  fOnopen := Value;
end;

procedure TUserCommunicationInterface.SetValid(const Value: Boolean);
begin
  _ciSetValid(fHandle,Value);
end;

function TUserCommunicationInterface.SndRcv(const Data: string;
  MaxTimeOut: integer): string;
begin
 result:=_SndRcv(fHandle,Data,MaxTimeOut);
end;

function TUserCommunicationInterface.SndRcvSpin97(var Adr, Sig,
  Inst_Ack: byte; var Data: string; MaxTimeOut: integer): boolean;
begin
 result:=_SndRcvSpin97(fHandle,Adr,Sig,Inst_Ack,Data,MaxTimeOut);
end;

procedure TUserCommunicationInterface.WinProc(var Msg: TMessage);
begin
  if (Msg.Msg = RegMsg)and(Msg.WParam = fHandle) then
  begin
    case Msg.LParam of
      ciev_Open : DoOnOpen;
      ciev_Close : DoOnClose;
      ciev_DataRcv: DoOnDataRcv;
    end;
  end;
end;

function TUserCommunicationInterface.WriteString(str: String): Cardinal;
begin
  result:=length(str);
  _ciWrite(fHandle,str);
end;


end.
