(*
  Quido - zaobalen� funkc� knihovny QuidoStackDll.dll
  Vytvo�eno pro Delphi 7

  Vydavatel :  Papouch s.r.o. - http://www.papouch.com/
  Autor     :  Martin Z�me�n�k zamecnik@papouch.com

  popis     : objekt umo��uje komunikaci se za��zen�mi Quido p�es libovoln� rozhran�.
              umo��uje p�es spinel protokol z�kladn� nastaven� a ovl�d�n� vstup� a v�stup� Quida.
              zaobaluje funkce knihovny QuidoStackDll do objektu.

  Pozn�mky  : k pou�it� jsou pot�eba knihovny CommIntfDll.dll, QuidoStackDll.dll a unita mapuj�c� funkce q_QuidoDllMapD.pas
              v p��pad� pou�it� pro USB Quida jsou pot�eba t� nainstalovan� ovlada�e FTD direct drivers a knihova FTD2XX.dll, nebo nainstalovan� virtu�ln� s�riov� port

*)
unit uo_Quido;

interface
uses  q_QuidoDllMapD, classes;
type
  TIOChangeEvent = procedure(Sender:TObject;IOIndex:integer;OldState:boolean;NewState:boolean) of object;
  TQuidoNotifyEvent = procedure(Sender:TObject;Event:word;Param:word) of object;
  TQuido = class
    private
      qHandle:THandle;
      FOnOutputChange: TIOChangeEvent;
      FOnInputChange: TIOChangeEvent;
      FOnInputsChange: TNotifyEvent;
      FOnOutputsChange: TNotifyEvent;
      FOnClose: TNotifyEvent;
      FOnOpen: TNotifyEvent;
      FOnQuidoEvent: TQuidoNotifyEvent;
      procedure SetOnClose(const Value: TNotifyEvent);
      procedure SetOnInputChange(const Value: TIOChangeEvent);
      procedure SetOnInputsChange(const Value: TNotifyEvent);
      procedure SetOnOpen(const Value: TNotifyEvent);
      procedure SetOnOutputChange(const Value: TIOChangeEvent);
      procedure SetOnOutputsChange(const Value: TNotifyEvent);
      function GetInutState(index: integer): boolean;
      function GetOutputState(index: integer): boolean;
      function GetRecentInputState(index: integer): boolean;
      function GetRecentOutputState(index: integer): boolean;
      function GetAutoInputNotification:boolean;
      procedure SetAutoInputNotification(const Value: boolean);
      procedure SetOutputState(index: integer; const Value: boolean);
      procedure SetOnQuidoEvent(const Value: TQuidoNotifyEvent);
      function GetActive: boolean;
      procedure SetActive(const Value: boolean);
      function GetRecentCounterValue(index: integer): cardinal;
    protected
      procedure OnEvent(qHandle:THandle;Event:word;Param:word);
    public //---------------
      constructor Create(ConnectionString:AnsiString;QuidoParams:AnsiString='ADDR=$FE');overload; //-- vytvo�en�: connectionString=parametry komunika�n�ho spojen�;QuidoParams=parametry quida (adresa)
      class function CreateByDlg(QuidoParams:AnsiString='ADDR=$FE';DefaultConnStr:AnsiString=''):TQuido; //-- vytvo�en� pomoc� dialogu: connection string se vytvo�� pomoc� dialogu. pokud se v dialogu stiskne storno, n�vratov� hodnota je NIL.
      destructor Destroy;override;
      procedure Open; //-- otev�e spojen� s quidem
      procedure Close; //-- zav�e spojen� s quidem
      property Active:boolean read GetActive write SetActive; //-- Otev�eno nebo zav�eno spojen�
      function DeviceInfo:AnsiString; //-- Informa�n� zpr�va quida
      function InputsCount:integer; //-- Po�et vstup�
      function OutputsCount:integer; //-- Po�et v�stup�
      function InputCountersCount:integer; //-- Po�et ��ta�� vstup�
      property InputState[index:integer]:boolean read GetInutState; //-- stavy jednotliv�ch vstup� (�te p��mo ze za��zen�)
      property OutputState[index:integer]:boolean read GetOutputState write SetOutputState; //-- zji�t�n� �i nastaven� jednotliv�ch v�stup� (�te �i zapisuje p��mo z/do za��zen�)
      procedure SetOutputStateTimed(index:integer;State:boolean;TimeSec:integer=0); //-- Nastaven� v�stupu na ur�it� �asov� interval (0 = bez �asov�ho intervalu)
      property RecentInputState[index:integer]:boolean read GetRecentInputState; //-- Posledn� zn�m� stav vstup� - (nezji��uje p��mo ze za��zen�)
                //-- Tyto hodnoty se aktualizuj� pomoc� metod RefreshInputs, RefreshCecentStates, pou�it�m vlastnosti InputState, nebo p�ijet�m automaticky vyslan� instrukce
      property RecentOutputState[index:integer]:boolean read GetRecentOutputState; //-- Posledn� zn�m� stav v�stup�
                //-- Tyto hodnoty se aktualizuj� pomoc� metod refreshOutputs,RefreshRecentStates nebo pout�t�m vlastnosti OutputState
      property RecentCounterValue[index:integer]:cardinal read GetRecentCounterValue; //-- Posledn� zn�m� hodnota ��ta�� vstup�
      procedure GetRecentCounterSetting(index:integer;var Rising,Falling:boolean); //-- Posledn� zn�m� nastaven� ��ta��
      function GetInputCounterValue(index: integer;NullCounter:boolean=false): cardinal; //-- Zjist� hodnotu ��ta�e vstupu, mo�nost n�sledn�ho vynulov�n�
      procedure RefreshRecentStates(Inputs:boolean = true;Outputs:boolean=true;Counters:boolean=true;CounterSettings:boolean=true);
                //-- Na�te aktu�ln� hodnoty stav� vstup�, v�stup�, ��ta�� a jejich nastaven�.
      procedure RefreshInputs(Wait:boolean=true); //-- Na�te aktu�ln� hodnoty vstup� ze za��zen�
      procedure RefreshOutputs(Wait:boolean=true); //-- Na�te aktu�ln� hodnoty v�stup� ze za��zen�
      property AutoInputNotification:boolean read GetAutoInputNotification write SetAutoInputNotification;
               //-- Nastav� �i zjist� stav automatick�ho vys�l�n� zm�ny vstup�
      property Handle:THandle read qHandle; //-- Origin�ln� handle z knihovny QuidoStackDll.dll
      procedure GetCounterSetting(Index:integer;var Raising,Falling:boolean); //-- Zjist� nastaven� ��ta�e vstupu
      procedure SetCounterSetting(Index:integer;Raising,Falling:boolean);  //-- Nastav� ��ta� vstupu
      procedure Reset;
      function SndRcvSpin97(Inst:byte; const Data:AnsiString; var RcvAck:byte; var RcvData:AnsiString; MaxTimeOut:integer=500):boolean;
    published
      property OnQuidoEvent:TQuidoNotifyEvent read FOnQuidoEvent write SetOnQuidoEvent; //-- Ud�lost - jak�koliv ud�lost na quidu
      property OnOpen:TNotifyEvent read FOnOpen write SetOnOpen;  //-- Ud�lost - otev�en� komunika�n�ho kan�lu
      property OnClose:TNotifyEvent read FOnClose write SetOnClose; //-- Ud�lost - zav�en� komunika�n�ho kan�lu
      property OnInputChange:TIOChangeEvent read FOnInputChange write SetOnInputChange; //-- Ud�lost - Zm�na vstupu
      property OnOutputChange:TIOChangeEvent read FOnOutputChange write SetOnOutputChange; //-- Ud�lost - Zm�na vstup�
      property OnInputsChange:TNotifyEvent read FOnInputsChange write SetOnInputsChange; //-- Ud�lost - Zm�na v�stupu.
                                //Pozor, v�stupy neumo��uj� automatick� vys�l�n�, tato ud�lost se tedy vyvol� pouze p�i zji�t�n� zm�n� p�i explicitn�m zji��ov�n� stavu
      property OnOutputsChange:TNotifyEvent read FOnOutputsChange write SetOnOutputsChange; //-- Ud�lost - Zm�na v�stp�

      class function ConnectionStringDlg(var ConnectionString:AnsiString;Caption:AnsiString=''):boolean; //-- Metoda t��dy, kter� vyvol� dialog pro vytvo�en� p�ipojovac�ho �et�zce a vr�t� ho v parametru. vrac� true, pokud bylo stisknuto OK

  end;

implementation
uses sysutils, dialogs;


procedure QuidoCallBackEvent(qHandle:THandle; Event:word; Param:word; CallBackID:cardinal); stdcall;
var EventDone:boolean;
begin
 EventDone:=false;
 try
  if qHandle<>0 then
    if CallBackID<>0 then
      if TObject(CallBackID) is TObject then
        if TObject(CallBackID) is TQuido then
          if TQuido(CallBackID).qHandle = qHandle then
          begin
            EventDone:=true;
            TQuido(CallBackID).OnEvent(qHandle,Event,Param);
          end;
 except
   on e:exception do if EventDone then MessageDlg(e.Message,mtError,[mbOK],0);
 end;
end;

{ TQuido }

procedure TQuido.Close;
begin
 if qClose(qHandle)<>0 then RaiseLastError;
end;

class function TQuido.ConnectionStringDlg(var ConnectionString: AnsiString; Caption: AnsiString): boolean;
begin
  if Caption=''
   then Caption:='Quido connection string';

  _GetConnectionStringDlg(ConnectionString,Caption);
end;

constructor TQuido.Create(ConnectionString, QuidoParams: AnsiString);
begin
  QDTestInit;
  qHandle := qCreateQuido(PAnsiChar(ConnectionString),PAnsiChar(QuidoParams));
  if qHandle = 0 then
  begin
   RaiseLastError;
   raise Exception.Create('Creating Quido failed.');
  end;
  if qRegisterCallBackNotifications(qHandle,QuidoCallBackEvent,cardinal(self))<>0 then RaiseLastError;
end;

class function TQuido.CreateByDlg(QuidoParams: AnsiString;DefaultConnStr:AnsiString): TQuido;
var s:AnsiString;
begin
  S:=DefaultConnStr;
  if _GetConnectionStringDlg(s)
   then result:=Create(s,QuidoParams) else result:=nil;
end;

destructor TQuido.Destroy;
begin
  qReleaseQuido(qHandle);
  inherited;
end;

function TQuido.DeviceInfo: AnsiString;
var i:integer;
begin
  result:='';
  if qInfo(qHandle,nil,i)<>0 then RaiseLastError;
  setlength(result,i);
  if i>0 then
  if qInfo(qHandle,@result[1],i)=0 then result:=copy(result,1,i) else RaiseLastError;
end;

function TQuido.GetActive: boolean;
var B:LongBool;
begin
  if qIsOpened(qHandle,B)<>0 then RaiseLastError;
  result:=B;
end;

function TQuido.GetAutoInputNotification: boolean;
var B:LongBool;
begin
  if qGetAutoNotify(qHandle,B)<>0 then RaiseLastError;
  result:=B;
end;

procedure TQuido.GetCounterSetting(Index: integer; var Raising, Falling: boolean);
var R,F:longbool;
begin
  if qGetCounterSetting(qHandle,Index,R,F)<>0 then RaiseLastError
  else begin
    Raising:=R;
    Falling:=F;
  end;
end;

function TQuido.GetInputCounterValue(index: integer; NullCounter: boolean): cardinal;
begin
  if qInputCounterValueByIndex(qHandle,index,result,NullCounter)<>0 then RaiseLastError;
end;

function TQuido.GetInutState(index: integer): boolean;
var B:LongBool;
begin
  if qInputStateByIndex(qHandle,index,B)<>0 then RaiseLastError;
  result:=B;
end;

function TQuido.GetOutputState(index: integer): boolean;
var B:LongBool;
begin
  if qOutputStateByIndex(qHandle,index,B)<>0 then RaiseLastError;
  result:=B;
end;

procedure TQuido.GetRecentCounterSetting(index: integer; var Rising, Falling:boolean);
  var R,F:longbool;
begin
  if qGetRecentCounterSettingByIndex(qHandle,Index,R,F)<>0 then RaiseLastError;
  Rising:=R;
  Falling:=F;
end;

function TQuido.GetRecentCounterValue(index: integer): cardinal;
var B:integer;
begin
  if qGetRecentInputCounterByIndex(qHandle,index,B)<>0 then RaiseLastError;
  result:=B;
end;

function TQuido.GetRecentInputState(index: integer): boolean;
var B:LongBool;
begin
  if qGetRecentInputByIndex(qHandle,index,B)<>0 then RaiseLastError;
  result:=B;
end;

function TQuido.GetRecentOutputState(index: integer): boolean;
var B:LongBool;
begin
  if qGetRecentOutputByIndex(qHandle,index,B)<>0 then RaiseLastError;
  result:=B;
end;

function TQuido.InputCountersCount: integer;
begin
  result:=qInputCountersCount(qHandle);
  if result<0 then RaiseLastError;
end;

function TQuido.InputsCount: integer;
begin
  result:=qInputsCount(qHandle);
  if result<0 then RaiseLastError;
end;

procedure TQuido.OnEvent(qHandle: THandle; Event, Param: word);
begin
  if qHandle=self.qHandle then
  begin
    if assigned(fOnQuidoEvent) then FOnQuidoEvent(self,event,param);
    case Event of
      qev_CIOpen : if assigned(fOnOpen) then FOnOpen(self);
      qev_CIClose : if assigned(fOnClose) then FOnClose(self);
      qev_InputsChange : if assigned(fOnInputsChange) then fOnInputsChange(self);
      qev_OutputsChange : if assigned(fOnOutputsChange) then fOnOutputsChange(self);
      qev_InputChange : if assigned(fOnInputChange) then fOnInputChange(self, Param and $FF, ((Param shr 8)and 2)=2, ((Param shr 8)and 1)=1);
      qev_OutputChange : if assigned(fOnOutputChange) then fOnOutputChange(self, Param and $FF, ((Param shr 8)and 2)=2, ((Param shr 8)and 1)=1);
    end;
  end;
end;

procedure TQuido.Open;
begin
 if qOpen(qHandle)<>0 then RaiseLastError;
end;

function TQuido.OutputsCount: integer;
begin
 result:=qOutputsCount(qHandle);
 if result<0 then RaiseLastError;
end;

procedure TQuido.RefreshInputs(Wait:boolean);
begin
 if qRefreshRecentStates(qHandle,true,false,false,false)<>0 then RaiseLastError;
end;

procedure TQuido.RefreshOutputs(Wait:boolean);
begin
 if qRefreshRecentStates(qHandle,false,true,false,false)<>0 then RaiseLastError;
end;

procedure TQuido.RefreshRecentStates(Inputs, Outputs, Counters,
  CounterSettings: boolean);
begin
  if qRefreshRecentStates(qHandle,Inputs,Outputs,Counters,CounterSettings)<>0 then RaiseLastError;
end;

procedure TQuido.Reset;
begin
  if qReset(qHandle)<>0 then RaiseLastError;
end;

procedure TQuido.SetActive(const Value: boolean);
var B:boolean;
    ret:integer;
begin
  B:=GetActive;
  ret:=0;
  if B<>Value then
    if Value then ret:=qOpen(qHandle) else ret:=qClose(qHandle);
  if ret<>0 then RaiseLastError;
end;

procedure TQuido.SetAutoInputNotification(const Value: boolean);
var B:LongBool;
begin
  B:=Value;
  if qSetAutoNotify(qHandle,B)<>0 then RaiseLastError;
end;

procedure TQuido.SetCounterSetting(Index: integer; Raising,
  Falling: boolean);
begin
  if qSetCounterSetting(qHandle,Index,Raising,Falling)<>0 then RaiseLastError;
end;

procedure TQuido.SetOnClose(const Value: TNotifyEvent);
begin
  FOnClose := Value;
end;

procedure TQuido.SetOnInputChange(const Value: TIOChangeEvent);
begin
  FOnInputChange := Value;
end;

procedure TQuido.SetOnInputsChange(const Value: TNotifyEvent);
begin
  FOnInputsChange := Value;
end;

procedure TQuido.SetOnOpen(const Value: TNotifyEvent);
begin
  FOnOpen := Value;
end;

procedure TQuido.SetOnOutputChange(const Value: TIOChangeEvent);
begin
  FOnOutputChange := Value;
end;

procedure TQuido.SetOnOutputsChange(const Value: TNotifyEvent);
begin
  FOnOutputsChange := Value;
end;

procedure TQuido.SetOnQuidoEvent(const Value: TQuidoNotifyEvent);
begin
  FOnQuidoEvent := Value;
end;

procedure TQuido.SetOutputState(index: integer; const Value: boolean);
begin
 if qSetOutput(qHandle,index,Value)<>0 then RaiseLastError;
end;


procedure TQuido.SetOutputStateTimed(index: integer; State: boolean;
  TimeSec: integer);
begin
 if qSetOutputTimered(qHandle,index,State,TimeSec)<>0 then RaiseLastError;
end;

function TQuido.SndRcvSpin97(Inst: byte; const Data: AnsiString; var RcvAck: byte;var RcvData: AnsiString; MaxTimeOut: integer): boolean;
begin
  result:=_SndRcvSpin97(qHandle,Inst,Data,RcvAck,RcvData,MaxTimeOut);
end;

end.
