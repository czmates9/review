(*
  CommIntfDll - Mapov�n� funkc� z knihovny CommIntfDll.dll
  Vytvo�eno pro Delphi 7

  Vydavatel :  Papouch s.r.o. - http://www.papouch.com/
  Autor     :  Martin Z�me�n�k zamecnik@papouch.com

  popis     : knihovna umo��uje komunikaci nejen se za��zen�mi firmy papouch s.r.o. p�es s�riov� port, usb a ethernet (TCP nebo UDP)
              komunika�n� spojen� se vytv��� pomoc� funkc� ciCreate a p�edan�ho p��pojovac�ho �et�zce (ten ur�uje, o jak� rozhrann� se jend�, a dal�� parametry),
              tyto funkce vracej� Handle (madlo) komunika�n�ho rozhrann�, kter� se pak p�ed�v� ostatn�m funkc�m
              v�echny funkce jsou spole�n� pro v�echny typy rozhrann�. funkce s n�vratovou hodnotou reStat (integer) vracej� ERR_OK (0) pokud v�e prob�lo v po��dku, jinak chybov� k�d

  Pozn�mky  : k pou�it� funkc� je pot�eba knihovna CommIntfDll.dll,
              v p��pad� pou�it� pro USB jsou pot�eba t� nainstalovan� ovlada�e FTD direct drivers a knihova FTD2XX.dll, nebo nainstalovan� virtu�ln� s�riov� port
              
*)
unit uci_IDLLMapD;

{$DEFINE InitDLL}
interface
uses windows;
const CIDLLName = 'CommIntfDLL.dll';
type reStat = integer;
     AHandle = array of THandle;
     tSPortNumber = integer;
     TPortStateState = (PS_OPEN=0, PS_CLOSE=1, PS_NOTEXIST=2);
     TPortState = packed record
       ComNumber: tSPortNumber;
       State: TPortStateState;
     end;

const ciev_Base = $FF;  //-- Konstanty pro Typ ud�losti komunika�n�ho rozhran�
      ciev_Open = ciev_Base + 1;
      ciev_Close = ciev_Base + 2;
      ciev_DataRcv = ciev_Base + 3;
      ciev_Error = ciev_Base + 4;


type

THandleNotificationEvent = procedure (Handle:THandle;Event:word;Param:word;CallBackID:cardinal);stdcall; //-- Typ callbackov� funkce (viz. ciRegisterCallBackNotifications)

var
//***funkce pro spr�vu chyb***
LastError : function:integer;stdcall; //-- Zjist� ��slo posledn� chyby
LastErrorText:function (Text:pchar;var Size:integer):reStat;stdcall;
                       //-- Z�sk� text posledn� chyby. Text=buffer, do kter�ho bude text p�ed�n; Size=velikost bufferu Text, zp�t vr�t� po�et znak� textu.
                       //-- Pokud je Size men�� ne� pot�ebn� velikost pro text, je n�vratov� hodnota ERR_MoreSize a do Size se nastav� pot�ebn� velikost
                       //-- Pokud je Text NIL, pouze se do Size vr�t� pot�ebn� velikost bufferu pro text
                       //-- Pokud v�e prob�hlo v po��dku, vr�t� se ERR_OK (0)
                       //-- pozn. tento princip funguje u v�t�iny funkc�, kde se z�sk�v� textov� hodnota
SetLastError:function (ErrNum:integer;Text:pchar):reStat; stdcall;
                      //-- Nastav� Chybu. P�ed�v� se ��slo chyby a text chyby
//*** info ***
Info:function :pChar; stdcall; //-- Vr�t� informa�n� text o knihovn�

//*** funkce pro pr�ci s komunika�n�m rozhrann�m ****
ciCreate:function (ConnectionString:pChar):THandle; stdcall; //-- Vytvo�� komunika�n� rozhrann� podle zadan�ho p�ipojovac�ho �et�zce
    //--       connection string je �et�zec pro vytvo�en� komunika�n�ho rozhrann�, ur�uje komunika�n� kan�l a jeho nastaven� (s�riov� port, tcp, udp, nebo ftd_usb)
    //   Tvorba connectionstringu : jsou to hodnoty ve tvaru "parametr=hodnota" odd�leny st�edn�kem. ur�uj� typ p�ipojen�
    //          nejd�le�it�j��m parametrem je "provider", ur�uje typ rozhrann�. m��e to b�t SERIAL_PORT, TCP_CLIENT, UDP_CLIENT nebo FTD_USB
    //          ka�d� kan�l pak m��e m�t dal�� parametry. SERIAL_PORT (comport=��slo portu;baudrate=rychlost - nemus� b�t zad�no), TCP_CLIENT(host=ip adresa za��zen�;port=tcp port za��zen�), UDP_CLIENT(stejn� jako TCP),
    //                                                    FTD_USB(index=po�adov� ��slo za��zen�; nebo device=��st n�zvu za��zen�; nebo serial_number=s�riov� ��slo za��zen�; nebo vid=vid;pid=pid; nebo nemus� m�t ��dn� parametr, vezme se prvn� p�ipojen� za��zen� typu FTD_USB
    //          p��klady: "provider=SERIAL_PORT;comport=1", "provider=TCP_CLIENT;host=192.168.1.254;port=10001", "provider=UDP_CLIENT;host=192.168.1.254;port=10001", "provider=FTD_USB;device=Quido"
    //          N�vratov� hodnota je Handle na vytvo�en� komunika�n� rozhrann�. 0 = Nebylo vytvo�eno

ciCreateM:function (ConnectionString:pChar;NotificationHWND:hwnd;Msg:cardinal;Blocking:boolean):THandle; stdcall;
                      //-- vytvo�� komunika�n� rozhrann� viz. ciCreate, nav�c zaregistruje p��jem ud�lost� pomoc� windows zpr�v.
                      //   NotificationHWND = handle okna kam maj� zpr�vy chodit, Msg = Jak� zpr�va se bude zas�lat,
                      //   Blocking=jakou medodou budou zpr�vy zas�l�ny: true-SendMessage-rozhrann� �ek� na zpracov�n� ud�lost�, false-PostMessage-rozhrann� asynchronn� za�le upozorn�n� o ud�losti a ne�ek� na jeho zpracov�n�
                      //   viz. ciRegisterMsgNotifications
ciCreateCB:function (ConnectionString:pChar;CallBackEntryPoint:pointer;CallBackID:cardinal):THandle; stdcall;
                      //-- vytvo�� komunika�n� rozhrann� viz. ciCreate, nav�c zaregistruje p��jem ud�lost� pomoc� CallBackov� funkce
                      //   CallBackEntryPoint = vstupn� bod Callbackov� funkce typu THandleNotificationEvent
                      //   CallBackID = voliteln� parametr, kter� bude zp�t zas�l�n p�i zp�tn�m vol�n� (voliteln� identifikace)
                      //   viz. ciRegisterCallBackNotifications
ciOpen:function (handle:THandle):reStat; stdcall; //-- otev�e komunika�n� kan�l (otev�e port, nav�e tcp spojen�, ... podle typu komunika�n�ho rozhran�; nutno p�ed zapo�et�m komunikace; vr�t� 0 pokud OK, chybov� k�d v opa�n�m p��pad�
                                                  //   Jako handle se p�ed�v� handle z�skan� z funkc� ciCreate
ciClose:function (handle:THandle):reStat; stdcall; //-- zav�e komunika�n� kan�l
ciRelease:function (handle:THandle):reStat; stdcall; //-- Zru�� komunika�n� kan�l a p��slu�n� handle
ciIsActive:function (handle:THandle;var Active:longbool):reStat; stdcall; //-- Zjist�, zda je komunika�n� rozhrann� otev�eno. pokud je n�vratov� hodnota 0, do parametru Active je vr�cen stav
ciRead:function (Handle:THandle;var Buffer;var Size:integer):reStat; stdcall; //-- Na�te p��choz� data. Size se nastav� na velikost bufferu, vr�ti se po�et na�ten�ch byt�
ciWrite:function (Handle:THandle;var Buffer;Size:integer):reStat; stdcall; //-- Po�le data po komunika�n�m rozhrann�
ciReadLength:function (Handle:THandle):integer; stdcall; //-- Zjist�, kolik byt� je ve vstupn�m bufferu p�ipraveno k na�ten�
ciClearReadBuffer:function(Handle:THandle):reStat; stdcall; //-- Vyma�e p��choz� data ze vstupn�ho bufferu

//funkce pro usnadn�n� synchronn� komunikace typu dotaz-odpov��
ciSndGet:function(Handle:THandle;var SndBuffer;Size:integer;var RcvBytes:integer;MaxTimeOut:integer=500):reStat; stdcall;
        //-- Ode�le data (Size byt� ze SndBufferu) a �ek� na odpov�� (Maxim�ln� MaxTimeOut milisekund). V RcvBytes vr�t�, kolik byt� bylo p�ijato jako odpov��. Odpov�� lze p�ijmout pomoc� ciRead
ciSndGetSpinel97:function(Handle:THandle;var SndBuffer;Size:integer;var RcvBytes:integer;MaxTimeOut:integer):reStat;stdcall;
        //-- Stejn� jako ciSndGet ode�le data a �ek� na odpov��. Jako odpov�� v�ak o�ek�v� Spinel paket. v RcvBytes vr�t� po�et p�ijat�ch byt� platn�ho Spinel paketu. Pokud nebyl platn� paket p�ijat, n�vratov� hodnota signalizuje chybu a RcvBytes je 0.
        //-- Odpov�� lze z�skat funkc� ciRead nebo ciReadSpin97.
ciSndGetSpin97:function (Handle:THandle;Adr:byte;Sig:byte;Inst:byte;Data:pointer;DataLen:integer;var RcvBytes:integer;MaxTimeOut:integer):reStat;stdcall;
        //-- Ode�le Spinelovsk� paket, vytvo�en� parametry Adr, Sig, Inst a Data (D�lky DataLen). Zbytek spinelovsk� hlavi�ky (prefix, d�lka, CRC, ..) se vypo��t� automaticky.
        //   Odpov�� jako u ciSndGetSpinel97
ciReadSpin97:function (Handle:THandle;var Adr:byte;var Sig:byte; var Ack:byte; Data:pointer; var DataSize:integer):reStat; stdcall;
        //-- Na�te Spinel paket z p�ijat�ch dat. pokud v p�ijat�ch datech nen� platn� spinel paket, n�vratov� hodnota signalizuje chybu.
        //   Pokud byl p�ijat paket, napln� se z n�j hodnoty Adr, Sig a Ack a Data. v DataSize je t�eba zadat velikost bufferu Data, zp�t se vr�t� aktu�ln� velikost Dat.
ciRegisterMsgNotifications:function (Handle:THandle;WHandle:hwnd;Msg:cardinal;Blocking:longbool=true):reStat; stdcall;
                      //-- Zaregistruje p��jem ud�lost� pomoc� windows zpr�v.
                      //   NotificationHWND = handle okna kam maj� zpr�vy chodit, Msg = Jak� zpr�va se bude zas�lat,
                      //   Blocking=jakou medodou budou zpr�vy zas�l�ny: true-SendMessage-rozhrann� �ek� na zpracov�n� ud�lost�, false-PostMessage-rozhrann� asynchronn� za�le upozorn�n� o ud�losti a ne�ek� na jeho zpracov�n�
                      //   Zpr�va p�ijde ve tvaru : Msg = Msg, wParam = Handle, lParamLow = Typ ud�losti (ciev_Open, ciev_Close, ciev_DataRcv, ciev_Error), lParamHi = p��padn� dodate�n� parametr
ciUnregisterMsgNotifications:function (Handle:THandle):reStat; stdcall; //-- Odregistruje p��jem ud�lost� pomoc� widnows zpr�v
ciRegisterCallBackNotifications:function (Handle:THandle;CallBackEntryPoint:THandleNotificationEvent;CallBackID:cardinal=0):reStat; stdcall;
                      //-- Zaregistruje p��jem ud�lost� pomoc� CallBackov� funkce
                      //   CallBackEntryPoint = vstupn� bod Callbackov� funkce typu THandleNotificationEvent
                      //   CallBackID = voliteln� parametr, kter� bude zp�t zas�l�n p�i zp�tn�m vol�n� (voliteln� identifikace)
                      //   Callbackov� funkce je pak vol�na s t�mito parametry : Handle-Handle rozhran�;Event-typ ud�losti (ciev_Open, ciev_Close, ciev_DataRcv, ciev_Error);Param-p��padn� parametr; CallBackID-voliteln� parametry zadan� p�i registraci
ciUnregisterCallBackNotifications:function (Handle:THandle):reStat; stdcall; //-- Odregistruje p��jem ud�lost� pomoc� callbackov� funkce
ciEnumHandles:function (HandleList:PHandle;var Size:integer):integer; stdcall; //-- Vr�t� seznam v�ech aktu�ln� vytvo�en�ch komunika�n�ch rozhran�ch
ciHandlesCount:function :integer;stdcall; //-- Vr�t� po�et aktu�ln� vytvo�en�ch komunika�n�ch rozhran�ch
ciHandleByIndex:function (index:integer):THandle;stdcall; //-- Vr�t� handle podle indexu (0 .. ciHandlesCount-1)
ciGetDescription:function (Handle:THandle;Description:pChar;var Len:integer):reStat; stdcall; //-- Vr�t� popis komunika�n�ho rozhran�
ciGetID:function (Handle:THandle;ID:pchar;var Len:integer):reStat; stdcall; //--  Vr�t� textovou identifikaci rozhran�
ciGetProvider: function (Handle:THandle;Provider:pChar;var Len:integer):reStat; stdcall; //-- Vr�ti typ rozhrann� (SERIAL_PORT, TCP_CLIENT, UDP_CLIENT nebo FTD_USB)
ciGetValid:function (handle:THandle;var Valid:longbool):reStat; stdcall; //-- rezervov�no
ciSetValid:function (handle:THandle;Valid:LongBool):reStat; stdcall;  //-- rezervov�no
ciExecuteConfigDialog:function (handle:THandle):longbool; stdcall; //-- Spust� se konfigura�n� dialog konkr�tn�ho komunika�n�ho rozhrann�
ciConfigDialogAvailable:function (handle:THandle):longbool; stdcall; //-- Zjist�, zda rozhran� podporuje konfigura�n� dialog
//-------------
ciGetConfig :function (Handle:THandle;ConfigString:pChar;var Len:integer):reStat; stdcall; //-- Z�sk� konfigura�n� �et�zec rozhran�
ciSetConfig :function (Handle:THandle;ConfigString:pChar):reStat;stdcall; //-- Nastav� konfigura�n� �et�zec rozhran�
ciGetConfigValue :function (Handle:THandle;ParamName:pChar;Value:pChar;var Len:integer):reStat; stdcall; //-- Zj�sk� jednu hodnotu z konfigura�n�ho �et�zce; ParamName=n�zev parametru; Value=buffer, do kter�ho se vr�t� textov� podoba hodnoty
ciGetConnectionStringDlg :function (OutConnStr:pChar;var Len:integer;var OKReturn:longbool;DefaultValue:pChar=nil;Caption:pChar=nil):reStat; stdcall;
      //-- Zobraz� dialog pro vytvo�en� konfigura�n�ho �et�zce. OutConnStr = buffer pro ulo�en� v�sledku; Len = velikost bufferu OutConnStr, zp�t vr�t� aktu�ln� velikost �et�zce; OKReturn=vr�t�, zda bylo stisknuto OK;
      //   DefaultValue = V�choz� konfigura�n� �et�zec; Caption = Titulek okna konfigura�n�ho �et�zce
//--------------

//*** funkce pro v��et s�riov�ch port� a FTD USB za��zen� ***
EnumSerialPorts:function(Ports:PInteger;var Size:integer):integer;stdcall; //-- Vr�t� seznam s�riov�ch port� na po��ta�i (v�etn� virtu�ln�ch)
            // Ports - buffer (ukazatel na pole integer�), kam se ulo�� v�sledek; Size - velikost bufferu v bytech, zp�t vr�t� aktu�ln� velikost v bytech; n�vratov� hodnota - po�et port� (-1 = chyba)
SerialPortCount:function():integer;stdcall;  //-- Po�et s�riov�ch port� na po��ta�i
SerialPortNumByIndex:function(index:integer):tSPortNumber;stdcall; //-- Vr�t� ��slo portu podle indexu (0..SerialPortCount-1)
SerialPortByIndex:function(index:integer;PortName:pChar;var Len:integer):reStat;stdcall; //-- Vr�t� n�zev portu podle indexu (0..SerialPortCount-1) nap�: "COM3"
GetSerialPortState:function(PortNum:tSPortNumber):TPortStateState; //-- Vr�t� stav s�riov�ho portu (otev�en�, zav�en�, neexistuje)
FTDDeviceCount:function():integer;stdcall; //-- Po�et za��zen� p�ipojen�ch p�es FTD USB
FTDGetDetailByIndex:function(index:integer;Flags,Typ,ID,LocID:pcardinal;SerialNum:pChar;Description:pChar):reStat;stdcall;
    //-- Zjist� informace o USB za��zen� podle indexu (0..FTDDeviceCount-1). Flags, Typ, ID a Loc jsou ukazatele na 32bitov� ��sla. parametry kter� nechceme vr�tit m��ou b�t NIL
    //-- SerialNum a Description jsou buffery pro ulo�en� textu, m�li by b�t alokov�ny na dostate�nou velikost, nebo NIL, pokud n�s nezaj�maj�. 32B pro SerialNum a 128B pro Description by m�lo ur�it� sta�it.
FTDSerNumByIndex:function(index:integer;SerNum:pChar;var Len:integer):reStat;stdcall;
    //-- Zjist� s�riov� ��slo USB za��zen� podle indexu
FTDDevNameByIndex:function(index:integer;DevName:pChar;var Len:integer):reStat;stdcall;
    //-- Zjist� n�zev za��zen� USB za��zen� podle indexu
FTDVidPidByIndex:function(index:integer;var VID:integer;var PID:integer):reStat;stdcall;
    //-- Zjist� VID a PID hodnoty (identifikace v�robce a produktu) USB za��zen�
FTDFindDevice:function(start:integer;SerNum:pChar;DevName:pChar;VID:pInteger;PID:pInteger;var Index:integer):reStat;stdcall;
    //-- Vyhled� v dostupn�ch USB za��zen� na po��ta�i (prvn�) ten, kter� odpov�d� zadan�m parametr�m. do Index vr�t� jeho Index.
    //   parametry se p�ed�vaj� ukazatelem na hodnotu nebo �et�zec. parametry mohou b�t vynech�ny zad�n�m NIL.
FTDFindDeviceCS:function(start:integer;Params:pChar;var Index:integer):reStat;stdcall;
    //-- Vyhled� USB za��zen� podle parametr�, jako FTDFindDevice, akor�t se parametry p�ed�vaj� v jednom �et�zci odd�len� st�edn�kem:
    //   Lze zadat n�kter� z t�chto parametr�:
    //   index=zad� p��mo index; nebo device=��st n�zvu za��zen�; nebo serial_number=s�riov� ��slo za��zen�; nebo vid=vid;pid=pid; nebo nemus� m�t ��dn� parametr, vezme se prvn� p�ipojen� za��zen� typu FTD_USB)
    //   do Index se vr�t� Index za��zen�, kter� odpov�d� v�em zadan�m parametr�m. V p��pad� �e tomu ��dn� za��zen� neodpov�d�, vr�t� se do Index -1.
//---------
//*** pomocn� funkce, uleh�uj�c� pr�ci s n�kter�mi importovan�mi funkcemi v prost�ed� Delphi ***
//---------
function _LastErrorText:string; //-- vr�t� text posledn� chyby
procedure _RaiseLastError; //-- vyvol� vyj�mku podle posledn� chyby
function _Info():string; //-- vr�t� informa�n� �et�zec knihovny
function _ciCreate(ConnectionString:string;NotifWND:hwnd=0;NMsg:cardinal=0):THandle;  //-- Vytvor� komunika�n� rozhran�, s mo�nost� registrace ud�lost� pomoc� zpr�v
function _ciOpen(Handle:THandle):boolean; //-- Otev�e kom. rozhran�, p�i selh�n� vyvol� vyj�mku
function _ciClose(Handle:THandle):boolean; //-- Zav�e kom. rozhran�, - || -
function _ciIsActive(Handle:THandle):boolean; //-- Zjist�, zda je rozhran� otev�eno
function _ciRead(Handle:THandle):string; //-- Na�te p�ijat� data
function _ciWrite(Handle:THandle;Data:string):boolean; //-- Zap�e data
function _ciEnumHandles(var HandleList:AHandle):integer; //-- Na�te v�echny vytvo�en� Handly rozhran�ch do pole, vr�t� jejich po�et
function _ciGetDescription(Handle:THandle):string; //-- Vr�t� popis rozhran�
function _ciGetID(Handle:THandle):string; //-- Vr�t� identifikaci rozhran�
function _ciGetProvider(Handle:THandle):string; //-- Vr�t� providera (typ rozhran�)
function _ciGetValid(handle:THandle):boolean;
procedure _ciSetValid(Handle:THandle;Valid:boolean);
function _GetConnectionStringDlg(var ConnectionString:string;Caption:string=''):boolean; //-- Zobraz� dialog pro tvorbu p�ipojovac�ho �et�zce
function _SndRcv(Handle:THandle;const Data:string;MaxTimeOut:integer=500):string; //-- Ode�le data a �ek� na odpov��. n�vratov� hodnota = p�ijat� odpov��
function _SndRcvSpin97(Handle:THandle;var Adr:byte;var Sig:byte;var Inst_Ack:byte;var Data:string;MaxTimeOut:integer=500):boolean;
         //-- Ode�le Spinel paket a p�ijme odpov��. Vyslan� paked se slo�� z adresy(Adr), podpisu(Sig),instrukce(Inst_Ack) a Dat(Data)
         // Pokud byla odpov�� p�ijata, n�vratov� hodnota je true, nastav� p�ij�t� Adr, Sig a Ack (v Inst_Ack) a data se zm�n� na p�ijat� Data
         // false = nebyl p�ijat paket zp�t
//*** linkov�n� knihovny ***
function CIDllOK:boolean; //-- Zjist�, zda byla v po��dku na�tena knihovna
function CIDllInitMsg:string; //-- Vr�t� chybobou zpr�vu, pokud nebyla v po��dku na�tena
procedure CIDTestInit;  //-- Vyvol� vyj�mku, pokud nebyla knihovna v po��dku na�tena



implementation
uses SysUtils,forms,messages;
var DllInited:boolean;
    hDll:THandle;
    DllInitMsg:string;

function _LastErrorText:string;
var i:integer;
begin
  CIDTestInit;
  result:='';
  LastErrorText(nil,i);
  if i>0 then
  begin
    setlength(result,i);
    LastErrorText(@result[1],i);
    setlength(result,i);
  end;
end;

procedure _RaiseLastError;
var X:integer;
begin
  CIDTestInit;
  X:=LastError;
  if X<>0 then raise Exception.Create(_LastErrorText);
end;

function _Info():string;
begin
  CIDTestInit;
  result:=Info;
end;

function _ciCreate(ConnectionString:string;NotifWND:hwnd;NMsg:cardinal):THandle;
begin
  CIDTestInit;
  result:= ciCreateM(pansichar(ConnectionString),NotifWND,NMsg,true);
  if result=0 then
   if LastError()<>0 then _RaiseLastError;
end;

function _ciOpen(Handle:THandle):boolean;
begin
  CIDTestInit;
  if ciOpen(Handle)<>0 then _RaiseLastError;
end;

function _ciClose(Handle:THandle):boolean;
begin
  CIDTestInit;
  if ciClose(Handle)<>0 then _RaiseLastError;
end;

function _ciIsActive(Handle:THandle):boolean;
var LB:LongBool;
begin
  CIDTestInit;
  if ciIsActive(Handle,LB)<>0 then _RaiseLastError;
  result:=LB;
end;

function _ciRead(Handle:THandle):string;
var i:integer;
    s:string;
begin
  CIDTestInit;
  result:='';
  i:=ciReadLength(Handle);
  if (I<0)and(LastError<>0) then _RaiseLastError;
  if i>0 then
  begin
    i:=i*2;
    setlength(S,i);
    if ciRead(Handle,s[1],i)<>0 then _RaiseLastError;
    result:=copy(s,1,i);
  end;
end;

function _ciWrite(Handle:THandle;Data:string):boolean;
var i:integer;
begin
  CIDTestInit;
  i:=length(Data);
  result:=false;
  if Data<>'' then
    result:=ciWrite(Handle,Data[1],i)<>0;
   //if ciWrite(Handle,Data[1],i)<>0 then _RaiseLastError;
end;

function _ciGetDescription(Handle:THandle):string;
var S:string;
    i:integer;
begin
  CIDTestInit;
  result:='';
  if ciGetDescription(Handle,nil,i)<>0 then _RaiseLastError;
  setlength(s,i);
  if i>0 then
  begin
    if ciGetDescription(Handle,@s[1],i)<>0 then _RaiseLastError;
    result:=copy(s,1,i);
  end;
end;

function _ciEnumHandles(var HandleList:AHandle):integer;
var x,s:integer;
begin
  CIDTestInit;
  result:=0;
  x:=ciEnumHandles(nil,s);
  if x<0 then _RaiseLastError;
  result:=x;
  if (x<=0)or(s<=0) then exit;
  setlength(HandleList, x);
  x:=ciEnumHandles(@HandleList[0],s);
  result:=x;
end;

function _ciGetID(Handle:THandle):string;
var S:string;
    i:integer;
begin
  CIDTestInit;
  result:='';
  if ciGetID(Handle,nil,i)<>0 then _RaiseLastError;
  setlength(s,i);
  if i>0 then
  begin
    if ciGetID(Handle,@s[1],i)<>0 then _RaiseLastError;
    result:=copy(s,1,i);
  end;
end;
function _ciGetProvider(Handle:THandle):string;
var S:string;
    i:integer;
begin
  CIDTestInit;
  result:='';
  if ciGetProvider(Handle,nil,i)<>0 then _RaiseLastError;
  setlength(s,i);
  if i>0 then
  begin
    if ciGetProvider(Handle,@s[1],i)<>0 then _RaiseLastError;
    result:=copy(s,1,i);
  end;
end;
function _ciGetValid(handle:THandle):boolean;
var LB:LongBool;
begin
  CIDTestInit;
  if ciGetValid(Handle,LB)<>0 then _RaiseLastError;
  result:=LB;
end;
procedure _ciSetValid(Handle:THandle;Valid:boolean);
var LB:LongBool;
begin
 CIDTestInit;
 LB:=Valid;
 if ciSetValid(Handle,LB)<>0 then _RaiseLastError;
end;
function _GetConnectionStringDlg(var ConnectionString:string;Caption:string=''):boolean;
var s,dv:string;
    L:integer;
    R:longbool;
begin
  l:=256;
  result:=false;
  setlength(s,l);
  dv:=ConnectionString;
  if ciGetConnectionStringDlg(@s[1],L,R,pansichar(DV),pansichar(Caption))=0 then
  begin
    if R then
    begin
      setlength(s,l);
      ConnectionString:=s;
      if s<>'' then result:=true;
    end;
  end else raise Exception.Create(_LastErrorText);
end;
function _SndRcv(Handle:THandle;const Data:string;MaxTimeOut:integer=500):string;
var Siz:integer;
    S:string;
begin
  result:='';
  if length(Data)<=0 then exit;
  S:=Data;
  if ciSndGet(Handle,S[1],length(S),Siz,MaxTimeOut)<>0 then exit;
  if Siz<=0 then exit;
  setlength(S,Siz);
  if ciRead(Handle,S[1],Siz)<>0 then exit;
  setlength(S,Siz);
  result:=S;
end;

function _SndRcvSpin97(Handle:THandle;var Adr:byte;var Sig:byte;var Inst_Ack:byte;var Data:string;MaxTimeOut:integer):boolean;
var Siz:integer;
    S:string;
    P:pointer;
begin
  result:=false;
  if length(Data)<=0 then P:=nil else P:=@Data[1];
  if ciSndGetSpin97(Handle,Adr,Sig,Inst_Ack,P,length(Data),Siz,MaxTimeOut)<>0 then exit;
  if Siz<=0 then exit;
  setlength(S,Siz);
  if ciReadSpin97(Handle,Adr,Sig,Inst_Ack,@S[1],Siz)<> 0 then exit;
  setlength(S,Siz);
  Data:=S;
  result:=true;
end;

function CIDllInitMsg:string;
begin
  if CIDllOK then result:='' else result:=DllInitMsg;
end;

procedure CIDTestInit;
begin
  if not cidllok then raise Exception.Create(DllInitMsg);
end;

function CIDllOK:boolean;
{}procedure Map(var ProcAddr:Pointer;const Name:string);
{}begin
    ProcAddr:=GetProcAddress(hDll,pansichar(Name));
    if not assigned(ProcAddr) then raise Exception.Create('Can not map function '+Name+ ' in '+cidllname);
{}end;
begin
  if DllInited then
  begin
    result:=(hDLL<>0);
  end else
  begin
    try
      DllInited:=true;
      result:=false;
      dllinitmsg:='';
      hDLL := LoadLibrary(pansichar(cidllname));
      if hDLL=0 then
      begin
        DllInitMsg := 'Can''t load library '+CIDLLName + '.';
        exit;
      end;
      Map(@ciCreate,'ciCreate');
      Map(@ciCreateM,'ciCreateM');
      Map(@ciCreateCB,'ciCreateCB');
      Map(@ciOpen ,'ciOpen');
      Map(@ciClose ,'ciClose');
      Map(@ciRelease,'ciRelease');
      Map(@ciIsActive,'ciIsActive');
      Map(@ciRead ,'ciRead');
      Map(@ciWrite ,'ciWrite');
      Map(@ciReadLength ,'ciReadLength');
      Map(@ciRegisterMsgNotifications ,'ciRegisterMsgNotifications');
      Map(@ciUnregisterMsgNotifications ,'ciUnregisterMsgNotifications');
      Map(@ciRegisterCallBackNotifications ,'ciRegisterCallBackNotifications');
      Map(@ciUnregisterCallBackNotifications ,'ciUnregisterCallBackNotifications');
      Map(@ciEnumHandles,'ciEnumHandles');
      Map(@ciGetDescription ,'ciGetDescription');
      Map(@ciGetID,'ciGetID');
      Map(@ciGetValid ,'ciGetValid');
      Map(@ciExecuteConfigDialog ,'ciExecuteConfigDialog');
      Map(@ciConfigDialogAvailable,'ciConfigDialogAvailable');
      Map(@ciHandlesCount,'ciHandlesCount');
      Map(@ciHandleByIndex,'ciHandleByIndex');
      Map(@ciGetProvider,'ciGetProvider');
      Map(@LastError,'LastError');
      Map(@LastErrorText,'LastErrorText');
      Map(@SetLastError,'SetLastError');
      //---------------------
      Map(@EnumSerialPorts,'EnumSerialPorts');
      Map(@SerialPortCount,'SerialPortCount');
      Map(@SerialPortNumByIndex,'SerialPortNumByIndex');
      Map(@SerialPortByIndex,'SerialPortByIndex');
      Map(@GetSerialPortState,'GetSerialPortState');
      Map(@FTDDeviceCount,'FTDDeviceCount');
      Map(@FTDGetDetailByIndex,'FTDGetDetailByIndex');
      Map(@FTDSerNumByIndex,'FTDSerNumByIndex');
      Map(@FTDDevNameByIndex,'FTDDevNameByIndex');
      Map(@FTDVidPidByIndex,'FTDVidPidByIndex');
      Map(@FTDFindDevice,'FTDFindDevice');
      Map(@FTDFindDeviceCS,'FTDFindDeviceCS');
      //---------------------
      Map(@ciGetConfig,'ciGetConfig');
      Map(@ciSetConfig,'ciSetConfig');
      Map(@ciGetConfigValue,'ciGetConfigValue');
      Map(@ciGetConnectionStringDlg,'ciGetConnectionStringDlg');

      Map(@ciClearReadBuffer,'ciClearReadBuffer');
      Map(@ciSndGet,'ciSndGet');
      Map(@ciSndGetSpinel97,'ciSndGetSpinel97');
      Map(@ciSndGetSpin97,'ciSndGetSpin97');
      Map(@ciReadSpin97,'ciReadSpin97');
      
      //Map(@,'');
      //Map(@ci,'ci');
      result:=true;
    except
      on e:exception do
      begin
        if hDll<>0 then
        begin
           FreeLibrary(hDLL);
           hDll := 0;
        end;
        DllInitMsg := e.Message;
      end;
    end;
  end;
end;

initialization
 DllInited := false;
 hDll := 0;
 {$IFDEF InitDLL}
 if not CIDllOK then
  if MessageBox(0,pansichar(DllInitMsg+#13#10+'Terminate aplication?'),'Error in loading library',MB_YESNO+MB_ICONERROR)=IDYes
    then PostMessage(Application.Handle,WM_QUIT,0,0);
 {$ENDIF}
finalization
 if hDLL<>0 then FreeLibrary(hDll);
 hDll:=0;
end.