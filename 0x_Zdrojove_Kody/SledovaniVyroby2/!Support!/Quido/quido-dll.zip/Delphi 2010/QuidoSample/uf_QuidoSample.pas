(*
  P��klad pou�it� knihovny QuidoStackDll.dll pro ovl�d�n� Quida.
  Vytvo�eno pro Delphi 7

  Vydavatel :  Papouch s.r.o. - http://www.papouch.com/
  Autor     :  Martin Z�me�n�k zamecnik@papouch.com

  popis     : uk�zkov� aplikace pro pou�it� knihovny QuidoStackDll.dll pro ovl�d�n� za��zen� Quido firmy Papouch s.r.o.
              p�es objektov� rozhran� definovan� v unit� uo_Quido.pas. Demonstruje zejm�na z�kladn� rutiny ovl�d�n� vstup� a v�stup�

  Pozn�mky  : k pou�it� funkc� jsou pot�eba knihovny QuidoStackDll.dll, CommIntfDll.dll, unita mapuj�c� funkce q_QuidoDllMapD.pas a unita pro zaobalen� do objektu uo_Quido.pas.
              v p��pad� pou�it� pro USB jsou pot�eba t� nainstalovan� ovlada�e FTD direct drivers a knihova FTD2XX.dll, nebo nainstalovan� virtu�ln� s�riov� port

*)
unit uf_QuidoSample;

interface

uses
  Windows, SysUtils, Controls, Forms, dialogs,
  StdCtrls,uo_Quido, ImgList, ComCtrls, ExtCtrls, Menus, Classes;
type
  TfQuidoDemo = class(TForm)
    GroupBox1: TGroupBox;
    ConnectionString: TComboBox;
    Label1: TLabel;
    Label2: TLabel;
    QuidoParams: TEdit;
    cmdCreateQ: TButton;
    cmdOpen: TButton;
    cmdClose: TButton;
    ImageList1: TImageList;
    Panel1: TPanel;
    gbOvladani: TGroupBox;
    Label3: TLabel;
    lwInputs: TListView;
    lblQuidoID: TLabel;
    pmInputs: TPopupMenu;
    Vynulovatta1: TMenuItem;
    lwOutputs: TListView;
    chAuto: TCheckBox;
    chPeriod: TCheckBox;
    cmdReset: TButton;
    chRefresh: TButton;
    Timer1: TTimer;
    pmOutputs: TPopupMenu;
    Zmnitstavnaas1: TMenuItem;
    Panel2: TPanel;
    Label4: TLabel;
    cmdDlg: TButton;
    Nastaven1: TMenuItem;
    Nbnhrana1: TMenuItem;
    Sestupnhrana1: TMenuItem;
    Ob1: TMenuItem;
    Vypnuto1: TMenuItem;
    procedure cmdCreateQClick(Sender: TObject);
    procedure cmdOpenClick(Sender: TObject);
    procedure cmdCloseClick(Sender: TObject);
    procedure Vynulovatta1Click(Sender: TObject);
    procedure cmdResetClick(Sender: TObject);
    procedure lwOutputsChange(Sender: TObject; Item: TListItem; Change: TItemChange);
    procedure chRefreshClick(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure chPeriodClick(Sender: TObject);
    procedure chAutoClick(Sender: TObject);
    procedure Zmnitstavnaas1Click(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure cmdDlgClick(Sender: TObject);
    procedure Vypnuto1Click(Sender: TObject);
    procedure Nbnhrana1Click(Sender: TObject);
    procedure Sestupnhrana1Click(Sender: TObject);
    procedure Ob1Click(Sender: TObject);
  private
    Quido:TQuido; //-- objekt quida
    //--- Ud�losti quida
    procedure QuidoOpened(sender:TObject);
    procedure QuidoClosed(sender:TObject);
    procedure QuidoInputChange(sender:TObject;Index:integer;Old:boolean;New:boolean);
    procedure QuidoOutputsChange(sender:TObject);
  public
    procedure DisplayQuido;
    procedure RefreshQuido(quick:boolean=true);
  end;

var
  fQuidoDemo: TfQuidoDemo;

implementation

{$R *.dfm}

procedure TfQuidoDemo.cmdCreateQClick(Sender: TObject);
begin
  if assigned(Quido) then //-- zru�en� p��padn�ho p�edchoz�ho quida
  begin
    FreeAndNil(Quido);
    lblQuidoID.Caption := '';
    gbOvladani.Visible := false;
  end;
  try
    Quido := TQuido.Create(ConnectionString.Text,QuidoParams.Text); //-- vytvo�� nov� objekt quida s dan�my parametry
  except
    on E:exception do MessageDlg(e.Message,mtError,[mbOK],0);
  end;
  if assigned(Quido) then //-- pokud se poda�ilo vytvo�it
  begin
    //-- namapov�n� ud�lost� otev�en� a zav�en� komunikace s quidem
    Quido.OnOpen := QuidoOpened;
    Quido.OnClose := QuidoClosed;
    if MessageDlg('Byl vytvo�en objekt quida. Chcete ho otev��t?',mtInformation,[mbYes,mbNo],0)=IDYES
     then Quido.Open; //-- otev�en� komunikace s quidem
  end;

  Timer1.Enabled := false;
end;

procedure TfQuidoDemo.cmdOpenClick(Sender: TObject);
begin
  if assigned(Quido) then Quido.Open else ShowMessage('Objekt Quida nebylo vytvo�en!');
                          //-otev�e se komunikace s quidem
end;

procedure TfQuidoDemo.cmdCloseClick(Sender: TObject);
begin
  if assigned(Quido) then Quido.Close else ShowMessage('Objekt Quida nebylo vytvo�en!');
                         //-zav�e se komunikace s quidem
end;

procedure TfQuidoDemo.QuidoClosed(sender: TObject);
begin
  //-- p�i zav�en� komunikace s quidem
  gbOvladani.Visible := false;
  Timer1.Enabled := false;
  //--odmapov�n� ud�lost� quida
  Quido.OnInputChange := nil;
  Quido.OnOutputsChange := nil;
end;


procedure TfQuidoDemo.QuidoOpened(sender: TObject);
begin
  //-- p�i otev�en� komunikace s quidem
  DisplayQuido;
  Timer1.Enabled := chPeriod.Checked;
end;

procedure TfQuidoDemo.QuidoOutputsChange(sender: TObject);
var i:integer;
    LWI:TListItem;
begin
  //-- p�i zji�t�n� zm�n� stavu n�kter�ch v�stup�
  if assigned(Quido) then
  for i:=0 to Quido.OutputsCount - 1 do
  begin
     LWI:=lwOutputs.Items.Item[i];
     LWI.Checked := Quido.RecentOutputState[i];
     if LWI.Checked then LWI.SubItems.Strings[0] := 'Sepnuto' else LWI.SubItems.Strings[0] := 'Rozepnuto';
  end;
end;

procedure TfQuidoDemo.DisplayQuido;
var i,x:integer;
    LWI:TListItem;
    R,F:boolean;
    s:string;
begin
  //Na�ten� informac� o Quidu a zobrazen� na formul��i, vyps�n� jeho v�stupu, vstup� a ��ta��
  //Pokud je Quido NIL, informace se schovaj�

  if assigned(Quido) then
  begin
    //-- vyps�n� identifikace
    lblQuidoID.Caption := Quido.DeviceInfo;

    //-- na�ten� vstup�
    lwInputs.Clear;
    Quido.RefreshInputs(true);
    x:=Quido.InputsCount;
    for i:=0 to x-1 do
    begin
      LWI:=lwInputs.Items.Add;
      try
        LWI.Caption := inttostr(i+1);
        if Quido.RecentInputState[i] then LWI.ImageIndex := 1 else LWI.ImageIndex := 0;
        if Quido.InputCountersCount>i then
        begin
          LWI.SubItems.Add(inttostr(Quido.GetInputCounterValue(i,false)));
          Quido.GetCounterSetting(I,R,F);
          if F and R
            then S:='Ob�'
            else if R then S:='N�b�n�'
            else if F then S:='Sestupn�'
            else S:='Vypnuto';
          LWI.SubItems.Add(S)
        end;
      except
      end;
    end;
    //-- na�ten� v�stup�
    lwOutputs.Items.Clear;
    Quido.RefreshOutputs(true);
    x:=Quido.OutputsCount;
    for i:=0 to x-1 do
    begin
      try
        LWI:=lwOutPuts.Items.Add;
        LWI.Caption := inttostr(i+1);
        if Quido.RecentOutputState[i] then
        begin
          LWI.Checked := true;
          LWI.SubItems.Add('Sepnuto');
        end else
        begin
          LWI.Checked := false;
          LWI.SubItems.Add('Rozepnuto');
        end;
      except
      end;
    end;
    //--automatick� vys�l�n�
    chAuto.Checked := Quido.AutoInputNotification;
    //--namapov�n� ud�lost� quida
    Quido.OnInputChange := QuidoInputChange; //-- vyvol� se pro ka�d� zm�n�n� vstup zvl᚝
    Quido.OnOutputsChange := QuidoOutputsChange; //-- vyvol� se hromadn� p�i zji�t�n� zm�n� n�kter�ho v�stupu

    gbOvladani.Visible := true;
  end else
  begin
    //schov�n�
    lblQuidoID.Caption := '';
    gbOvladani.Visible := false;
  end;
end;

procedure TfQuidoDemo.Vynulovatta1Click(Sender: TObject);
begin
  //-- Vynuluje ��ta� vybran�ho vstupu
  if lwInputs.ItemIndex >=  0 then Quido.GetInputCounterValue(lwInputs.ItemIndex,true);
end;

procedure TfQuidoDemo.QuidoInputChange(sender: TObject; Index: integer; Old,
  New: boolean);
var LWI:TListItem;
    R,F:boolean;
    S:string;
begin
  //-- p�i zji�t�n� zm�n� vstupu
try
  LWI:=lwInputs.Items.Item[Index];
  if assigned(LWI) then
  with LWI do
  begin
    if Quido.RecentInputState[Index]
      then ImageIndex := 1
      else ImageIndex := 0;
    SubItems.Strings[0]:=inttostr(Quido.GetInputCounterValue(index,false));
    Quido.GetCounterSetting(Index,R,F);
    if F and R
      then S:='Ob�'
      else if R then S:='N�b�n�'
      else if F then S:='Sestupn�'
      else S:='Vypnuto';
    SubItems.Strings[1]:=S;
  end;
except
end;
end;

procedure TfQuidoDemo.cmdResetClick(Sender: TObject);
begin
  //-- Resetuje quido. pokud se periodicky zobrazuj� stavy, odd�l� se prvn� zji��ov�n� za 3 vte�iny
  if Timer1.Enabled then Timer1.Interval := 3000;
  Quido.Reset;
end;

procedure TfQuidoDemo.lwOutputsChange(Sender: TObject; Item: TListItem;
  Change: TItemChange);
  var s:string;
begin
 //-- Zm�na n�kter� polo�ky v seznamu v�stup� (v ListView)...
 //-- Zjist�me zda u�ivatel necht�l zm�nit stav v�stupu za�krt�vac�m pol��kem
 //  , pokud ano, provede se zm�na v�stupu na quidu ...
 if assigned(Quido) then  // ... je vytvo�eno quido ...
  if Change = ctState then //... mohlo by se jednat o za�krtnut� pol��ka ...
   if assigned(Quido.OnOutputsChange) then //... nejedn� se o ud�lost vzniklou p�i vytv��en� polo�ky v ListView ...
    if Item.Checked <> Quido.RecentOutputState[Item.Index] //... za�krt�v�tko neodpov�da stavu v�stupu ...
      then Quido.OutputState[Item.Index]:=Item.Checked; //... Zm�n�me stav v�stupu
end;

procedure TfQuidoDemo.chRefreshClick(Sender: TObject);
begin
  //-- zobraz� aktu�ln� stavy quida (vstupy, v�stupy, ��ta�e)
  RefreshQuido(false);
end;

procedure TfQuidoDemo.Timer1Timer(Sender: TObject);
begin
  try
   if assigned(Quido) and Quido.Active then
   begin
     //- pokud je quido otev�en�, obnov� se zobrazen� jeho stav�:
     RefreshQuido;
   end;
  except
  end;
  Timer1.Interval := 500;
end;

procedure TfQuidoDemo.chPeriodClick(Sender: TObject);
begin
  //- zapne (nebo vypne) se �asova�, kter� periodicky zobrazuje aktu�ln� stavy quida 
  Timer1.Enabled := chPeriod.Checked;
end;

procedure TfQuidoDemo.RefreshQuido(quick:boolean=true);
var B:boolean;
    i,x:integer;
    LWI:TListItem;
    R,F:boolean;
    s:string;
begin
  //- Obnov� zobrazen� stav� v�stup�, vstup� a ��ta��

  if Quick then
  begin
      Quido.RefreshInputs;
      Quido.RefreshOutputs;
      b:=Quido.AutoInputNotification;
      if b<>chAuto.Checked then chAuto.Checked := Quido.AutoInputNotification;
  end else
  begin
      b:=Quido.AutoInputNotification;
      if b<>chAuto.Checked then chAuto.Checked := Quido.AutoInputNotification;
      Quido.RefreshInputs;
      x:=Quido.InputsCount;
      for i:=0 to x-1 do
      begin
          LWI:=lwInputs.Items.Item[i];
          if assigned(LWI) then
          with LWI do
          begin
            if Quido.RecentInputState[i] then ImageIndex := 1 else ImageIndex := 0;
            SubItems.Strings[0]:=inttostr(Quido.GetInputCounterValue(index,false));
            Quido.GetCounterSetting(Index,R,F);
            if F and R
              then S:='Ob�'
              else if R then S:='N�b�n�'
              else if F then S:='Sestupn�'
              else S:='Vypnuto';
            SubItems.Strings[1]:=S;

          end;
      end;
      Quido.RefreshOutputs;
      x:=Quido.OutputsCount;
      for i:=0 to x - 1 do
      begin
         LWI:=lwOutputs.Items.Item[i];
         if assigned(LWI) then
         begin
           LWI.Checked := Quido.RecentOutputState[i];
           if LWI.Checked then LWI.SubItems.Strings[0] := 'Sepnuto' else LWI.SubItems.Strings[0] := 'Rozepnuto';
         end;
      end;
  end;
end;

procedure TfQuidoDemo.chAutoClick(Sender: TObject);
begin
  //-- Nastav� nebo zru�� se v Quidu automatick� vys�l�n� zm�ny vstup�
  Quido.AutoInputNotification := chAuto.Checked;
end;

procedure TfQuidoDemo.Zmnitstavnaas1Click(Sender: TObject);
var s:string;
    i:integer;
begin
  //-- zm�n� stav v�stupu na zadanou dobu ve vte�in�ch
  s:='5';
  if lwOutputs.ItemIndex >=  0 then
   if InputQuery('Zm�nit stav v�stupu na �as','Zadejte �as (sec)',S) then
     if TryStrToInt(s,i) then
     begin
      Quido.SetOutputStateTimed(lwOutputs.ItemIndex,not Quido.RecentOutputState[lwOutputs.ItemIndex],i);
      Quido.RefreshOutputs(true);
     end;
end;

procedure TfQuidoDemo.FormDestroy(Sender: TObject);
begin
  Timer1.Enabled := false;
  freeandnil(Quido);
end;

procedure TfQuidoDemo.cmdDlgClick(Sender: TObject);
var s:AnsiString;
begin
  //--- Vytvo�en� p�ipojovac�ho �et�zce pomoc� dialogu
  s:=ConnectionString.Text;
  if TQuido.ConnectionStringDlg(S)
   then ConnectionString.Text := s;
end;

procedure TfQuidoDemo.Vypnuto1Click(Sender: TObject);
begin
  //-- Vypnut� ��ta�e vybran�ho vstupu
  if lwInputs.ItemIndex >=  0 then
  begin
    Quido.SetCounterSetting(lwInputs.ItemIndex,false,false);
    RefreshQuido(false);
  end;
end;

procedure TfQuidoDemo.Nbnhrana1Click(Sender: TObject);
begin
  //-- Nastaven� ��ta�e vybran�ho vstupu na n�b�nou hranu
  if lwInputs.ItemIndex >=  0 then
  begin
    Quido.SetCounterSetting(lwInputs.ItemIndex,true,false);
    RefreshQuido(false);
  end;
end;

procedure TfQuidoDemo.Sestupnhrana1Click(Sender: TObject);
begin
  //-- Nastaven� ��ta�e vybran�ho vstupu na sestupnou hranu
  if lwInputs.ItemIndex >=  0 then
  begin
    Quido.SetCounterSetting(lwInputs.ItemIndex,false,true);
    RefreshQuido(false);
  end;
end;

procedure TfQuidoDemo.Ob1Click(Sender: TObject);
begin
  //-- Nastaven� ��ta�e vybran�ho vstupu na ob� hrany
  if lwInputs.ItemIndex >=  0 then
  begin
    Quido.SetCounterSetting(lwInputs.ItemIndex,true,true);
    RefreshQuido(false);
  end;
end;

end.
