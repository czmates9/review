program QuidoDllSample;

uses
  Forms,
  uf_QuidoSample in 'uf_QuidoSample.pas' {fQuidoDemo},
  uo_Quido in '..\uo_Quido.pas',
  q_QuidoDllMapD in '..\q_QuidoDllMapD.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.Title := 'User quido DLL test application';
  Application.CreateForm(TfQuidoDemo, fQuidoDemo);
  Application.Run;
end.
