<?xml version="1.0" encoding="windows-1250"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
	<xsl:output method="html" encoding="windows-1250"/>
	<xsl:template match="library">
		<html>
			<head>
  			<link type="text/css" href="library_base.css" rel="StyleSheet" title="css"/>
				<title>
					<xsl:value-of select="name"/>
				</title>
			</head>
			<body>
        <a name="_top"/>
        <div class="libdoc">
				<div class="libname">
					<xsl:value-of select="name"/>
				</div>
				<div class="libtitle">
					<xsl:value-of select="title"/>
				</div>
				<div class="libdesc">
					<xsl:value-of select="description"/>
				</div>
				<div class="constsdoc">
  				<div class="constshead">Konstanty</div>
  				<xsl:for-each select="constants">
            <xsl:for-each select="./group">
              <div class="grpdoc">
                <div class="grpname">
                  <xsl:value-of select="./name"/>
                </div>
                <xsl:for-each select="./constants/constant">
                  <div class="constdoc">
                    <xsl:value-of select="./name"/>
                    (
                    <xsl:value-of select="./value"/>
                    )
                  </div>
                </xsl:for-each>
              </div>
            </xsl:for-each>
              <div class="grpdoc">
                <xsl:for-each select="./constant">
                  <div class="constdoc">
                    <xsl:value-of select="./name"/>
                    (
                    <xsl:value-of select="./value"/>
                    )
                  </div>
                </xsl:for-each>
              </div>
  				</xsl:for-each>
				</div>


				<div class="typesdoc">
  				<div class="typeshead">Typy</div>
  				<xsl:for-each select="types/type">
              <div class="typedoc">
                <div class="typename"><xsl:value-of select="./name"/></div>
                <div class="typedesc"><xsl:value-of select="./description"/></div>
                <div class="typedefs">
                    Delphi: <div class="typedef"><xsl:value-of select="./definition/delphi"/></div>
                    C++: <div class="typedef"><xsl:value-of select="./definition/cpp"/></div>
                    Visual Basic: <div class="typedef"><xsl:value-of select="./definition/vbasic"/></div>
                 </div>
              </div>
  				</xsl:for-each>
				</div>
				
				<div class="typesdoc">
  				<div class="typeshead">Funkce</div>
  				<div class="fcelist">
          <a name="function_list"/>
  				<xsl:for-each select="./functions/function">
                <div class="typename">
                   <a>
                    <xsl:attribute name="href">
                      	<xsl:value-of select="concat('#',./name)"/>
                    </xsl:attribute>
                    <xsl:value-of select="./name"/>
                  </a>
                </div>
  				</xsl:for-each>
  				</div>

  				<xsl:for-each select="./functions/function">
                <div class="fcedoc">
                   <a>
                    <xsl:attribute name="name">
                      	<xsl:value-of select="./name"/>
                    </xsl:attribute>
                    <div class="fcename"><xsl:value-of select="./name"/></div>
                    <div class="fcedesc"><xsl:value-of select="./description"/></div>
                    <div class="fceparams">
                       <div class="paramhead">Parametry</div>
                       <xsl:for-each select="./parametters/parametter">
                          <div class="fceparam">
                            <div class="paramname"><xsl:value-of select="./name"/></div>
                            <div class="paramdesc"><xsl:value-of select="./description"/></div>
                          </div>
                       </xsl:for-each>
                       <div class="paramhead">N�vratov� hodnota</div>
                       <div class="paramdesc"><xsl:value-of select="./parametters/result/description"/></div>
                    </div>
                    <div class="fcedefs">
                      <div class="fcedefhead">Definice</div>
                      Delphi: <div class="fcedef"><xsl:value-of select="./definition/delphi"/></div>
                      C++: <div class="fcedef"><xsl:value-of select="./definition/cpp"/></div>
                      Visual basic: <div class="fcedef"><xsl:value-of select="./definition/vbasic"/></div>
                    </div>
                    <div class="fceback"><a href="#function_list">seznam funkc�</a></div>
                  </a>
                </div>
  				</xsl:for-each>

				</div>


				<!--	<hr/>
        [<xsl:value-of select="./version"/>]
        <xsl:value-of select="./date"/>
					<xsl:value-of select="concat(substring(./date/@date,6,8),'.',substring(./date/@date,9,11)) "/>
					<xsl:for-each select="point">
						<li>
							<xsl:value-of select="."/>
						</li>
					</xsl:for-each>
				</xsl:for-each>
				-->
			 </div>
			</body>
		</html>
	</xsl:template>
</xsl:stylesheet>
