Attribute VB_Name = "modCommSample"
Option Explicit
Public CiHandle As Long

'Callbackov� funkce pro p��jem ud�lost� komunika�n�ho rozhran�
Public Sub CallBackEvent(ByVal Handle As Long, ByVal EventType As Integer, ByVal Param As Integer)
  Dim I As Long
  Dim S As String
  Select Case EventType
    Case ciev_Open
       fCommSample.OnOpen
    Case ciev_Close
       fCommSample.OnClose
    Case ciev_DataRcv
       I = ciReadLength(CiHandle)
       If I > 0 Then
         S = String(I, " ")
         If ciRead(CiHandle, S, I) = 0 Then
           S = Left(S, I)
           fCommSample.OnDataRcv S
         End If
       End If
       
  End Select
End Sub

'Pomocn� funkce - p�evod dat z hexa a do hexa z�pisu
Public Function TextToHex(Text As String) As String
 Dim I As Integer
 Dim Ch As String
 TextToHex = ""
 For I = 1 To Len(Text)
   Ch = Hex(Asc(Mid(Text, I, 1)))
   If Len(Ch) < 2 Then Ch = "0" + Ch
   TextToHex = TextToHex + Ch + " "
 Next I
End Function
Public Function HexToInt(Hex As String) As Integer
  HexToInt = 0
  Dim I As Integer
  Dim V As Integer
  For I = 1 To Len(Hex)
     Select Case Mid(Hex, I, 1)
       Case "0" To "9"
         V = Asc(Mid(Hex, I, 1)) - Asc("0")
       Case "a" To "f"
         V = Asc(Mid(Hex, I, 1)) - Asc("a") + 10
       Case "A" To "F"
         V = Asc(Mid(Hex, I, 1)) - Asc("A") + 10
       Case Else
         V = 0
     End Select
     HexToInt = HexToInt * 16 + V
  Next I
End Function

Public Function HexToText(HexText As String) As String
  Dim I As Integer, X As Integer
  Dim S As String
  Dim Ch As String
  HexToText = ""
  S = Replace(HexText, " ", "")
  S = Replace(S, Chr(13), "")
  S = Replace(S, Chr(10), "")
  
  For I = 0 To Len(S) \ 2 - 1
    Ch = Mid(S, I * 2 + 1, 2)
    X = HexToInt(Ch)
    HexToText = HexToText + Chr(X)
  Next I
End Function
Public Function TextPrintable(ByVal Text As String) As String
  Dim I As Integer
  For I = 1 To Len(Text)
    If (Asc(Mid(Text, I, 1)) < 10) Or (Asc(Mid(Text, I, 1)) > 127) Then Mid(Text, I, 1) = "."
  Next I
  TextPrintable = Text
End Function
