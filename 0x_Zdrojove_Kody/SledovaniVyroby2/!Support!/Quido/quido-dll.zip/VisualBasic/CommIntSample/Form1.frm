VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "mscomctl.ocx"
Begin VB.Form fCommSample 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Uk�zka pou�it� CommIntfDll.dll"
   ClientHeight    =   6165
   ClientLeft      =   2475
   ClientTop       =   2250
   ClientWidth     =   6300
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6165
   ScaleWidth      =   6300
   StartUpPosition =   2  'CenterScreen
   Begin VB.Frame Frame1 
      Caption         =   "P�ipojovac� �et�zec"
      Height          =   1335
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   6015
      Begin VB.CommandButton cmdOpenClose 
         Caption         =   "Otev��t"
         Height          =   375
         Left            =   2040
         TabIndex        =   8
         Top             =   840
         Width           =   1575
      End
      Begin VB.CommandButton cmdCreate 
         Caption         =   "Vytvo�it"
         Height          =   375
         Left            =   120
         TabIndex        =   3
         Top             =   840
         Width           =   1695
      End
      Begin VB.CommandButton Command1 
         Caption         =   "..."
         Height          =   330
         Left            =   5280
         TabIndex        =   2
         Top             =   360
         Width           =   615
      End
      Begin VB.TextBox ConnectionString 
         Height          =   330
         Left            =   120
         TabIndex        =   1
         Text            =   "provider=TCP_CLIENT;host=192.168.1.254;port=10001"
         Top             =   360
         Width           =   5055
      End
   End
   Begin VB.PictureBox pnlProsta 
      BorderStyle     =   0  'None
      Height          =   3975
      Left            =   240
      ScaleHeight     =   3975
      ScaleWidth      =   5775
      TabIndex        =   5
      Top             =   1920
      Width           =   5775
      Begin VB.Frame Frame3 
         Caption         =   "P�ijat� data"
         Height          =   1815
         Left            =   0
         TabIndex        =   13
         Top             =   2160
         Width           =   5655
         Begin VB.CommandButton cmdClearRcv 
            Caption         =   "Vymazat"
            Height          =   375
            Left            =   4320
            TabIndex        =   16
            Top             =   240
            Width           =   1215
         End
         Begin VB.TextBox txtRcv 
            Height          =   975
            Left            =   120
            MultiLine       =   -1  'True
            ScrollBars      =   2  'Vertical
            TabIndex        =   15
            Top             =   720
            Width           =   5415
         End
         Begin VB.CheckBox chHexRcv 
            Caption         =   "P�ijat� data zobrazovat v hexa"
            Height          =   255
            Left            =   120
            TabIndex        =   14
            Top             =   240
            Width           =   3855
         End
      End
      Begin VB.Frame Frame2 
         Caption         =   "Odeslat data"
         Height          =   2055
         Left            =   0
         TabIndex        =   7
         Top             =   0
         Width           =   5655
         Begin VB.CommandButton cmdSend 
            Caption         =   "Odeslat >"
            Enabled         =   0   'False
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   238
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   4200
            TabIndex        =   12
            Top             =   1560
            Width           =   1335
         End
         Begin VB.CommandButton cmdClear 
            Caption         =   "Vymazat"
            Height          =   375
            Left            =   120
            TabIndex        =   11
            Top             =   1560
            Width           =   1215
         End
         Begin VB.TextBox txtSnd 
            Height          =   855
            Left            =   120
            MultiLine       =   -1  'True
            ScrollBars      =   2  'Vertical
            TabIndex        =   9
            Top             =   600
            Width           =   5415
         End
         Begin VB.CheckBox chHexSnd 
            Caption         =   "Data jsou zad�na v hexa (FA 2C 23)"
            Height          =   255
            Left            =   120
            TabIndex        =   10
            Top             =   240
            Width           =   3615
         End
      End
   End
   Begin MSComctlLib.TabStrip TabCom 
      Height          =   4455
      Left            =   120
      TabIndex        =   4
      Top             =   1560
      Width           =   6015
      _ExtentX        =   10610
      _ExtentY        =   7858
      _Version        =   393216
      BeginProperty Tabs {1EFB6598-857C-11D1-B16A-00C0F0283628} 
         NumTabs         =   2
         BeginProperty Tab1 {1EFB659A-857C-11D1-B16A-00C0F0283628} 
            Caption         =   "Prost� komunikace"
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab2 {1EFB659A-857C-11D1-B16A-00C0F0283628} 
            Caption         =   "Spinel"
            ImageVarType    =   2
         EndProperty
      EndProperty
   End
   Begin VB.PictureBox pnlSpinel 
      BorderStyle     =   0  'None
      Height          =   3975
      Left            =   240
      ScaleHeight     =   3975
      ScaleWidth      =   5775
      TabIndex        =   6
      Top             =   1920
      Width           =   5775
      Begin VB.Frame Frame5 
         Caption         =   "P�ijat� spinel paket"
         Height          =   2055
         Left            =   0
         TabIndex        =   28
         Top             =   1920
         Width           =   5775
         Begin VB.TextBox txtSRcv 
            Height          =   735
            Left            =   240
            MultiLine       =   -1  'True
            TabIndex        =   35
            Top             =   1200
            Width           =   5295
         End
         Begin VB.TextBox txtAck 
            Height          =   285
            Left            =   2280
            TabIndex        =   33
            Top             =   480
            Width           =   1335
         End
         Begin VB.TextBox txtRSig 
            Height          =   285
            Left            =   1200
            TabIndex        =   31
            Top             =   480
            Width           =   975
         End
         Begin VB.TextBox txtRAdr 
            Height          =   285
            Left            =   240
            TabIndex        =   29
            Top             =   480
            Width           =   855
         End
         Begin VB.CheckBox chHexSRcv 
            Caption         =   "P�ijat� data zobrazit v hexa"
            Height          =   255
            Left            =   840
            TabIndex        =   37
            Top             =   960
            Width           =   3255
         End
         Begin VB.Label Label8 
            Caption         =   "Data"
            Height          =   255
            Left            =   240
            TabIndex        =   36
            Top             =   960
            Width           =   495
         End
         Begin VB.Label Label7 
            Caption         =   "Ack (n�vratov� k�d)"
            Height          =   255
            Left            =   2280
            TabIndex        =   34
            Top             =   240
            Width           =   1575
         End
         Begin VB.Label Label6 
            Caption         =   "Sig (podpis)"
            Height          =   255
            Left            =   1200
            TabIndex        =   32
            Top             =   240
            Width           =   975
         End
         Begin VB.Label Label5 
            Caption         =   "Adresa"
            Height          =   255
            Left            =   240
            TabIndex        =   30
            Top             =   240
            Width           =   735
         End
      End
      Begin VB.Frame Frame4 
         Caption         =   "Odeslat spinel paket"
         Height          =   1815
         Left            =   0
         TabIndex        =   17
         Top             =   0
         Width           =   5775
         Begin VB.TextBox txtSSnd 
            Height          =   495
            Left            =   240
            MultiLine       =   -1  'True
            TabIndex        =   25
            Top             =   1200
            Width           =   5295
         End
         Begin VB.CommandButton cmdSSend 
            Caption         =   "Odeslat >"
            Enabled         =   0   'False
            Height          =   330
            Left            =   3720
            TabIndex        =   24
            Top             =   430
            Width           =   1455
         End
         Begin VB.TextBox txtInst 
            Height          =   285
            Left            =   2280
            TabIndex        =   22
            Text            =   "243"
            Top             =   480
            Width           =   1335
         End
         Begin VB.TextBox txtSig 
            Height          =   285
            Left            =   1200
            TabIndex        =   20
            Text            =   "0"
            Top             =   480
            Width           =   975
         End
         Begin VB.TextBox txtAdr 
            Height          =   285
            Left            =   240
            TabIndex        =   18
            Text            =   "254"
            Top             =   480
            Width           =   855
         End
         Begin VB.CheckBox chHexSData 
            Caption         =   "Data jsou zad�na v hexa"
            Height          =   255
            Left            =   840
            TabIndex        =   27
            Top             =   960
            Width           =   3255
         End
         Begin VB.Label Label4 
            Caption         =   "Data"
            Height          =   255
            Left            =   240
            TabIndex        =   26
            Top             =   960
            Width           =   495
         End
         Begin VB.Label Label3 
            Caption         =   "Instrukce"
            Height          =   255
            Left            =   2280
            TabIndex        =   23
            Top             =   240
            Width           =   735
         End
         Begin VB.Label Label2 
            Caption         =   "Sig (podpis)"
            Height          =   255
            Left            =   1200
            TabIndex        =   21
            Top             =   240
            Width           =   975
         End
         Begin VB.Label Label1 
            Caption         =   "Adresa"
            Height          =   255
            Left            =   240
            TabIndex        =   19
            Top             =   240
            Width           =   735
         End
      End
   End
End
Attribute VB_Name = "fCommSample"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Public Sub OnOpen()
  cmdSend.Enabled = True
  cmdSSend.Enabled = True
  TabCom_Click
  cmdOpenClose.Caption = "Zav��t"
End Sub
Public Sub OnClose()
  cmdSend.Enabled = False
  cmdSSend.Enabled = False
  cmdOpenClose.Caption = "Otev��t"
End Sub
Public Sub OnDataRcv(Data As String)
  Dim S As String
  S = Data
  If chHexRcv.Value Then S = TextToHex(S) Else S = TextPrintable(S)
  txtRcv.Text = txtRcv.Text + S
End Sub

Private Sub cmdClear_Click()
  txtSnd.Text = ""
End Sub

Private Sub cmdClearRcv_Click()
  txtRcv.Text = ""
End Sub

Private Sub cmdCreate_Click()

  If CiHandle <> 0 Then 'Zru�en� p�vodn�ho rozhran�, pokud je vytvo�eno
    ciRelease CiHandle
    CiHandle = 0
    OnClose
  End If
  
  'Vytvo�� komunika�n� rozhran� podle p�ipojovac�ho �et�zce
  CiHandle = ciCreate(ConnectionString.Text)
  
  If CiHandle <> 0 Then
    'Zaregistruje p��jem ud�lost� (otev�en�, zav�en�, p��jem dat)
    ciRegisterCallBackNotifications CiHandle, AddressOf CallBackEvent, 0
  Else
    MsgBox "Rozhran� nebylo vytvo�eno"
  End If
  
End Sub

Private Sub cmdOpenClose_Click()
  Dim I As Long
  If CiHandle = 0 Then
    MsgBox "Rozhran� nebylo vytvo�eno"
  Else
    If ciIsActive(CiHandle, I) = 0 Then
      If I <> 0 Then ciClose CiHandle Else ciOpen CiHandle
    Else
      MsgBox "Chyba"
    End If
  End If
End Sub

Private Sub cmdSend_Click()
 Dim S As String
 S = txtSnd.Text
 If chHexSnd.Value Then S = HexToText(S)
 If (ciWrite(CiHandle, S, Len(S)) <> 0) Then MsgBox "Nebylo odesl�no"
End Sub


Private Sub Command1_Click()
  Dim S As String
  Dim Ln As Long
  Dim Ret As Long
  
  Ln = 512
  S = String(Ln, " ")
  If (ciGetConnectionStringDlg(S, Ln, Ret, ConnectionString.Text, "P�ipojovac� �et�zec") = 0) And (Ret) Then
    S = Left(S, Ln)
    ConnectionString.Text = S
  End If
End Sub

Private Sub cmdSSend_Click()
  Dim Dat As String
  Dim Adr As Byte, Sig As Byte, Inst As Byte, Ack As Byte
  If chHexSData.Value Then Dat = HexToText(txtSSnd.Text) Else Dat = txtSSnd.Text
  Adr = CByte(txtAdr.Text)
  Sig = CByte(txtSig.Text)
  Inst = CByte(txtInst.Text)
  If SndRcvSpin97(CiHandle, Adr, Sig, Inst, Dat, Ack, Dat) Then
    txtRAdr.Text = CStr(Adr)
    txtRSig.Text = CStr(Sig)
    txtAck.Text = CStr(Ack)
    If chHexSRcv.Value Then txtSRcv.Text = TextToHex(Dat) Else txtSRcv.Text = TextPrintable(Dat)
  Else
    MsgBox "Nezda�ilo se p�edat instrukci"
  End If
End Sub


Private Sub Form_Unload(Cancel As Integer)
 If CiHandle <> 0 Then ciRelease CiHandle
End Sub

Private Sub TabCom_Click()
  If TabCom.SelectedItem.index = 1 Then pnlProsta.ZOrder 0 Else pnlSpinel.ZOrder 0
End Sub

Private Sub Text4_Change()

End Sub
