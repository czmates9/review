Attribute VB_Name = "uci_IDllMap"
'
'  CommIntfDll - Mapov�n� funkc� z knihovny CommIntfDll.dll
'  Vytvo�eno pro Delphi 7
'
'  Vydavatel :  Papouch s.r.o. - http://www.papouch.com/
'  Autor     :  Martin Z�me�n�k zamecnik@papouch.com
'
'  popis     : knihovna umo��uje komunikaci nejen se za��zen�mi firmy papouch s.r.o. p�es s�riov� port, usb a ethernet (TCP nebo UDP)
'              komunika�n� spojen� se vytv��� pomoc� funkc� ciCreate a p�edan�ho p��pojovac�ho �et�zce (ten ur�uje, o jak� rozhrann� se jend�, a dal�� parametry),
'              tyto funkce vracej� Handle (madlo) komunika�n�ho rozhrann�, kter� se pak p�ed�v� ostatn�m funkc�m
'              v�echny funkce jsou spole�n� pro v�echny typy rozhrann�. funkce s n�vratovou hodnotou reStat (integer) vracej� ERR_OK (0) pokud v�e prob�lo v po��dku, jinak chybov� k�d
'
'  Pozn�mky  : k pou�it� funkc� je pot�eba knihovna CommIntfDll.dll,
'              v p��pad� pou�it� pro USB jsou pot�eba t� nainstalovan� ovlada�e FTD direct drivers a knihova FTD2XX.dll, nebo nainstalovan� virtu�ln� s�riov� port
              
Option Explicit

Public Const ciev_Base = 255  '-- Konstanty pro Typ ud�losti komunika�n�ho rozhran�
Public Const ciev_Open = ciev_Base + 1
Public Const ciev_Close = ciev_Base + 2
Public Const ciev_DataRcv = ciev_Base + 3
Public Const ciev_Error = ciev_Base + 4

'***funkce pro spr�vu chyb***
Public Declare Function LastError Lib "CommIntfDll.dll" () As Long '-- Zjist� ��slo posledn� chyby
Public Declare Function LastErrorText Lib "CommIntfDll.dll" (ByVal Text As String, ByRef Size As Long) As Long
                       '-- Z�sk� text posledn� chyby. Text=buffer, do kter�ho bude text p�ed�n, Size=velikost bufferu Text, zp�t vr�t� po�et znak� textu.
                       '-- Pokud je Size men�� ne� pot�ebn� velikost pro text, je n�vratov� hodnota ERR_MoreSize a do Size se nastav� pot�ebn� velikost
                       '-- Pokud je Text NIL, pouze se do Size vr�t� pot�ebn� velikost bufferu pro text
                       '-- Pokud v�e prob�hlo v po��dku, vr�t� se ERR_OK (0)
                       '-- pozn. tento princip funguje u v�t�iny funkc�, kde se z�sk�v� textov� hodnota
Public Declare Function SetLastError Lib "CommIntfDll.dll" (ByVal ErrNum As Long, ByVal Text As String) As Long
                      '-- Nastav� Chybu. P�ed�v� se ��slo chyby a text chyby
'*** info ***
Public Declare Function Info Lib "CommIntfDll.dll" () As String '-- Vr�t� informa�n� text o knihovn�

'*** funkce pro pr�ci s komunika�n�m rozhrann�m ****
Public Declare Function ciCreate Lib "CommIntfDll.dll" (ByVal ConnectionString As String) As Long '-- Vytvo�� komunika�n� rozhrann� podle zadan�ho p�ipojovac�ho �et�zce
    '--       connection string je �et�zec pro vytvo�en� komunika�n�ho rozhrann�, ur�uje komunika�n� kan�l a jeho nastaven� (s�riov� port, tcp, udp, nebo ftd_usb)
    '   Tvorba connectionstringu  as  jsou to hodnoty ve tbyrefu "parametr=hodnota" odd�Leny st�edn�kem. ur�uj� typ p�ipojen�
    '          nejd�le�it�j��m parametrem je "provider", ur�uje typ rozhrann�. m��e to b�t SERIAL_PORT, TCP_CLIENT, UDP_CLIENT nebo FTD_USB
    '          ka�d� kan�l pak m��e m�t dal�� parametry. SERIAL_PORT (comport=��slo portu,baudrate=rychlost - nemus� b�t zad�no), TCP_CLIENT(host=ip adresa za��zen�,port=tcp port za��zen�), UDP_CLIENT(stejn� jako TCP),
    '                                                    FTD_USB(index=po�adov� ��slo za��zen�, nebo device=��st n�zvu za��zen�, nebo serial_number=s�riov� ��slo za��zen�, nebo vid=vid,pid=pid, nebo nemus� m�t ��dn� parametr, vezme se prvn� p�ipojen� za��zen� typu FTD_USB
    '          p��klady as  "provider=SERIAL_PORT,comport=1", "provider=TCP_CLIENT,host=192.168.1.254,port=10001", "provider=UDP_CLIENT,host=192.168.1.254,port=10001", "provider=FTD_USB,device=Quido"
    '          N�vratov� hodnota je Handle na vytvo�en� komunika�n� rozhrann�. 0 = Nebylo vytvo�eno

Public Declare Function ciCreateM Lib "CommIntfDll.dll" (ByVal ConnectionString As String, ByVal NotificationHWND As Long, ByVal Msg As Long, ByVal Blocking As Boolean) As Long
                      '-- vytvo�� komunika�n� rozhrann� viz. ciCreate, nav�c zaregistruje p��jem ud�lost� pomoc� windows zpr�v.
                      '   Notificationlong = handle okna kam maj� zpr�vy chodit, Msg = Jak� zpr�va se bude zas�lat,
                      '   Blocking=jakou medodou budou zpr�vy zas�l�ny as  true-SendMessage-rozhrann� �ek� na zpracov�n� ud�lost�, false-PostMessage-rozhrann� asynchronn� za�le upozorn�n� o ud�losti a ne�ek� na jeho zpracov�n�
                      '   viz. ciRegisterMsgNotifications
Public Declare Function ciCreateCB Lib "CommIntfDll.dll" (ByVal ConnectionString As String, ByVal CallBackEntryPoint As Long, ByVal CallBackID As Long) As Long
                      '-- vytvo�� komunika�n� rozhrann� viz. ciCreate, nav�c zaregistruje p��jem ud�lost� pomoc� CallBackov� funkce
                      '   CallBackEntryPoint = vstupn� bod Callbackov� funkce typu longNotificationEvent
                      '   CallBackID = voliteln� parametr, kter� bude zp�t zas�l�n p�i zp�tn�m vol�n� (voliteln� identifikace)
                      '   viz. ciRegisterCallBackNotifications
Public Declare Function ciOpen Lib "CommIntfDll.dll" (ByVal Handle As Long) As Long '-- otev�e komunika�n� kan�l (otev�e port, nav�e tcp spojen�, ... podle typu komunika�n�ho rozhran�, nutno p�ed zapo�et�m komunikace, vr�t� 0 pokud OK, chybov� k�d v opa�n�m p��pad�
                                                  '   Jako handle se p�ed�v� handle z�skan� z funkc� ciCreate
Public Declare Function ciClose Lib "CommIntfDll.dll" (ByVal Handle As Long) As Long '-- zav�e komunika�n� kan�l
Public Declare Function ciRelease Lib "CommIntfDll.dll" (ByVal Handle As Long) As Long '-- Zru�� komunika�n� kan�l a p��slu�n� handle
Public Declare Function ciIsActive Lib "CommIntfDll.dll" (ByVal Handle As Long, ByRef Active As Long) As Long '-- Zjist�, zda je komunika�n� rozhrann� otev�eno. pokud je n�vratov� hodnota 0, do parametru Active je vr�cen stav
Public Declare Function ciRead Lib "CommIntfDll.dll" (ByVal Handle As Long, ByVal Buffer As String, ByRef Size As Long) As Long  '-- Na�te p��choz� data. Size se nastav� na velikost bufferu, vr�ti se po�et na�ten�ch byt�
Public Declare Function ciWrite Lib "CommIntfDll.dll" (ByVal Handle As Long, ByVal Buffer As String, ByVal Size As Long) As Long  '-- Po�le data po komunika�n�m rozhrann�
Public Declare Function ciReadLength Lib "CommIntfDll.dll" (ByVal Handle As Long) As Long '-- Zjist�, kolik byt� je ve vstupn�m bufferu p�ipraveno k na�ten�
Public Declare Function ciClearReadBuffer Lib "CommIntfDll.dll" (ByVal Handle As Long) As Long '-- Vyma�e p��choz� data ze vstupn�ho bufferu

'funkce pro usnadn�n� synchronn� komunikace typu dotaz-odpov��
Public Declare Function ciSndGet Lib "CommIntfDll.dll" (ByVal Handle As Long, ByRef SndBuffer, ByVal Size As Long, ByRef RcvBytes As Long, ByVal MaxTimeOut As Long) As Long
        '-- Ode�le data (Size byt� ze SndBufferu) a �ek� na odpov�� (Maxim�ln� MaxTimeOut milisekund). V RcvBytes vr�t�, kolik byt� bylo p�ijato jako odpov��. Odpov�� lze p�ijmout pomoc� ciRead
Public Declare Function ciSndGetSpinel97 Lib "CommIntfDll.dll" (ByVal Handle As Long, ByRef SndBuffer, ByVal Size As Long, ByRef RcvBytes As Long, ByVal MaxTimeOut As Long) As Long
        '-- Stejn� jako ciSndGet ode�le data a �ek� na odpov��. Jako odpov�� v�ak o�ek�v� Spinel paket. v RcvBytes vr�t� po�et p�ijat�ch byt� platn�ho Spinel paketu. Pokud nebyl platn� paket p�ijat, n�vratov� hodnota signalizuje chybu a RcvBytes je 0.
        '-- Odpov�� lze z�skat funkc� ciRead nebo ciReadSpin97.
Public Declare Function ciSndGetSpin97 Lib "CommIntfDll.dll" (ByVal Handle As Long, ByVal Adr As Byte, ByVal Sig As Byte, ByVal Inst As Byte, ByVal Data As String, ByVal DataLength As Long, ByRef RcvBytes As Long, ByVal MaxTimeOut As Long) As Long
        '-- Ode�le Spinelovsk� paket, vytvo�en� parametry Adr, Sig, Inst a Data (D�lky DataLen). Zbytek spinelovsk� hlavi�ky (prefix, d�lka, CRC, ..) se vypo��t� automaticky.
        '   Odpov�� jako u ciSndGetSpinel97
Public Declare Function ciReadSpin97 Lib "CommIntfDll.dll" (ByVal Handle As Long, ByRef Adr As Byte, ByRef Sig As Byte, ByRef Ack As Byte, ByVal Data As String, ByRef DataSize As Long) As Long
        '-- Na�te Spinel paket z p�ijat�ch dat. pokud v p�ijat�ch datech nen� platn� spinel paket, n�vratov� hodnota signalizuje chybu.
        '   Pokud byl p�ijat paket, napln� se z n�j hodnoty Adr, Sig a Ack a Data. v DataSize je t�eba zadat velikost bufferu Data, zp�t se vr�t� aktu�ln� velikost Dat.
Public Declare Function ciRegisterMsgNotifications Lib "CommIntfDll.dll" (ByVal Handle As Long, ByVal WHandle As Long, ByVal Msg As Long, ByVal Blocking As Long) As Long
                      '-- Zaregistruje p��jem ud�lost� pomoc� windows zpr�v.
                      '   Notificationlong = handle okna kam maj� zpr�vy chodit, Msg = Jak� zpr�va se bude zas�lat,
                      '   Blocking=jakou medodou budou zpr�vy zas�l�ny as  true-SendMessage-rozhrann� �ek� na zpracov�n� ud�lost�, false-PostMessage-rozhrann� asynchronn� za�le upozorn�n� o ud�losti a ne�ek� na jeho zpracov�n�
                      '   Zpr�va p�ijde ve tbyrefu  as  Msg = Msg, wParam = Handle, lParamLow = Typ ud�losti (ciev_Open, ciev_Close, ciev_DataRcv, ciev_Error), lParamHi = p��padn� dodate�n� parametr
Public Declare Function ciUnregisterMsgNotifications Lib "CommIntfDll.dll" (ByVal Handle As Long) As Long '-- Odregistruje p��jem ud�lost� pomoc� widnows zpr�v
Public Declare Function ciRegisterCallBackNotifications Lib "CommIntfDll.dll" (ByVal Handle As Long, ByVal CallBackEntryPoint As Long, ByVal CallBackID As Long) As Long
                      '-- Zaregistruje p��jem ud�lost� pomoc� CallBackov� funkce
                      '   CallBackEntryPoint = vstupn� bod Callbackov� funkce typu longNotificationEvent
                      '   CallBackID = voliteln� parametr, kter� bude zp�t zas�l�n p�i zp�tn�m vol�n� (voliteln� identifikace)
                      '   Callbackov� funkce je pak vol�na s t�mito parametry  as  Handle-Handle rozhran�,Event-typ ud�losti (ciev_Open, ciev_Close, ciev_DataRcv, ciev_Error),Param-p��padn� parametr, CallBackID-voliteln� parametry zadan� p�i registraci
Public Declare Function ciUnregisterCallBackNotifications Lib "CommIntfDll.dll" (ByVal Handle As Long) As Long '-- Odregistruje p��jem ud�lost� pomoc� callbackov� funkce
Public Declare Function ciEnumHandles Lib "CommIntfDll.dll" (ByRef HandleList, ByRef Size As Long) As Long '-- Vr�t� seznam v�ech aktu�ln� vytvo�en�ch komunika�n�ch rozhran�ch
Public Declare Function ciHandlesCount Lib "CommIntfDll.dll" () As Long '-- Vr�t� po�et aktu�ln� vytvo�en�ch komunika�n�ch rozhran�ch
Public Declare Function ciHandleByIndex Lib "CommIntfDll.dll" (ByVal index As Long) As Long '-- Vr�t� handle podle indexu (0 .. ciHandlesCount-1)
Public Declare Function ciGetDescription Lib "CommIntfDll.dll" (ByVal Handle As Long, ByVal Description As String, ByRef Length As Long) As Long '-- Vr�t� popis komunika�n�ho rozhran�
Public Declare Function ciGetID Lib "CommIntfDll.dll" (ByVal Handle As Long, ByVal ID As String, ByRef Length As Long) As Long '--  Vr�t� textovou identifikaci rozhran�
Public Declare Function ciGetProvider Lib "CommIntfDll.dll" (ByVal Handle As Long, ByVal Provider As String, ByRef Length As Long) As Long '-- Vr�ti typ rozhrann� (SERIAL_PORT, TCP_CLIENT, UDP_CLIENT nebo FTD_USB)
Public Declare Function ciGetValid Lib "CommIntfDll.dll" (ByVal Handle As Long, ByRef Valid As Long) As Long '-- rezervov�no
Public Declare Function ciSetValid Lib "CommIntfDll.dll" (ByVal Handle As Long, ByVal Valid As Long) As Long '-- rezervov�no
Public Declare Function ciExecuteConfigDialog Lib "CommIntfDll.dll" (ByVal Handle As Long) As Long '-- Spust� se konfigura�n� dialog konkr�tn�ho komunika�n�ho rozhrann�
Public Declare Function ciConfigDialogAvailable Lib "CommIntfDll.dll" (ByVal Handle As Long) As Long '-- Zjist�, zda rozhran� podporuje konfigura�n� dialog
'-------------
Public Declare Function ciGetConfig Lib "CommIntfDll.dll" (ByVal Handle As Long, ByVal ConfigString As String, ByRef Length As Long) As Long '-- Z�sk� konfigura�n� �et�zec rozhran�
Public Declare Function ciSetConfig Lib "CommIntfDll.dll" (ByVal Handle As Long, ByVal ConfigString As String) As Long '-- Nastav� konfigura�n� �et�zec rozhran�
Public Declare Function ciGetConfigValue Lib "CommIntfDll.dll" (ByVal Handle As Long, ByVal ParamName As String, ByVal Value As String, ByRef Length As Long) As Long '-- Zj�sk� jednu hodnotu z konfigura�n�ho �et�zce, ParamName=n�zev parametru, Value=buffer, do kter�ho se vr�t� textov� podoba hodnoty
Public Declare Function ciGetConnectionStringDlg Lib "CommIntfDll.dll" (ByVal OutConnStr As String, ByRef Length As Long, ByRef OKReturn As Long, ByVal DefaultValue As String, ByVal Caption As String) As Long
      '-- Zobraz� dialog pro vytvo�en� konfigura�n�ho �et�zce. OutConnStr = buffer pro ulo�en� v�sledku, Length = velikost bufferu OutConnStr, zp�t vr�t� aktu�ln� velikost �et�zce, OKReturn=vr�t�, zda bylo stisknuto OK,
      '   DefaultValue = V�choz� konfigura�n� �et�zec, Caption = Titulek okna konfigura�n�ho �et�zce
'--------------

'*** funkce pro v��et s�riov�ch port� a FTD USB za��zen� ***
Public Declare Function EnumSerialPorts Lib "CommIntfDll.dll" (ByRef Ports, ByRef Size As Long) As Long '-- Vr�t� seznam s�riov�ch port� na po��ta�i (v�etn� virtu�ln�ch)
            ' Ports - buffer (ukazatel na pole long�), kam se ulo�� v�sledek, Size - velikost bufferu v bytech, zp�t vr�t� aktu�ln� velikost v bytech, n�vratov� hodnota - po�et port� (-1 = chyba)
Public Declare Function SerialPortCount Lib "CommIntfDll.dll" () As Long  '-- Po�et s�riov�ch port� na po��ta�i
Public Declare Function SerialPortNumByIndex Lib "CommIntfDll.dll" (ByVal index As Long) As Long '-- Vr�t� ��slo portu podle indexu (0..SerialPortCount-1)
Public Declare Function SerialPortByIndex Lib "CommIntfDll.dll" (ByVal index As Long, ByVal PortName As String, ByRef Length As Long) As Long '-- Vr�t� n�zev portu podle indexu (0..SerialPortCount-1) nap� as  "COM3"
Public Declare Function GetSerialPortState Lib "CommIntfDll.dll" (ByVal PortNum As Long) As Long '-- Vr�t� stav s�riov�ho portu (otev�en�, zav�en�, neexistuje)
Public Declare Function FTDDeviceCount Lib "CommIntfDll.dll" () As Long '-- Po�et za��zen� p�ipojen�ch p�es FTD USB
Public Declare Function FTDGetDetailByIndex Lib "CommIntfDll.dll" (ByVal index As Long, ByRef Flags As Long, ByRef Typ As Long, ByRef ID As Long, ByRef LocID As Long, ByVal SerialNum As String, ByVal Description As String) As Long
    '-- Zjist� informace o USB za��zen� podle indexu (0..FTDDeviceCount-1). Flags, Typ, ID a Loc jsou ukazatele na 32bitov� ��sla. parametry kter� nechceme vr�tit m��ou b�t NIL
    '-- SerialNum a Description jsou buffery pro ulo�en� textu, m�li by b�t alokov�ny na dostate�nou velikost, nebo NIL, pokud n�s nezaj�maj�. 32B pro SerialNum a 128B pro Description by m�lo ur�it� sta�it.
Public Declare Function FTDSerNumByIndex Lib "CommIntfDll.dll" (ByVal index As Long, ByVal SerNum As String, ByRef Length As Long) As Long
    '-- Zjist� s�riov� ��slo USB za��zen� podle indexu
Public Declare Function FTDDevNameByIndex Lib "CommIntfDll.dll" (ByVal index As Long, ByVal DevName As String, ByRef Length As Long) As Long
    '-- Zjist� n�zev za��zen� USB za��zen� podle indexu
Public Declare Function FTDVidPidByIndex Lib "CommIntfDll.dll" (ByVal index As Long, ByRef VID As Long, ByRef PID As Long) As Long
    '-- Zjist� VID a PID hodnoty (identifikace v�robce a produktu) USB za��zen�
Public Declare Function FTDFindDevice Lib "CommIntfDll.dll" (ByVal start As Long, ByVal SerNum As String, ByVal DevName As String, ByRef VID As Long, ByRef PID As Long, ByRef index As Long) As Long
    '-- Vyhled� v dostupn�ch USB za��zen� na po��ta�i (prvn�) ten, kter� odpov�d� zadan�m parametr�m. do Index vr�t� jeho Index.
    '   parametry se p�ed�vaj� ukazatelem na hodnotu nebo �et�zec. parametry mohou b�t vynech�ny zad�n�m NIL.
Public Declare Function FTDFindDeviceCS Lib "CommIntfDll.dll" (ByVal start As Long, ByVal Params As String, ByRef index As Long) As Long
    '-- Vyhled� USB za��zen� podle parametr�, jako FTDFindDevice, akor�t se parametry p�ed�vaj� v jednom �et�zci odd�Len� st�edn�kem as
    '   Lze zadat n�kter� z t�chto parametr� as
    '   index=zad� p��mo index, nebo device=��st n�zvu za��zen�, nebo serial_number=s�riov� ��slo za��zen�, nebo vid=vid,pid=pid, nebo nemus� m�t ��dn� parametr, vezme se prvn� p�ipojen� za��zen� typu FTD_USB)
    '   do Index se vr�t� Index za��zen�, kter� odpov�d� v�em zadan�m parametr�m. V p��pad� �e tomu ��dn� za��zen� neodpov�d�, vr�t� se do Index -1.


'********* POMOCN� FUNKCE *************

Public Function SndRcvSpin97(ByVal Handle As Long, ByRef Adr As Byte, Sig As Byte, ByVal Inst As Byte, ByVal Data As String, ByRef Ack As Byte, ByRef ReturnData As String, Optional ByVal MaxTimeOut As Long = 500) As Boolean
  Dim RetLen As Long
  Dim Dat As String
  SndRcvSpin97 = False
  If ciSndGetSpin97(Handle, Adr, Sig, Inst, Data, Len(Data), RetLen, MaxTimeOut) = 0 Then
    Dat = String(RetLen, " ")
    If RetLen > 0 Then
        If ciReadSpin97(Handle, Adr, Sig, Ack, Dat, RetLen) = 0 Then
          ReturnData = Left(Dat, RetLen)
          SndRcvSpin97 = True
        End If
    End If
  End If
End Function


