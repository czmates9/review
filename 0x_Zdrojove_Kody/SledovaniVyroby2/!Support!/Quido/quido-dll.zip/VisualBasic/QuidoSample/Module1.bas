Attribute VB_Name = "Module1"
Option Explicit

Public Sub CallBackEvent(ByVal qHandle As Long, ByVal Evnt As Integer, ByVal Param As Integer, ByVal CallBackID As Long)
 Select Case Evnt
   Case qev_CIOpen
     fQuidoSample.OnOpen
   Case qev_CIClose
     fQuidoSample.OnClose
   Case qev_InputChange
     fQuidoSample.OnInputChange (Param Mod 256)
 End Select
End Sub
