VERSION 5.00
Begin VB.Form fQuidoSample 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Quido Dll Sample"
   ClientHeight    =   6855
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   5415
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6855
   ScaleWidth      =   5415
   StartUpPosition =   3  'Windows Default
   Begin VB.Frame gbQuido 
      Caption         =   "Quido"
      Height          =   4455
      Left            =   120
      TabIndex        =   8
      Top             =   2280
      Visible         =   0   'False
      Width           =   5175
      Begin VB.Frame Frame5 
         Caption         =   "Vstupy"
         Height          =   1815
         Left            =   120
         TabIndex        =   16
         Top             =   2520
         Width           =   4935
         Begin VB.Frame Frame6 
            Caption         =   "��ta�"
            Height          =   615
            Left            =   120
            TabIndex        =   19
            Top             =   1080
            Width           =   3855
            Begin VB.Label lblCounterValue 
               Height          =   255
               Left            =   1920
               TabIndex        =   21
               Top             =   240
               Width           =   1815
            End
            Begin VB.Label lblCounter 
               Height          =   255
               Left            =   120
               TabIndex        =   20
               Top             =   240
               Width           =   1695
            End
         End
         Begin VB.ComboBox ComboBoxIn 
            Height          =   315
            Left            =   120
            Style           =   2  'Dropdown List
            TabIndex        =   18
            Top             =   600
            Width           =   2415
         End
         Begin VB.CheckBox chAutoNotify 
            Caption         =   "Automatick� vys�l�n� zm�ny vstup�"
            Height          =   255
            Left            =   120
            TabIndex        =   17
            Top             =   240
            Width           =   4575
         End
         Begin VB.Shape InIndik 
            BackColor       =   &H00FFFFFF&
            FillColor       =   &H00FFFFFF&
            FillStyle       =   0  'Solid
            Height          =   375
            Left            =   2760
            Shape           =   3  'Circle
            Top             =   600
            Width           =   495
         End
      End
      Begin VB.CommandButton cmdSPInfo 
         Caption         =   "SP Info"
         Height          =   375
         Left            =   2160
         TabIndex        =   12
         Top             =   240
         Width           =   1215
      End
      Begin VB.CommandButton cmdReset 
         Caption         =   "Reset"
         Height          =   375
         Left            =   840
         TabIndex        =   11
         Top             =   240
         Width           =   1215
      End
      Begin VB.Frame Frame4 
         Caption         =   "Info"
         Height          =   735
         Left            =   120
         TabIndex        =   10
         Top             =   720
         Width           =   4935
         Begin VB.Label Label2 
            Caption         =   "Label2"
            Height          =   255
            Left            =   600
            TabIndex        =   13
            Top             =   240
            Width           =   4095
         End
      End
      Begin VB.Frame Frame3 
         Caption         =   "V�stupy"
         Height          =   855
         Left            =   120
         TabIndex        =   9
         Top             =   1560
         Width           =   4935
         Begin VB.CheckBox chOut 
            Height          =   255
            Left            =   2760
            TabIndex        =   15
            Top             =   360
            Width           =   2055
         End
         Begin VB.ComboBox ComboBoxOut 
            Height          =   315
            Left            =   120
            Style           =   2  'Dropdown List
            TabIndex        =   14
            Top             =   360
            Width           =   2415
         End
      End
   End
   Begin VB.Frame Frame1 
      Caption         =   "P�ipojovac� �e��zec"
      Height          =   2055
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   5175
      Begin VB.CommandButton cmdClose 
         Caption         =   "Zav��t"
         Height          =   375
         Left            =   3720
         TabIndex        =   7
         Top             =   1440
         Width           =   1215
      End
      Begin VB.CommandButton cmdOpen 
         Caption         =   "Otev��t"
         Height          =   375
         Left            =   2400
         TabIndex        =   6
         Top             =   1440
         Width           =   1215
      End
      Begin VB.TextBox txtParams 
         Height          =   330
         Left            =   120
         TabIndex        =   5
         Text            =   "addr=$FE"
         Top             =   960
         Width           =   1815
      End
      Begin VB.CommandButton cmdCreate 
         Caption         =   "Vytvo�it Quido"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   238
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   3
         Top             =   1440
         Width           =   1815
      End
      Begin VB.CommandButton cmdDlg 
         Caption         =   "..."
         Height          =   330
         Left            =   4320
         TabIndex        =   2
         Top             =   360
         Width           =   615
      End
      Begin VB.TextBox ConnectionString 
         Height          =   330
         Left            =   120
         TabIndex        =   1
         Text            =   "provider=TCP_CLIENT;host=192.168.1.254;port=10001"
         Top             =   360
         Width           =   4095
      End
      Begin VB.Label Label1 
         Caption         =   "Paramtery Quida"
         Height          =   255
         Left            =   120
         TabIndex        =   4
         Top             =   720
         Width           =   1215
      End
   End
End
Attribute VB_Name = "fQuidoSample"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim QuidoHandle As Long

Private Sub cmdClose_Click()
  If QuidoHandle = 0 Then
    MsgBox "Quido nen� vytvo�eno"
    Exit Sub
  End If
  qClose (QuidoHandle) 'Zav�en� komunika�n�ho rozhran� s Quidem

End Sub

Private Sub cmdCreate_Click()
  'Vytvo�� Quido
  
  If (QuidoHandle <> 0) Then 'Pokud je vytvo�en� jin� Quido ...
    qReleaseQuido QuidoHandle '... zru�� se ...
    QuidoHandle = 0 '... vynuluje se handle ...
    OnClose  '... shov� se z formul��e ovl�d�n� quida
  End If
  QuidoHandle = qCreateQuido(ConnectionString.Text, txtParams.Text)
  '-- Vytvo�� se Quido podle p�ipojovac�ho �et�zce, kter� definuje komunika�n� rozhran�. d�le se p�ed� adresa Quida v parametrech quida

  If (QuidoHandle <> 0) Then
     '-- pokud bylo quido vytvo�eno, zaregistruje se zas�l�n� ud�lost� pomoc� Windows zpr�v
     qRegisterCallBackNotifications QuidoHandle, AddressOf CallBackEvent, 0
  Else
    MsgBox "Quido nebylo vytvo�eno" 'pokud Quido nelze podle p�ipojovac�ho �et�zce vytvo�it
  End If

End Sub

Public Sub OnClose()
  'Schov�n� ovl�d�n� Quida
  gbQuido.Visible = False
End Sub
Public Sub OnOpen()
  Dim Buf As String
  Dim Ln As Long
  Ln = 128
  Buf = String(Ln, " ")
  Dim Cnt As Long
  If (qInfo(QuidoHandle, Buf, Ln) = 0) Then 'Na�ten� identifika�n�ho �et�zce
    Buf = Left(Buf, Ln)
    Label2.Caption = Buf
  Else
   MsgBox "Nebylo na�teno z Quida"
   Exit Sub
  End If

  If (qGetAutoNotify(QuidoHandle, Cnt) = 0) Then  'Zjist� stav automatick�ho vys�l�n�
    If Cnt = 0 Then chAutoNotify.Value = 0 Else chAutoNotify.Value = 1
  Else
   chAutoNotify.Value = 2
  End If
  ComboBoxOut.Clear
  'Zji�t�n� po�tu v�stup� a vyps�n� do ComboBoxu
  Cnt = qOutputsCount(QuidoHandle)
  If (Cnt < 0) Then
    MsgBox "Nebyl zji�t�n po�et v�stup�"
    Exit Sub
  End If
  Dim i As Integer
  For i = 0 To Cnt - 1
    ComboBoxOut.AddItem "V�stup " & (i + 1)
  Next i
  If (Cnt > 0) Then
   'Nastaven� prvn�ho v�stupu
   ComboBoxOut.ListIndex = 0
   ComboBoxOut_Click
  End If

  ComboBoxIn.Clear
  'Zji�t�n� po�tu vstup� a vyps�n� do ComboBoxu
  Cnt = qInputsCount(QuidoHandle)
  If (Cnt < 0) Then
    MsgBox "Nebyl zji�t�n po�et vstup�"
    Exit Sub
  End If
  For i = 0 To Cnt - 1
    ComboBoxIn.AddItem "Vstup " & (i + 1)
  Next i
  If (Cnt > 0) Then
   'Nastaven� prvn�ho vstupu
   ComboBoxIn.ListIndex = 0
   ComboBoxIn_Click
  End If

  'Zobrazen� ovl�d�n� Quida
  gbQuido.Visible = True
End Sub
Public Sub OnInputChange(Index As Long)
  If (Index = ComboBoxIn.ListIndex) Then 'Pokud je zm�n�n� vstup vybran� (zobrazen�)
      Dim OS As Long, R As Long, F As Long
      'Zjist� se naposledy zn�m� stav vstupu (po t�to ud�losti by m�l b�t aktu�ln�, nen� t�eba znovu komunikovat s Quidem)
      If (qGetRecentInputByIndex(QuidoHandle, ComboBoxIn.ListIndex, OS) = 0) Then
         InIndik.FillColor = IIf(OS <> 0, vbRed, RGB(128, 128, 128))
         'Zji�t�n� stavu ��ta�e
         If (qInputCounterValueByIndex(QuidoHandle, Index, OS, 0) = 0) Then
           lblCounterValue.Caption = CStr(OS)
         Else
           lblCounterValue.Caption = ""
         End If
         'Zji�t�n� nastaven� ��ta�e
         If (qGetCounterSetting(QuidoHandle, Index, R, F) = 0) Then
            If (R <> 0) And (F <> 0) Then
             lblCounter.Caption = "��ta�: Ob� hrany"
            ElseIf (R <> 0) Then
             lblCounter.Caption = "��ta�: N�b�n� hrana"
            ElseIf (F <> 0) Then
             lblCounter.Caption = "��ta�: Sestupn� hrana"
            Else
             lblCounter.Caption = "��ta� vypnut"
            End If
         Else
          lblCounter.Caption = "��ta� nen�"
         End If
      End If
  End If
  
End Sub

Private Sub cmdDlg_Click()
  Dim S As String
  Dim Ln As Long
  Dim Ret As Long
  Ln = 512
  S = String(Ln, " ")
  If ciGetConnectionStringDlg(S, Ln, Ret, ConnectionString.Text, "P�ipojovac� �et�zec") = 0 Then
   S = Left(S, Ln)
   ConnectionString.Text = S
  Else
   MsgBox "Chyba dialogu"
  End If
End Sub

Private Sub cmdOpen_Click()
  If QuidoHandle = 0 Then
    MsgBox "Quido nen� vytvo�eno"
    Exit Sub
  End If
  qOpen QuidoHandle 'Otev�e se komunika�n� rozhran�

End Sub

Private Sub cmdReset_Click()
  'Restartov�n� Quida
  If (qReset(QuidoHandle) <> 0) Then MsgBox "Nezda�ilo se resetovat"

End Sub

Private Sub cmdSPInfo_Click()
  'Uk�zka pou��t� funkce qSndRcvSpin97
  'Tuto funkci je vhodn� pou��vat v p��padech, kdy je t�eba prov�st p��kaz, kter� nem� implementovanou speci�ln� funkci
  'p��klad po�le spinel instrukci 0xF3 pro zj�sk�n� identifika�n�ho �et�zce Quida (to je implementov�no funkc� qInfo)
  Const InstInfo = 243 '0xF3
  Dim Info As String
  Dim Size As Long
  Size = 128
  Info = String(Size, " ")
  Dim Ack As Byte
  Dim Ret As Long
  Ret = qSndRcvSpin97(QuidoHandle, InstInfo, "", 0, Ack, Info, Size, 1000)
  'funkci se p�ed� handle Quida, instrukce (0xF3), data a jejich d�ka (v t�to instrukci se data nep�ed�vaj�, jsou tedy NULL a d�lka 0), Ack pro z�sk�n� n�vratov�ho k�du (0=OK),
  'buffer Info pro p��jem vr�cen�ch dat o velikosti Len (pokud se neo�ek�vaj� vr�cen� data, m��e b�t NULL a velikost 0). Len se zm�n� na aktu�ln� velikost vr�cen�ch dat.

  If (Ret = 0) Then 'pokud byla instrukce provedena (a potvrzena)
     If (Ack = 0) Then 'pokud je n�vratov� k�d Ack = 0 (OK)
        Info = Left(Info, Size) '�et�zec se zkr�t� na p�ijatou d�lku
        MsgBox Info 'Zobraz� se p�ijat� �et�zec
     Else
       MsgBox ("Instrukce nebyla �sp�n� vykon�na")
     End If
  Else
    MsgBox ("Bez odezvy")
  End If

End Sub

Private Sub ComboBoxIn_Click()
  'P�i zm�n� v�b�ru vstupu
  If (QuidoHandle <> 0) Then
    If (ComboBoxIn.ListIndex >= 0) Then 'Vybran� vstup
      Dim OS As Long, R As Long, F As Long
      'Zjistit stav vybran�ho vstupu
      If (qInputStateByIndex(QuidoHandle, ComboBoxIn.ListIndex, OS) <> 0) Then
        MsgBox "Nelze zjistit stav v�stupu."
        Exit Sub
      End If
      'Zm�nit barvu indik�toru (�erven�=vstup aktivn�, �ed�= vstup neaktivn�)
      InIndik.FillColor = IIf(OS <> 0, vbRed, RGB(128, 128, 128))
      'Zji�t�n� stavu ��ta�e
      If (qInputCounterValueByIndex(QuidoHandle, ComboBoxIn.ListIndex, OS, 0) = 0) Then
         lblCounterValue.Caption = CStr(OS)
      Else
         lblCounterValue.Caption = ""
      End If
      'Zji�t�n� nastaven� ��ta�e
      If (qGetCounterSetting(QuidoHandle, ComboBoxIn.ListIndex, R, F) = 0) Then
         If (R <> 0) And (F <> 0) Then
          lblCounter.Caption = "��ta�: Ob� hrany"
         ElseIf (R <> 0) Then
          lblCounter.Caption = "��ta�: N�b�n� hrana"
         ElseIf (F <> 0) Then
          lblCounter.Caption = "��ta�: Sestupn� hrana"
         Else
          lblCounter.Caption = "��ta� vypnut"
         End If
      Else
       lblCounter.Caption = "��ta� nen�"
      End If
    End If
  End If

End Sub

Private Sub ComboBoxOut_Click()
  'P�i zm�n� v�b�ru v�stupu
  If (QuidoHandle <> 0) Then
    If (ComboBoxOut.ListIndex >= 0) Then
      chOut.Caption = "V�stup " & (ComboBoxOut.ListIndex + 1)
      Dim OS As Long
      'Zjistit stav vybran�ho v�stupu
      If (qOutputStateByIndex(QuidoHandle, ComboBoxOut.ListIndex, OS) <> 0) Then
       MsgBox "Nelze zjistit stav v�stupu."
       Exit Sub
      End If
      'Zobrazit
      chOut.Value = IIf(OS <> 0, 1, 0)
    End If
  End If

End Sub

Private Sub Form_Terminate()
  'P�i ukon�en� zru�it Quido
  If (QuidoHandle <> 0) Then qReleaseQuido (QuidoHandle)
End Sub

Private Sub chAutoNotify_Click()
  If (chAutoNotify.Value <> 2) Then
    Dim Ch As Long
    Ch = chAutoNotify.Value
    'Nastaven� automatick�ho vys�l�n�
    If (qSetAutoNotify(QuidoHandle, Ch) <> 0) Then MsgBox "Automatick� vys�l�n� nebylo nastaveno."
  End If

End Sub

Private Sub chOut_Click()
  'Zm�nit stav vybran�ho v�stupu

  If (QuidoHandle <> 0) Then ' (je vytvo�eno Quido?)
    If (ComboBoxOut.ListIndex >= 0) Then '(je vybr�n v�stup?)
      Dim OS
      OS = chOut.Value 'Zjistit stav za�krt�v�tka
      'Nastavit v�stup Quida
      If (qSetOutput(QuidoHandle, ComboBoxOut.ListIndex, OS) <> 0) Then
        MsgBox "V�stup nebyl nastaven."
      End If
    End If
  End If

End Sub
