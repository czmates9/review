Attribute VB_Name = "q_QuidoDllMap"
'  QuidoStackDll - Mapov�n� funkc� z knihovny QuidoStackDll.dll
'
'  Vydavatel :  Papouch s.r.o. - http://www.papouch.com/
'  Autor     :  Martin Z�me�n�k zamecnik@papouch.com
'
'  Pozn�mky  : k pou�it� funkc� jsou pot�eba knihovny QuidoStackDll.dll a CommIntfDll.dll,
'              v p��pad� pou�it� pro USB jsou pot�eba t� nainstalovan� ovlada�e FTD direct drivers a knihova FTD2XX.dll
'  Upozorn�n�: ve�ker� parametry Index, a to i v p��pad� vstup� a v�stup� quida, jsou ��slov�ny od 0 !!!

Option Explicit
Const QDLLName = "QuidoStackDll.dll"

'identifikace ud�lost� (event) vyvolan�ch Quidem. pro zas�l�n� ud�lost� registrujet jejich p��jem pomoc� qRegisterMsgNotifications nebo qRegisterCallBackNotifications
Public Const qev_Base = 511
Public Const qev_InputsChange = qev_Base + 1 ' //zm�na vstup� - obecn� ozn�m�, z� byla zaznamen�na zm�na n�kter�ho vstupu
Public Const qev_OutputsChange = qev_Base + 2 ' //zm�na v�stup� - ozn�m�, �e byl zn�n�n n�kter� v�stup
Public Const qev_InputChange = qev_Base + 3 ' //zm�na vstupu - ozn�m�, �e byl zm�n�n jednotliv� vstup (oznamuje ka�d� vstup zvl᚝)
Public Const qev_OutputChange = qev_Base + 4 ' //zm�na v�stupu - ozn�m�, �e byla zaznamen�na zm�na jednotliv�ho v�stupu
Public Const qev_CIOpen = qev_Base + 5 ' //-- otev�en� komunika�n�ho kan�lu quida
Public Const qev_CIClose = qev_Base + 6 ' //-- uzav�en� komunika�n�ho kan�lu quida


Public Declare Function DllInfo Lib "QuidoStackDll.dll" () As String '-- vrac� informa�n� text o knihovn�

Public Declare Function qHandlesCount Lib "QuidoStackDll.dll" () As Long '-- vrac� po�et vytvo�en�ch Quid (funkcemi qCreateQuido...), -1 = chyba
Public Declare Function qHandleByIndex Lib "QuidoStackDll.dll" (ByVal Index As Long) As Long '-- vrac� handle na Quido podle indexu (0..qHandlesCount-1), 0 = neplatn� handle
Public Declare Function ciHandlesCount Lib "QuidoStackDll.dll" () As Long '-- vrac� po�et vytvo�en�ch komunika�n�ch rozhran� (a� ji� spole�n� s Quidem nebo zvl᚝ v QuidoStackDll.dll), -1=chyba
Public Declare Function ciHandleByIndex Lib "QuidoStackDll.dll" (ByVal Index As Long) As Long '-- vrac� handle na komunika�n� rozhran� podle indexu (0..ciHandlesCount-1), 0=chyba

Public Declare Function qCreateQuido Lib "QuidoStackDll.dll" (ByVal ConnectionString As String, ByVal devicestring As String) As Long
    '-- vytvo�i objekt Quida. vrac� handle vytvo�en�ho objektu Quida, 0 = nepovedlo se vytvo�it
    '--       connection string je �et�zec pro vytvo�en� komunika�n�ho rozhrann�, ur�uje komunika�n� kan�l a jeho nastaven� (s�riov� port, tcp, udp, nebo ftd_usb)
    '--       devicestring specifikuje parametry za��zen� Quido (adresu. v p��pad� �e je na komunika�n�m kan�lu pouze jedno za��zen�, lze zadat univerz�ln� adresu $FE)
    '   Tvorba connectionstringu  as  jsou to hodnoty ve tvaru "parametr=hodnota" odd�Lenghty st�edn�kem. ur�uj� typ p�ipojen�
    '          nejd�le�it�j��m parametrem je "provider", ur�uje typ komunika�n�ho kan�lu. m��e to b�t SERIAL_PORT, TCP_CLIENT, UDP_CLIENT nebo FTD_USB
    '          ka�d� kan�l pak m��e m�t dal�� parametry. SERIAL_PORT (comport=��slo portu,baudrate=rychlost - nemus� b�t zad�no), TCP_CLIENT(host=ip adresa za��zen�,port=tcp port za��zen�), UDP_CLIENT(stejn� jako TCP), FTD_USB(index=po�adov� ��slo za��zen�, nebo device=��st n�zvu za��zen�, nebo serial_number=s�riov� ��slo za��zen�, nebo vid=vid,pid=pid, nebo nemus� m�t ��dn� parametr, vezme se prvn� p�ipojen� za��zen� typu FTD_USB
    '          p��klady as  "provider=SERIAL_PORT,comport=1", "provider=TCP_CLIENT,host=192.168.1.254,port=10001", "provider=UDP_CLIENT,host=192.168.1.254,port=10001", "provider=FTD_USB,device=Quido"
    '   Tvorba devicestringu as  p�. "addr=12", "addr=$FE" ($ - znamen� ��slo je zad�no v hexa, $FE=univerz�ln� adresa)

Public Declare Function qCreateQuidoCI Lib "QuidoStackDll.dll" (ByVal ciHandle As Long, ByVal devicestring As String) As Long '-- Vytvo�� objekt Quida, pou�ije se komunika�n� rozhrann� ji� explicitn� vytvo�en� v CommIntfDll (ciHandle)
Public Declare Function qCreateQuidoEx Lib "QuidoStackDll.dll" (ByVal ConnectionString As String, ByVal devicestring As String, ByVal ciEventType As Long) As Long '-- umo��uje specifikovat zp�sob vol�n� ud�lost� mezi komunika�n�m rozhrann�m a objektem quida  - ciEventType (0 - sendmessage, 1 - callback, 2 - postmessage). nedoporu�uje se pou��vat, pokud k tomu nen� d�vod
Public Declare Function qCreateQuidoCIEx Lib "QuidoStackDll.dll" (ByVal ciHandle As Long, ByVal devicestring As String, ByVal ciEventType As Long) As Long '-- pou�it� explicitn� vytvo�en�ho komunika�n�ho rozhrann�, specifikace zp�sobu vol�n� ud�lost�

Public Declare Function qGetQuidoCIHandle Lib "QuidoStackDll.dll" (ByVal qHandle As Long) As Long '-- vr�t� handle komunika�n�ho rozhran� p�ipojen�mu ke Quidu

Public Declare Function qOpen Lib "QuidoStackDll.dll" (ByVal qHandle As Long) As Long  '-- otev�e komunika�n� kan�l Quida (otev�e port, nav�e tcp spojen�, ... podle typu komunika�n�ho rozhran�, nutno pro komunikaci se za��zen�m, vr�t� 0 pokud OK, chybov� k�d v opa�n�m p��pad� (plat� obecn� pro n�vratov� typ long (long))
Public Declare Function qClose Lib "QuidoStackDll.dll" (ByVal qHandle As Long) As Long  '-- zav�e komunika�n� kan�l Quida, vr�t� 0 pokud OK, chybov� k�d v opa�n�m p��pad�
Public Declare Function qIsOpened Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByRef Opened As Long) As Long '-- zjist�, zda je komunika�n� kan�l quida otev�en
Public Declare Function qReleaseQuido Lib "QuidoStackDll.dll" (ByVal qHandle As Long) As Long  '-- zru�� objekt quida (v�etn� p��slu�n�ho komunika�n�ho rozhran� - pokud nen� zad�no p�i vytvo�en� explicitn� pomoc� handlu - qCreateQuidoCI)

Public Declare Function qInputsCount Lib "QuidoStackDll.dll" (ByVal qHandle As Long) As Long  '-- vr�t� po�et vstup� Quida, -1=chyba
Public Declare Function qOutputsCount Lib "QuidoStackDll.dll" (ByVal qHandle As Long) As Long  '-- vr�t� po�et v�stup� Quida, -1=chyba
Public Declare Function qInputCountersCount Lib "QuidoStackDll.dll" (ByVal qHandle As Long) As Long  '-- vr�t� po�et ��ta�� vstup�, -1=chyba, standardn� po�et ��ta�� vstup�=po�et vstup�, maxim�ln� v�ak 60

Public Declare Function qInputStateByIndex Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByVal Index As Long, ByRef State As Long) As Long '-- vr�t� do State stav vstupu podle indexu (0..po�et vstup�-1) (true=je na vstupu nap�t�, false=neni), n�vratov� hodnota as  0-ok, jinak chyba
Public Declare Function qOutputStateByIndex Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByVal Index As Long, ByRef State As Long) As Long '-- vr�t� do State stav v�stupu podle indexu (0..po�et vstup�-1)  (true=je na vstupu nap�t�, false=neni), n�vratov� hodnota as  0-ok, jinak chyba
Public Declare Function qInputCounterValueByIndex Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByVal Index As Long, ByRef Value As Long, ByVal NullCounter As Long) As Long '-- vr�t� do Value hodnotu ��ta�e vstupu podle indexu (0..po�et ��ta��-1), pokud je NullCounter true, ��ta� se z�hy vynuluje

Public Declare Function qGetInputs Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByRef Inputs, ByRef Lenght As Long) As Long   '-- vr�t� v poli stav v�ech vstup�. do inputs je t�eba zadat ukazatel na pole alokovan� na (po�et vstup�) byt�, do Lenght je t�eba zadat velikost tohoto pole, p�i pou�it� klasick�ho pole v delphi (array of boolean) je t�eba zadat ukazatel na prvn� prvek pole (@pole[0]),
             '---  pokud je v�e v po��dku, od Inputs se vypln� stavy vstup�, do Lenght se vypln� aktu�ln� velikost pole a n�vratov� hodnota je 0
             '---  pokud se do Inputs zad� nil, do Lenght se vypln� pot�ebn� velikost pole a n�vratov� hodnota je 0
             '---  pokud se vyskytne chyba (stav vstup� nelze zjistit, nebo zadan� velikost Lenght je nedostate�n�), n�vratov� hodnota je chybov� k�d <> 0
Public Declare Function qGetOutputs Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByRef Outputs, ByRef Lenght As Long) As Long '-- vr�t� v poli stav v�ech v�stup�. princip jako u qGetInputs

Public Declare Function qSetOutput Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByVal Index As Long, ByVal State As Long) As Long '-- Nastav� stav v�stupu Quida podle indexu (State as true=sepnout,false=rozepnout). pokud je n�vratov� hodnota 0=OK, jinach chyba
Public Declare Function qSetOutputTimered Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByVal Index As Long, ByVal State As Boolean, ByVal Time As Long) As Long '-- Nastav� stav v�stupu na ur�it� �as (Time=�as ve vte�in�ch).pokud je n�vratov� hodnota 0=OK, jinach chyba

Public Declare Function qSetOutputs Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByRef Outputs, ByVal Lenght As Long) As Long '-- Nastav� najednou stav v�ech v�stup�. do outputs se zad� pole booLenght� (1 bytov�ch). Lenght ur�uje velikost pole, pokud je n�vratov� hodnota 0=OK, jinach chyba

Public Declare Function qGetRecentInputsState Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByRef Inputs, ByRef Lenght As Long) As Long  '-- vr�t� v poli naposledy zn�m� stav vstup� - stejn� jako qGetInputs, akor�t se nedotazuje p��mo za��zen�, ale vrac� naposledy zji�t�n� stav. vhodn� nap�. po ud�losti qev_InputsChange.
Public Declare Function qGetRecentOutputsState Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByRef Outputs, ByRef Lenght As Long) As Long '-- vr�t� v poli naposledy zn�m� stav v�stup� - procuje jako qGetRecentInputsState

Public Declare Function qGetRecentInputByIndex Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByVal Index As Long, ByRef State As Long) As Long  '-- vr�t� naposledy zn�m� stav vstupu Quida podle Indexu (jako qGetInputStateByIndex, akor�t se nedotazuje p��mo za��zen�, ale vrac� naposledy zji�t�n� stav
Public Declare Function qGetRecentOutputByIndex Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByVal Index As Long, ByRef State As Long) As Long '-- vr�t� naposledy zn�m� stav v�stupu Quida podle Indexu. pracuje jako qGetRecentInputByIndex
Public Declare Function qGetRecentInputCounterByIndex Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByVal Index As Long, ByRef Value As Long) As Long '-- vr�t� naposledy zn�m� stav ��ta�e vstupu Quida podle Indexu.
Public Declare Function qGetRecentCounterSettingByIndex Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByVal Index As Long, ByRef Rising As Long, Falling As Long) As Long  '-- vr�t� naposledy zn�m� stav nastaven� vstupu Quida podle Indexu

Public Declare Function qRefreshRecentStates Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByVal Inputs As Long, ByVal Outputs As Long, ByVal Counters As Long, ByVal CounterSettings As Long) As Long
'qCheckInputsState Lib "QuidoStackDll.dll" (qHandle as long, Wait as long) as long '-- zjist� ze za��zen� stavy vstup�. ty jsou pak k dispozici pomoc� funkc� qGetRecentInputsstate a qGetRecentInputByIndex
'qCheckOutputsState Lib "QuidoStackDll.dll" (qHandle as long, Wait as long) as long '-- zjist� ze za��zen� stavy v�stup�. ty jou pak k dispozici pomoc� funkc� qGetRecentOutputsState a qGetRecentOutputByIndex

Public Declare Function qGetAutoNotify Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByRef Value As Long) As Long  '-- vr�t� do Value zda je aktivov�no automatick� oznamov�n� zm�ny stavu vstup� (pokud je registrov�no oznamov�n� pomoc� qRegisterMsgNotifications nebo qRegisterCallBackNotifications,
Public Declare Function qSetAutoNotify Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByVal Value As Long) As Long  '-- nastav� nebo zru�� automatick� oznamov�n� zm�ny stavu vstup� (true=nastavit, false=zru�it)

Public Declare Function qSetCounterSetting Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByVal Index As Long, ByVal Rising As Long, ByVal Falling As Long) As Long  '-- Nastaven� ��ta�e (na kter� hrany sign�lu se inkrementuje - rising=n�b�n�, falling=sestupn�)
Public Declare Function qGetCounterSetting Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByVal Index As Long, ByRef Rising As Long, ByRef Falling As Long) As Long  '-- Zji�t�n� nastaven� ��ta�e

Public Declare Function qRegisterMsgNotifications Lib "QuidoStackDll.dll" (ByVal Handle As Long, ByVal WHandle As Long, ByVal Msg As Long, ByVal blocking As Long) As Long '-- registruje zas�l�n� ud�lost� Quida pomoc� Windows zpr�v (Otev�en� a zav�en� komunika�n�ho kan�lu, zm�ny stav� vstup�, ...). zad�v� se long okna, kter� zpr�vu p�ij�m� a identifikaci zpr�vy, kter� je zas�l�na. v parametru zpr�vy WParam je zasl�n handle Quida, kter� ji zas�l�, v LParamLo je zasl�n typ ud�losti, LParamHi p��padn� dodate�n� parametr
Public Declare Function qUnregisterMsgNotifications Lib "QuidoStackDll.dll" (ByVal Handle As Long) As Long   '-- ru�� zas�l�n� ud�lost� Quida pomoc� Windows zpr�v
Public Declare Function qRegisterCallBackNotifications Lib "QuidoStackDll.dll" (ByVal Handle As Long, ByVal CallBackEntryPoint As Long, ByVal CallBackID As Long) As Long '-- registruje zas�l�n� ud�lost� Quida pomoc� vol�n� callbackov� funkce form�tu longnghtotificationEvent
Public Declare Function qUnregisterCallBackNotifications Lib "QuidoStackDll.dll" (ByVal Handle As Long) As Long '-- ru�� zas�l�n� ud�lost� Quida pomoc� callbackov� funkce

Public Declare Function qInfo Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByVal Info As String, ByRef Lenght As Long) As Long  '-- vrac� textovou identifikaci za��zen� (Quida)
Public Declare Function qReset Lib "QuidoStackDll.dll" (ByVal qHandle As Long) As Long  '-- Resetov�n� za��zen�
Public Declare Function qGetAddress Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByRef Addr As Long) As Long '-- zji�t�n� adresy za��zen�
Public Declare Function qSetAddress Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByRef Addr As Long) As Long '-- nastaven� adresy za��zen� (0-253)
Public Declare Function qGetUserData Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByVal UserData As String, ByRef Lenght As Long) As Long '-- z�sk�n� u��vatelsk�ch dat (16 byt�)
Public Declare Function qSetUserData Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByVal UserData As String, ByVal Lenght As Long) As Long  '-- nastaven� u�ivatelsk�ch dat (16 byt�)
Public Declare Function qGetFactoryInfo Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByRef ProductID As Long, ByRef SerialNumber As Long, ByRef FactoryData As Long) As Long '-- zj�sk�n� v�robn�ch dat (s�riov�ho ��sla,..) za��zen�

Public Declare Function qSndRcvSpin97 Lib "QuidoStackDll.dll" (ByVal qHandle As Long, ByVal Inst As Byte, ByVal Data As String, ByVal DataLenght As Long, _
                  ByRef RcvAck As Byte, ByVal RcvData As String, ByRef RcvDataLenght As Long, ByVal MaxTimeOut As Long) As Long
                  '-- Za�le spinel paket, zadan� instrukc� Inst a daty Data (velikosti DataLenght) a �ek� na odpov�� (maxim�ln� MaxTimeOut milisekund)
                  ' Pokud p�ijde odpov��, n�vratov� hodnota je 0, do bufferu RcvData o velikosti RcvDataLenght se zap�ou vr�cen� data spinel paketu a v RcvDataLenght se vr�t� aktu�ln� velikost dat.
                  ' RcvAck vr�t� k�d odpov�di (0 = OK)
                  ' Pokud se paket neode�le, nebo se nevr�t� odpov��, nebo vznikne jin� chyba, n�vratov� hodnota <> 0

Public Declare Function ciGetConnectionStringDlg Lib "QuidoStackDll.dll" (ByVal OutConnStr As String, ByRef Lenght As Long, ByRef OKReturn As Long, ByVal DefaultValue As String, ByVal Caption As String) As Long '-- Vyvol� dialogov� okno pro vytvo�en� p�ipojovac�ho �et�zce (connection string). Vrac� hodnotu<>0, pokud nastala chyba
                        '-- OutConStr as sem je vr�cen connectionstring, Lenght as velikost bufferu OutConStr, OKReturn as vr�ceno true, pokut bylo stisknuto OK, DefaultValue as p��padn� p�ednastaven� v�choz�ho connectionstringu, Caption as  vlastn� titulek dialogu

Public Declare Function LastError Lib "QuidoStackDll.dll" () As Long '-- vr�t� chybov� k�d naposledy volan� funkce. 0=funkce prob�hla v po��dku
Public Declare Function LastErrorText Lib "QuidoStackDll.dll" (ByVal Text As String, ByRef Size As Long) As Long '-- vr�t� text chyby naposledy volan� funkce

