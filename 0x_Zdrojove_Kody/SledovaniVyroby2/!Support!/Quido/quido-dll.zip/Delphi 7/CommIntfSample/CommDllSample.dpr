program CommDllSample;

uses
  Forms,
  Unit1 in 'Unit1.pas' {fCommDllSample},
  uUserInterface in '..\uUserInterface.pas',
  uci_IDLLMapD in '..\uci_IDLLMapD.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TfCommDllSample, fCommDllSample);
  Application.Run;
end.
