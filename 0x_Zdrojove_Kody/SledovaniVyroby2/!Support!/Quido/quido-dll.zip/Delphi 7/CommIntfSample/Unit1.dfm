object fCommDllSample: TfCommDllSample
  Left = 193
  Top = 102
  Width = 490
  Height = 491
  Caption = 'Uk'#225'zka pou'#382#237't'#237' CommIntfDll.dll'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  DesignSize = (
    482
    464)
  PixelsPerInch = 96
  TextHeight = 13
  object GroupBox1: TGroupBox
    Left = 8
    Top = 0
    Width = 321
    Height = 105
    Caption = 'Spojen'#237
    TabOrder = 0
    object Label1: TLabel
      Left = 8
      Top = 16
      Width = 98
      Height = 13
      Caption = 'p'#345'ipojovac'#237' '#345'et'#283'zec :'
    end
    object ConnectionString: TComboBox
      Left = 8
      Top = 32
      Width = 257
      Height = 21
      ItemHeight = 13
      TabOrder = 0
      Text = 'provider=TCP_CLIENT;host=192.168.1.254;port=10001'
      Items.Strings = (
        'provider=SERIAL_PORT;comport=1'
        'provider=TCP_CLIENT;host=192.168.1.254;port=10001')
    end
    object cmdCreate: TButton
      Left = 8
      Top = 72
      Width = 75
      Height = 25
      Caption = 'Vytvo'#345'it'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = [fsBold]
      ParentFont = False
      TabOrder = 1
      OnClick = cmdCreateClick
    end
    object cmdOpenClose: TButton
      Left = 104
      Top = 72
      Width = 75
      Height = 25
      Caption = 'Otev'#345#237't'
      TabOrder = 2
      OnClick = cmdOpenCloseClick
    end
    object cmdDlg: TButton
      Left = 272
      Top = 32
      Width = 43
      Height = 22
      Hint = 'Vytvo'#345'it p'#345'ipojovac'#237' '#345'et'#283'zec'
      Caption = '...'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = [fsBold]
      ParentFont = False
      ParentShowHint = False
      ShowHint = True
      TabOrder = 3
      OnClick = cmdDlgClick
    end
  end
  object PageControl1: TPageControl
    Left = 8
    Top = 112
    Width = 466
    Height = 337
    ActivePage = TabSheet1
    Anchors = [akLeft, akTop, akRight, akBottom]
    TabOrder = 1
    object TabSheet1: TTabSheet
      Caption = 'Prost'#225' komunikace'
      DesignSize = (
        458
        309)
      object GroupBox3: TGroupBox
        Left = 8
        Top = 8
        Width = 442
        Height = 137
        Anchors = [akLeft, akTop, akRight]
        Caption = 'Odeslat data'
        TabOrder = 0
        DesignSize = (
          442
          137)
        object chSendHex: TCheckBox
          Left = 8
          Top = 16
          Width = 265
          Height = 17
          Caption = 'Data zad'#225'na v hexa (FA 12 A3)'
          TabOrder = 1
        end
        object mSend: TMemo
          Left = 8
          Top = 32
          Width = 418
          Height = 65
          Anchors = [akLeft, akTop, akRight]
          ScrollBars = ssVertical
          TabOrder = 0
        end
        object cmdSend: TButton
          Left = 353
          Top = 104
          Width = 75
          Height = 25
          Anchors = [akTop, akRight]
          Caption = 'Odeslat >'
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'MS Sans Serif'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 2
          OnClick = cmdSendClick
        end
        object cmdClearSnd: TButton
          Left = 6
          Top = 100
          Width = 75
          Height = 25
          Caption = 'Clear'
          TabOrder = 3
          OnClick = cmdClearSndClick
        end
      end
      object GroupBox2: TGroupBox
        Left = 8
        Top = 152
        Width = 442
        Height = 145
        Anchors = [akLeft, akTop, akRight, akBottom]
        Caption = 'P'#345'ijat'#225' data'
        TabOrder = 1
        DesignSize = (
          442
          145)
        object cmdClear: TButton
          Left = 351
          Top = 12
          Width = 75
          Height = 25
          Anchors = [akTop, akRight]
          Caption = 'Clear'
          TabOrder = 0
          OnClick = cmdClearClick
        end
        object chRcvHex: TCheckBox
          Left = 8
          Top = 22
          Width = 177
          Height = 17
          Caption = 'P'#345'ijat'#225' data zobrazovat v hexa'
          TabOrder = 1
        end
        object mRcv: TMemo
          Left = 8
          Top = 43
          Width = 418
          Height = 89
          Anchors = [akLeft, akTop, akRight, akBottom]
          ScrollBars = ssVertical
          TabOrder = 2
        end
      end
    end
    object TabSheet2: TTabSheet
      Caption = 'Spinel'
      ImageIndex = 1
      DesignSize = (
        458
        309)
      object GroupBox4: TGroupBox
        Left = 8
        Top = 8
        Width = 442
        Height = 137
        Anchors = [akLeft, akTop, akRight]
        Caption = 'Odeslat Spinel paket'
        TabOrder = 0
        DesignSize = (
          442
          137)
        object Label2: TLabel
          Left = 152
          Top = 16
          Width = 44
          Height = 13
          Caption = 'Instrukce'
        end
        object Label3: TLabel
          Left = 16
          Top = 56
          Width = 23
          Height = 13
          Caption = 'Data'
        end
        object chSpinSendHex: TCheckBox
          Left = 64
          Top = 56
          Width = 161
          Height = 17
          Caption = 'Data zad'#225'na v hexa'
          TabOrder = 4
        end
        object leAddress: TLabeledEdit
          Left = 16
          Top = 32
          Width = 57
          Height = 21
          Hint = '0-255 (254=univerz'#225'ln'#237' adresa)'
          EditLabel.Width = 33
          EditLabel.Height = 13
          EditLabel.Caption = 'Adresa'
          ParentShowHint = False
          ShowHint = True
          TabOrder = 0
          Text = '254'
        end
        object leSig: TLabeledEdit
          Left = 80
          Top = 32
          Width = 65
          Height = 21
          Hint = '0-255 (m'#367#382'e nab'#253'vat libovoln'#233' hodnoty bez vlivu na funkci)'
          EditLabel.Width = 55
          EditLabel.Height = 13
          EditLabel.Caption = 'Sig (podpis)'
          ParentShowHint = False
          ShowHint = True
          TabOrder = 1
          Text = '0'
        end
        object cbInst: TComboBox
          Left = 152
          Top = 32
          Width = 145
          Height = 21
          ItemHeight = 13
          ItemIndex = 0
          TabOrder = 2
          Text = '243 ; Info'
          Items.Strings = (
            '243 ; Info'
            '227 ; Reset'
            '6 ; V'#253'robn'#237' '#250'daje'
            '242 ; '#269'ten'#237' u'#382'ivatelsk'#253'ch dat'
            '226 ; z'#225'pis u'#382'ivatelsk'#253'ch dat')
        end
        object mSDSnd: TMemo
          Left = 16
          Top = 72
          Width = 410
          Height = 57
          Anchors = [akLeft, akTop, akRight]
          ScrollBars = ssVertical
          TabOrder = 3
        end
        object cmdSPSend: TButton
          Left = 312
          Top = 31
          Width = 75
          Height = 23
          Caption = 'Odeslat >'
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'MS Sans Serif'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 5
          OnClick = cmdSPSendClick
        end
      end
      object GroupBox5: TGroupBox
        Left = 8
        Top = 152
        Width = 442
        Height = 137
        Anchors = [akLeft, akTop, akRight]
        Caption = 'P'#345'ijat'#253' Spinel paket'
        TabOrder = 1
        DesignSize = (
          442
          137)
        object Label5: TLabel
          Left = 152
          Top = 16
          Width = 93
          Height = 13
          Caption = 'Ack (k'#243'd odpov'#283'di)'
        end
        object Label6: TLabel
          Left = 16
          Top = 56
          Width = 23
          Height = 13
          Caption = 'Data'
        end
        object chSpinRcvHex: TCheckBox
          Left = 64
          Top = 56
          Width = 161
          Height = 17
          Caption = 'P'#345'ijat'#225' data zobrazit v hexa'
          TabOrder = 3
        end
        object leAdrR: TLabeledEdit
          Left = 16
          Top = 32
          Width = 57
          Height = 21
          Hint = '0-255 (254=univerz'#225'ln'#237' adresa)'
          EditLabel.Width = 33
          EditLabel.Height = 13
          EditLabel.Caption = 'Adresa'
          ParentShowHint = False
          ReadOnly = True
          ShowHint = True
          TabOrder = 0
        end
        object leSigR: TLabeledEdit
          Left = 80
          Top = 32
          Width = 65
          Height = 21
          Hint = '0-255 (m'#367#382'e nab'#253'vat libovoln'#233' hodnoty bez vlivu na funkci)'
          EditLabel.Width = 55
          EditLabel.Height = 13
          EditLabel.Caption = 'Sig (podpis)'
          ParentShowHint = False
          ReadOnly = True
          ShowHint = True
          TabOrder = 1
        end
        object mSDRcv: TMemo
          Left = 16
          Top = 72
          Width = 410
          Height = 57
          Anchors = [akLeft, akTop, akRight]
          ReadOnly = True
          ScrollBars = ssVertical
          TabOrder = 2
        end
        object cmdSPClear: TButton
          Left = 312
          Top = 31
          Width = 75
          Height = 23
          Caption = 'Smazat'
          TabOrder = 4
          OnClick = cmdSPClearClick
        end
        object eAck: TEdit
          Left = 152
          Top = 32
          Width = 145
          Height = 21
          ReadOnly = True
          TabOrder = 5
        end
      end
    end
  end
  object Panel2: TPanel
    Left = 334
    Top = 5
    Width = 140
    Height = 100
    Anchors = [akLeft, akTop, akRight]
    BevelInner = bvRaised
    BevelOuter = bvLowered
    TabOrder = 2
    DesignSize = (
      140
      100)
    object Label4: TLabel
      Left = 8
      Top = 16
      Width = 124
      Height = 57
      Alignment = taCenter
      Anchors = [akLeft, akTop, akRight]
      AutoSize = False
      Caption = 'Uk'#225'zkov'#253' p'#345#237'klad pro pou'#382'it'#237' knihovny CommIntfDll.dll'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = [fsBold]
      ParentFont = False
      WordWrap = True
    end
  end
end
