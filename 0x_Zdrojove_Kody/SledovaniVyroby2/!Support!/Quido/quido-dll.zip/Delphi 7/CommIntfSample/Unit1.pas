(*
  P��klad pou�it� komunika�n� knihovny CommIntfDll.dll pomoc� objektu TUserCommunicationInterface.
  Vytvo�eno pro Delphi 7

  Vydavatel :  Papouch s.r.o. - http://www.papouch.com/
  Autor     :  Martin Z�me�n�k zamecnik@papouch.com

  Pozn�mky  : k pou�it� funkc� je pot�eba knihovna CommIntfDll.dll, unita mapuj�c� funkce uci_IDLLMapD.pas a unita pro zaobalen� do objektu uUserInterface.
              v p��pad� pou�it� pro USB jsou pot�eba t� nainstalovan� ovlada�e FTD direct drivers a knihova FTD2XX.dll, nebo nainstalovan� virtu�ln� s�riov� port

*)
unit Unit1;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls,uUserInterface, ComCtrls, ExtCtrls;

type
  TfCommDllSample = class(TForm)
    GroupBox1: TGroupBox;
    Label1: TLabel;
    ConnectionString: TComboBox;
    cmdCreate: TButton;
    cmdOpenClose: TButton;
    cmdDlg: TButton;
    PageControl1: TPageControl;
    TabSheet1: TTabSheet;
    TabSheet2: TTabSheet;
    GroupBox3: TGroupBox;
    chSendHex: TCheckBox;
    mSend: TMemo;
    cmdSend: TButton;
    GroupBox2: TGroupBox;
    cmdClear: TButton;
    chRcvHex: TCheckBox;
    mRcv: TMemo;
    GroupBox4: TGroupBox;
    leAddress: TLabeledEdit;
    leSig: TLabeledEdit;
    Panel2: TPanel;
    Label4: TLabel;
    cmdClearSnd: TButton;
    cbInst: TComboBox;
    Label2: TLabel;
    mSDSnd: TMemo;
    Label3: TLabel;
    chSpinSendHex: TCheckBox;
    cmdSPSend: TButton;
    GroupBox5: TGroupBox;
    Label5: TLabel;
    Label6: TLabel;
    chSpinRcvHex: TCheckBox;
    leAdrR: TLabeledEdit;
    leSigR: TLabeledEdit;
    mSDRcv: TMemo;
    cmdSPClear: TButton;
    eAck: TEdit;
    procedure cmdCreateClick(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure cmdClearClick(Sender: TObject);
    procedure cmdSendClick(Sender: TObject);
    procedure cmdClearSndClick(Sender: TObject);
    procedure cmdOpenCloseClick(Sender: TObject);
    procedure cmdDlgClick(Sender: TObject);
    procedure cmdSPClearClick(Sender: TObject);
    procedure cmdSPSendClick(Sender: TObject);
  private
    CommIntf:TUserCommunicationInterface; //Objekt komunika�n�ho rozhran�
    procedure OnOpen(sender:TObject); //Procedura vyvolan� p�i ud�losti otev�en� komunika�n�ho kan�lu
    procedure OnClose(sender:TObject); //Procedura se vyvol� p�i ud�losti zav�en� komunika�n�ho kan�lu
    procedure OnDataRcv(sender:TObject); //Procedura se vyvol� p�i ud�losti p�ijet� dat
    procedure ActiveChange(Active:boolean); //Uprav� tla��tka na formul��i podle toho, zda je spojen� otev�eno �i zav�eno
  public
  end;

var
  fCommDllSample: TfCommDllSample;

implementation

{$R *.dfm}

//funkce, kter� data zapsan� v hexa (FA 12 A6) p�evede na odpov�daj�c� data
function HexToText(const Hex:string):string;
var s:string;
    i:integer;
begin
  S:=StringReplace(Hex,' ','',[rfReplaceAll]);
  S:=StringReplace(S,#13,'',[rfReplaceAll]);
  S:=StringReplace(S,#10,'',[rfReplaceAll]);
  //-- odstran�ny mezery a entery
  result:='';
  for i:=0 to length(S) div 2 - 1 do
  begin
    result:=result+chr(strtoint('$'+copy(S,i*2+1,2)));
  end;
end;
//funkce, kter� data p�eveda na hexa z�pis
function TextToHex(const Text:string):string;
var i:integer;
begin
  result:='';
  for i:=1 to length(Text) do
  begin
    result := result + IntToHex(ord(Text[i]),2) + ' ';
  end;
end;
//zm�n� netisknuteln� znaky na te�ky
function TextToPrintable(const Text:string):string;
var I:integer;
begin
  result:=Text;
  for i:=1 to length(Text) do
  begin
    if ((result[i]<#32)or(result[i]>=#127)) then result[i]:='.';
  end;
end;
//-------------------------------------
procedure TfCommDllSample.ActiveChange(Active: boolean);
begin
  //Zaktivn� �i zneaktivn� tla��tka pro odesl�n� dat
  cmdSend.Enabled := Active;
  cmdSPSend.Enabled := Active;
  //Zm�n� popisek tla��ta
  if Active
    then cmdOpenClose.Caption := 'Zav��t'
    else cmdOpenClose.Caption := 'Otev��t';
end;

procedure TfCommDllSample.cmdCreateClick(Sender: TObject);
begin

  //Zru�� st�vaj�c� komunika�n� rozhran�, pokud je vytvo�eno
  if assigned(CommIntf) then
  begin
    FreeAndNil(CommIntf); //Zru�� rozhran�
    ActiveChange(false);  //Nastav� tla��tka na formul��i
  end;

  CommIntf:=TUserCommunicationInterface.Create(ConnectionString.Text);
  //-Vytvo�� komunika�n� rozhran� podle p�ipojovac�ho �et�zce

  if assigned(CommIntf) then //-- pokud se poda�ilo vytvo�it
  begin
    //-- namapov�n� ud�lost� komunika�n�ho rozhran� (otev�en� a zav�en� komunikace, p��jem dat)
    CommIntf.OnOpen := OnOpen;
    CommIntf.OnClose := OnClose;
    CommIntf.OnDataRcv := OnDataRcv;
    if MessageDlg('Bylo vytvo�eno komunika�n� rozhran�. Chcete ho otev��t?',mtInformation,[mbYes,mbNo],0)=IDYES
      then CommIntf.Open; //-- otev�en� komunikace
  end;

end;

procedure TfCommDllSample.FormDestroy(Sender: TObject);
begin
 //P�i ukon�en� se zru�� komunika�n� rozhran�, pokud je vytvo�eno
 if assigned(CommIntf)
   then CommIntf.Free;
end;

procedure TfCommDllSample.OnClose(sender: TObject);
begin
  ActiveChange(false); //Uprav� tla��tka na formul��i (zneaktivn� tla��tka pro odes�l�n� dat, n�pis na tla��tku pro otev�en� nastav� na "otev��t")
end;

procedure TfCommDllSample.OnDataRcv(sender: TObject);
var S:string;
begin
  if sender is TUserCommunicationInterface then
  begin
     S:=(sender as TUserCommunicationInterface).ReadString; //!!!Na�ten� p�ijat�ch dat
     if chRcvHex.Checked //Pokud je za�krtl� zobrazovat v hexa ...
        then mRcv.Lines.Add(TextToHex(S)) // ... p�evedou se p�ijat� data do hexa form�tu a zobraz� ...
        else mRcv.Lines.Add(TextToPrintable(S)); // ... jinak se zobraz� p��mo, netisknuteln� znaky se p�evedou na te�ky
  end;
end;

procedure TfCommDllSample.OnOpen(sender: TObject);
begin
  ActiveChange(true); //Uprav� tla��tka na formul��i (zaktivn� tla��tka pro odes�l�n� dat, n�pis na tla��tku otev��t zm�n� na zav��t)
end;

procedure TfCommDllSample.FormCreate(Sender: TObject);
begin
  ActiveChange(false);
  //Uprav� tla��tka na formul��i (zneaktivn� tla��tka pro odes�l�n� dat, n�pis na tla��tku pro otev�en� nastav� na "otev��t")
end;

procedure TfCommDllSample.cmdClearClick(Sender: TObject);
begin
  mRcv.Clear; //vyma�e p�ijat� data
end;

procedure TfCommDllSample.cmdSendClick(Sender: TObject);
begin
 //Ode�le zadan� data
 if chSendHex.Checked  //Pokud je za�krtl� zad�v�n� v hexa ...
   then CommIntf.WriteString(HexToText(mSend.Text)) //... p�evedou se data z hexa ...
   else CommIntf.WriteString(mSend.Text); // ... jinak se ode�le prost� text jako data
end;

procedure TfCommDllSample.cmdClearSndClick(Sender: TObject);
begin
  mSend.Clear; //Vyma�e data pro odesl�n�
end;

procedure TfCommDllSample.cmdOpenCloseClick(Sender: TObject);
begin
  if assigned(CommIntf) then //Rozhran� mus� b�t vytvo�eno ...
  begin
    CommIntf.Active := not CommIntf.Active; //Pokud bylo spojen� otev�eno tak se zav�e, v opa�n�m p��pad� se otev�e
  end else ShowMessage('Nejprve je komunika�n� rozhran� t�eba vytvo�it.'); //... pokud nen� vytvo�eno - upozorn�n�
end;

procedure TfCommDllSample.cmdDlgClick(Sender: TObject);
var S:string;
begin
  //Uprav� se p�ipojovac� �et�zec pomoc� dialogu

  S:=ConnectionString.Text; //p�vodn� p�ipojovac� �et�zec
  if TUserCommunicationInterface.ConnectionStringDlg(S) then
  begin //Pokud bylo v dialogu stisknuto OK
    ConnectionString.Text := S; //Zm�n� se p�ipojovac� �et�zec podle dialogu

    //Nab�dne se rovnou rozhran� podle komunika�n�ho �et�zce vytvo�it
    if MessageDlg('Chcete rovnou komunika�n� spojen� vytvo�it?',mtConfirmation,[mbYes,mbNo],0)=IDYES then
    begin
      cmdCreateClick(cmdCreate);
    end;
  end;
  
end;

procedure TfCommDllSample.cmdSPClearClick(Sender: TObject);
begin
  //Vyma�e zobrazen� p�ijat�ho spinel paketu
  eAck.Text := '';
  leAdrR.Text := '';
  leSigR.Text := '';
  mSDRcv.Text := '';
end;

procedure TfCommDllSample.cmdSPSendClick(Sender: TObject);
var Data:string;
    Adr,Sig,Inst_Ack:byte;
begin
  //Ode�le se zadan� spinel paket a p�ijme se odpov��

  //Nastaven� dat :
  if chSpinSendHex.Checked //pokud je za�krtnuto zad�v�n� dat v hexa ...
    then Data:=HexToText(mSDSnd.Text) //...p�evede se z hexa...
    else Data:=mSDSnd.Text; //...jinak se bere prost� text

  Adr:=StrToInt(leAddress.Text); //Nasteven� adresy

  Sig := StrToInt(leSig.Text); //Nastaven� podpisu

  //Nastaven� instrukce:
  if pos(';',cbInst.Text)>0 //Pokud k�d instrukce obsahuje koment�� ( za st�edn�kem)...
    then Inst_Ack:=StrToInt(trim(Copy(cbInst.Text,1,pos(';',cbInst.Text)-1))) //... hled�me instrukci p�ed st�edn�kem ...
    else Inst_Ack:= StrToInt(cbInst.Text); //... jinak v cel�m obsahu

  if CommIntf.SndRcvSpin97(Adr,Sig,Inst_Ack,Data) then //!!!Ode�leme paket a �ek�me na odpov��
  begin //pokud odpov�� do�la :
    //Zobrazen� p�ijat�ho paketu (adresa, sig, ack a data)
    leAdrR.Text := inttostr(Adr);
    leSigR.Text := inttostr(Sig);
    eAck.Text := inttostr(Inst_Ack);
    case Inst_Ack of //U n�vratov�ho k�du Ack zobraz�me popis
      0: eAck.Text := eAck.Text + ' - OK';
      $0C..$0F: eAck.Text := eAck.Text + ' - Samovoln� vys�l�n�';
      else eAck.Text := eAck.Text + ' - Chyba';
    end;

    if chSpinRcvHex.Checked //Pokud je za�krtnuto zobrazen� dat v hexa ...
      then  mSDRcv.Text := TextToHex(Data) //... zobrazen� v hexa ...
      else  mSDRcv.Text := TextToPrintable(Data); //... jinak zobrazit tisknuteln� znaky dat.

  end else ShowMessage('Spinel instrukce neusp�la.'); //pokud nedo�la odpov��
end;

end.
