(*
  QuidoStackDll - Mapov�n� funkc� z knihovny QuidoStackDll.dll

  Vydavatel :  Papouch s.r.o. - http://www.papouch.com/
  Autor     :  Martin Z�me�n�k zamecnik@papouch.com

  Pozn�mky  : k pou�it� funkc� jsou pot�eba knihovny QuidoStackDll.dll a CommIntfDll.dll,
              v p��pad� pou�it� pro USB jsou pot�eba t� nainstalovan� ovlada�e FTD direct drivers a knihova FTD2XX.dll
  Upozorn�n�: ve�ker� parametry Index, a to i v p��pad� vstup� a v�stup� quida, jsou ��slov�ny od 0 !!!
*)

unit q_QuidoDllMapD;
{$DEFINE InitDLL}

interface
uses windows,forms;
//konstatny
const QDLLName = 'QuidoStackDll.dll';
      //-- identifikace ud�lost� (event) vyvolan�ch Quidem. pro zas�l�n� ud�lost� registrujet jejich p��jem pomoc� qRegisterMsgNotifications nebo qRegisterCallBackNotifications
      qev_Base = $1FF;
      qev_InputsChange = qev_Base + 1; //zm�na vstup� - obecn� ozn�m�, z� byla zaznamen�na zm�na n�kter�ho vstupu
      qev_OutputsChange = qev_Base + 2; //zm�na v�stup� - ozn�m�, �e byl zn�n�n n�kter� v�stup
      qev_InputChange = qev_Base + 3; //zm�na vstupu - ozn�m�, �e byl zm�n�n jednotliv� vstup (oznamuje ka�d� vstup zvl᚝)
      qev_OutputChange = qev_Base + 4; //zm�na v�stupu - ozn�m�, �e byla zaznamen�na zm�na jednotliv�ho v�stupu
      qev_CIOpen = qev_Base + 5; //-- otev�en� komunika�n�ho kan�lu quida
      qev_CIClose = qev_Base + 6; //-- uzav�en� komunika�n�ho kan�lu quida
//typy
type reStat = integer; //-- typ pro n�vratovou hodnotu funkc�; 0 = funkce prob�hla v po��dku, jinak chybov� k�d <> 0
     THandleNotificationEvent = procedure (Handle:THandle;Event:word;Param:word;CallBackID:cardinal);stdcall; //-- typ callbackov� procedure pro oznamov�n� ud�lost� (lze pou��t t� oznamov�n� p�es windows zpr�vy)

var

//--- Dynamicky mapovan� funkce z DLL knihovny

DllInfo : function :pChar; stdcall; //-- vrac� informa�n� text o knihovn�

qHandlesCount: function ():integer; stdcall; //-- vrac� po�et vytvo�en�ch Quid (funkcemi qCreateQuido...); -1 = chyba
qHandleByIndex: function (index:integer):THandle; stdcall; //-- vrac� handle na Quido podle indexu (0..qHandlesCount-1); 0 = neplatn� handle
ciHandlesCount: function ():integer; stdcall; //-- vrac� po�et vytvo�en�ch komunika�n�ch rozhran� (a� ji� spole�n� s Quidem nebo zvl᚝ v CommIntfDll.dll); -1=chyba
ciHandleByIndex: function (index:integer):THandle; stdcall; //-- vrac� handle na komunika�n� rozhran� podle indexu (0..ciHandlesCount-1); 0=chyba

qCreateQuido: function (connectionstring:pChar; deviceString:pchar):THandle; stdcall;
    //-- vytvo�i objekt Quida. vrac� handle vytvo�en�ho objektu Quida; 0 = nepovedlo se vytvo�it
    //--       connection string je �et�zec pro vytvo�en� komunika�n�ho rozhrann�, ur�uje komunika�n� kan�l a jeho nastaven� (s�riov� port, tcp, udp, nebo ftd_usb)
    //--       devicestring specifikuje parametry za��zen� Quido (adresu. v p��pad� �e je na komunika�n�m kan�lu pouze jedno za��zen�, lze zadat univerz�ln� adresu $FE)
    //   Tvorba connectionstringu : jsou to hodnoty ve tvaru "parametr=hodnota" odd�leny st�edn�kem. ur�uj� typ p�ipojen�
    //          nejd�le�it�j��m parametrem je "provider", ur�uje typ komunika�n�ho kan�lu. m��e to b�t SERIAL_PORT, TCP_CLIENT, UDP_CLIENT nebo FTD_USB
    //          ka�d� kan�l pak m��e m�t dal�� parametry. SERIAL_PORT (comport=��slo portu;baudrate=rychlost - nemus� b�t zad�no), TCP_CLIENT(host=ip adresa za��zen�;port=tcp port za��zen�), UDP_CLIENT(stejn� jako TCP), FTD_USB(index=po�adov� ��slo za��zen�; nebo device=��st n�zvu za��zen�; nebo serial_number=s�riov� ��slo za��zen�; nebo vid=vid;pid=pid; nebo nemus� m�t ��dn� parametr, vezme se prvn� p�ipojen� za��zen� typu FTD_USB
    //          p��klady: "provider=SERIAL_PORT;comport=1", "provider=TCP_CLIENT;host=192.168.1.254;port=10001", "provider=UDP_CLIENT;host=192.168.1.254;port=10001", "provider=FTD_USB;device=Quido"
    //   Tvorba devicestringu: p�. "addr=12", "addr=$FE" ($ - znamen� ��slo je zad�no v hexa, $FE=univerz�ln� adresa)

qCreateQuidoCI: function (ciHandle:THandle; devicestring:pChar):THandle; stdcall; //-- Vytvo�� objekt Quida, pou�ije se komunika�n� rozhrann� ji� explicitn� vytvo�en� v CommIntfDll (ciHandle)
qCreateQuidoEx: function (connectionstring:pChar; deviceString:pchar; ciEventType:cardinal):THandle; stdcall; //-- umo��uje specifikovat zp�sob vol�n� ud�lost� mezi komunika�n�m rozhrann�m a objektem quida  - ciEventType (0 - sendmessage, 1 - callback, 2 - postmessage). nedoporu�uje se pou��vat, pokud k tomu nen� d�vod
qCreateQuidoCIEx: function (ciHandle:THandle; devicestring:pChar; ciEventType:cardinal):THandle; stdcall; //-- pou�it� explicitn� vytvo�en�ho komunika�n�ho rozhrann�, specifikace zp�sobu vol�n� ud�lost�

qGetQuidoCIHandle : function (qHandle:THandle):THandle;stdcall;  //-- vr�t� handle komunika�n�ho rozhran� p�ipojen�mu ke Quidu

qOpen : function (qHandle:THandle):reStat; stdcall; //-- otev�e komunika�n� kan�l Quida (otev�e port, nav�e tcp spojen�, ... podle typu komunika�n�ho rozhran�; nutno pro komunikaci se za��zen�m; vr�t� 0 pokud OK, chybov� k�d v opa�n�m p��pad� (plat� obecn� pro n�vratov� typ reStat (integer))
qClose : function (qHandle:THandle):reStat; stdcall; //-- zav�e komunika�n� kan�l Quida; vr�t� 0 pokud OK, chybov� k�d v opa�n�m p��pad�
qIsOpened : function (qHandle:THandle;var Opened:longbool):reStat; stdcall; //-- zjist�, zda je komunika�n� kan�l quida otev�en
qReleaseQuido : function (qHandle:THandle):reStat;stdcall; //-- zru�� objekt quida (v�etn� p��slu�n�ho komunika�n�ho rozhran� - pokud nen� zad�no p�i vytvo�en� explicitn� pomoc� handlu - qCreateQuidoCI)

qInputsCount : function (qHandle:THandle):integer;stdcall; //-- vr�t� po�et vstup� Quida; -1=chyba
qOutputsCount : function (qHandle:THandle):integer;stdcall; //-- vr�t� po�et v�stup� Quida; -1=chyba
qInputCountersCount : function (qHandle:THandle):integer;stdcall; //-- vr�t� po�et ��ta�� vstup�; -1=chyba; standardn� po�et ��ta�� vstup�=po�et vstup�, maxim�ln� v�ak 60

qInputStateByIndex : function (qHandle:THandle;Index:integer;var State:longbool):reStat;stdcall;//-- vr�t� do State stav vstupu podle indexu (0..po�et vstup�-1) (true=je na vstupu nap�t�, false=neni); n�vratov� hodnota: 0-ok, jinak chyba
qOutputStateByIndex : function (qHandle:THandle;Index:integer;var State:longbool):reStat;stdcall;//-- vr�t� do State stav v�stupu podle indexu (0..po�et vstup�-1)  (true=je na vstupu nap�t�, false=neni); n�vratov� hodnota: 0-ok, jinak chyba
qInputCounterValueByIndex : function (qHandle:THandle;Index:integer;var Value:cardinal;NullCounter:longbool):reStat;stdcall; //-- vr�t� do Value hodnotu ��ta�e vstupu podle indexu (0..po�et ��ta��-1); pokud je NullCounter true, ��ta� se z�hy vynuluje

qGetOutputPWM: function(qHandle:THandle; Output:Integer; var PWM:Integer):reStat; stdcall;
qSetOutputPWM: function(qHandle:THandle; Output:Integer; const PWM:Integer):reStat; stdcall;

qGetInputPPS: function(qHandle:THandle; Input:Integer; Sec:Integer; var PPS:Integer):reStat; stdcall;

qGetInputs : function (qHandle:THandle; Inputs:pBoolean; var Len:Integer):reStat; stdcall; //-- vr�t� v poli stav v�ech vstup�. do inputs je t�eba zadat ukazatel na pole alokovan� na (po�et vstup�) byt�; do Len je t�eba zadat velikost tohoto pole; p�i pou�it� klasick�ho pole v delphi (array of boolean) je t�eba zadat ukazatel na prvn� prvek pole (@pole[0]);
             //---  pokud je v�e v po��dku, od Inputs se vypln� stavy vstup�, do Len se vypln� aktu�ln� velikost pole a n�vratov� hodnota je 0
             //---  pokud se do Inputs zad� nil, do Len se vypln� pot�ebn� velikost pole a n�vratov� hodnota je 0
             //---  pokud se vyskytne chyba (stav vstup� nelze zjistit, nebo zadan� velikost Len je nedostate�n�), n�vratov� hodnota je chybov� k�d <> 0
qGetOutputs : function (qHandle:THandle; Outputs:pBoolean; var Len:Integer):reStat; stdcall;//-- vr�t� v poli stav v�ech v�stup�. princip jako u qGetInputs

qSetOutput : function (qHandle:THandle; Index:Integer; State:longbool):reStat; stdcall;//-- Nastav� stav v�stupu Quida podle indexu (State:true=sepnout,false=rozepnout). pokud je n�vratov� hodnota 0=OK, jinach chyba
qSetOutputTimered : function (qHandle:THandle; Index:Integer; State:Boolean; Time:integer):reStat; stdcall;//-- Nastav� stav v�stupu na ur�it� �as (Time=�as ve vte�in�ch).pokud je n�vratov� hodnota 0=OK, jinach chyba

qSetOutputs : function (qhandle:THandle; Outputs:pBoolean; Len:Integer):reStat;  stdcall;//-- Nastav� najednou stav v�ech v�stup�. do outputs se zad� pole boolen� (1 bytov�ch). Len ur�uje velikost pole; pokud je n�vratov� hodnota 0=OK, jinach chyba

qGetRecentInputsState : function (qHandle:THandle; Inputs:pBoolean; var Len:Integer):reStat; stdcall; //-- vr�t� v poli naposledy zn�m� stav vstup� - stejn� jako qGetInputs, akor�t se nedotazuje p��mo za��zen�, ale vrac� naposledy zji�t�n� stav. vhodn� nap�. po ud�losti qev_InputsChange.
qGetRecentOutputsState : function(qHandle:THandle; Outputs:pBoolean; var Len:integer):reStat; stdcall; //-- vr�t� v poli naposledy zn�m� stav v�stup� - procuje jako qGetRecentInputsState

qGetRecentInputByIndex : function (qHandle:THandle; Index:Integer; var State:longbool):reStat;stdcall; //-- vr�t� naposledy zn�m� stav vstupu Quida podle Indexu (jako qGetInputStateByIndex, akor�t se nedotazuje p��mo za��zen�, ale vrac� naposledy zji�t�n� stav
qGetRecentOutputByIndex : function (qHandle:THandle; Index:Integer; var State:longbool):reStat;stdcall;//-- vr�t� naposledy zn�m� stav v�stupu Quida podle Indexu. pracuje jako qGetRecentInputByIndex
qGetRecentInputCounterByIndex:function(qHandle:THandle; Index:Integer; var Value:integer):reStat;stdcall; //-- vr�t� naposledy zn�m� stav ��ta�e vstupu Quida podle Indexu.
qGetRecentCounterSettingByIndex:function(qHandle:THandle; Index:Integer; var Rising,Falling:longbool):reStat;stdcall; //-- vr�t� naposledy zn�m� stav nastaven� vstupu Quida podle Indexu

qRefreshRecentStates: function(qHandle:THandle;Inputs:longbool=true; Outputs:longbool=true; Counters:longbool=true; CounterSettings:longbool=true):reStat;stdcall;
//qCheckInputsState: function (qHandle:THandle; Wait:longbool):reStat; stdcall; //-- zjist� ze za��zen� stavy vstup�. ty jsou pak k dispozici pomoc� funkc� qGetRecentInputsstate a qGetRecentInputByIndex
//qCheckOutputsState: function (qHandle:THandle; Wait:longbool):reStat; stdcall; //-- zjist� ze za��zen� stavy v�stup�. ty jou pak k dispozici pomoc� funkc� qGetRecentOutputsState a qGetRecentOutputByIndex

qGetAutoNotify : function (qHandle:THandle; var Value:longbool):reStat;stdcall; //-- vr�t� do Value zda je aktivov�no automatick� oznamov�n� zm�ny stavu vstup� (pokud je registrov�no oznamov�n� pomoc� qRegisterMsgNotifications nebo qRegisterCallBackNotifications;
qSetAutoNotify : function(qHandle:THandle; Value:longbool):reStat;stdcall; //-- nastav� nebo zru�� automatick� oznamov�n� zm�ny stavu vstup� (true=nastavit, false=zru�it)

qSetCounterSetting :function (qHandle:THandle;Index:integer; Rising,Falling:longbool):reStat;stdcall; //-- Nastaven� ��ta�e (na kter� hrany sign�lu se inkrementuje - rising=n�b�n�, falling=sestupn�)
qGetCounterSetting :function (qHandle:THandle;Index:integer; var Rising,Falling:longbool):reStat;stdcall; //-- Zji�t�n� nastaven� ��ta�e

qRegisterMsgNotifications : function (Handle:THandle;WHandle:hwnd;Msg:cardinal;blocking:longbool=true):reStat; stdcall; //-- registruje zas�l�n� ud�lost� Quida pomoc� Windows zpr�v (Otev�en� a zav�en� komunika�n�ho kan�lu, zm�ny stav� vstup�, ...). zad�v� se hWnd okna, kter� zpr�vu p�ij�m� a identifikaci zpr�vy, kter� je zas�l�na. v parametru zpr�vy WParam je zasl�n handle Quida, kter� ji zas�l�, v LParamLo je zasl�n typ ud�losti, LParamHi p��padn� dodate�n� parametr
qUnregisterMsgNotifications : function (Handle:THandle):reStat; stdcall;  //-- ru�� zas�l�n� ud�lost� Quida pomoc� Windows zpr�v
qRegisterCallBackNotifications : function (Handle:THandle;CallBackEntryPoint:THandleNotificationEvent;CallBackID:cardinal):reStat;stdcall; //-- registruje zas�l�n� ud�lost� Quida pomoc� vol�n� callbackov� funkce form�tu THandleNotificationEvent
qUnregisterCallBackNotifications : function (Handle:THandle):reStat;stdcall;//-- ru�� zas�l�n� ud�lost� Quida pomoc� callbackov� funkce

qInfo : function (qHandle:THandle; Info:pChar; var Len:integer):reStat; stdcall; //-- vrac� textovou identifikaci za��zen� (Quida)
qReset : function (qHandle:THandle):reStat;stdcall; //-- Resetov�n� za��zen�
qGetAddress:function (qHandle:THandle;var Addr:integer):reStat; stdcall; //-- zji�t�n� adresy za��zen�
qSetAddress:function (qHandle:THandle;var Addr:integer):reStat; stdcall; //-- nastaven� adresy za��zen� (0-253)
qGetUserData:function (qHandle:THandle; UserData:pChar;var Len:integer):reStat; stdcall; //-- z�sk�n� u��vatelsk�ch dat (16 byt�)
qSetUserData:function (qHandle:THandle; UserData:pChar; Len:integer):reStat; stdcall; //-- nastaven� u�ivatelsk�ch dat (16 byt�)
qGetFactoryInfo:function (qHandle:THandle; var ProductID:integer; var SerialNumber:integer;var FactoryData:cardinal):reStat; stdcall; //-- zj�sk�n� v�robn�ch dat (s�riov�ho ��sla,..) za��zen�

qSndRcvSpin97: function (qHandle:THandle;Inst:byte;Data:pointer;DataLen:integer;
                  var RcvAck:byte;RcvData:pointer;var RcvDataLen:integer;MaxTimeOut:integer):reStat;stdcall;
                  //-- Za�le spinel paket, zadan� instrukc� Inst a daty Data (velikosti DataLen) a �ek� na odpov�� (maxim�ln� MaxTimeOut milisekund)
                  // Pokud p�ijde odpov��, n�vratov� hodnota je 0, do bufferu RcvData o velikosti RcvDataLen se zap�ou vr�cen� data spinel paketu a v RcvDataLen se vr�t� aktu�ln� velikost dat.
                  // RcvAck vr�t� k�d odpov�di (0 = OK)
                  // Pokud se paket neode�le, nebo se nevr�t� odpov��, nebo vznikne jin� chyba, n�vratov� hodnota <> 0

ciGetConnectionStringDlg:function(OutConnStr:pChar;var Len:integer;var OKReturn:longbool;DefaultValue:pChar=nil;Caption:pChar=nil):reStat; stdcall; //-- Vyvol� dialogov� okno pro vytvo�en� p�ipojovac�ho �et�zce (connection string). Vrac� hodnotu<>0, pokud nastala chyba
                        //-- OutConStr:sem je vr�cen connectionstring, Len:velikost bufferu OutConStr, OKReturn:vr�ceno true, pokut bylo stisknuto OK, DefaultValue:p��padn� p�ednastaven� v�choz�ho connectionstringu, Caption: vlastn� titulek dialogu

LastError : function:reStat;stdcall; //-- vr�t� chybov� k�d naposledy volan� funkce. 0=funkce prob�hla v po��dku
LastErrorText:function (Text:pchar;var Size:integer):reStat;stdcall; //-- vr�t� text chyby naposledy volan� funkce

function _LastErrorText:string; //-- zjednodu�uje pou�it� LastErrorText
procedure RaiseLastError(RaiseIfNoError:boolean=false); //-- procedura, kter� vyvol� vyj�mku s odpov�daj�c�m textem chyby ktr� vznikla p�i naposledy volan� funkci, pokud vznikla
function _GetConnectionStringDlg(var ConnectionString:string;Caption:string=''):boolean;
function _SndRcvSpin97(qHandle:THandle;Inst:byte;const Data:string;var RcvAck:byte;var RcvData:string;MaxTimeOut:integer=500):boolean;

//-- funkce pro detekci �sp�nosti zaveden� knihovny
function QDllOK:boolean; //-- vrac� true, pokud byla knihovna a v�echny jej� funkce v po��dku zavedeny
function QDllInitMsg:string; //-- vrac� text chyby, pokud nebyla knihovna v po��dku zavedena
procedure QDTestInit; //-- ned�l� nic, pokud byla knihovna v po��dku zavedena, jinak vyvol� vyj�mku s textem chyby


implementation
uses SysUtils,messages;
var DllInited:boolean;
    hDll:THandle;
    DllInitMsg:string;


function QDllInitMsg:string;
begin
  if QDllOK then result:='' else result:=DllInitMsg;
end;

procedure QDTestInit;
begin
  if not qdllok then raise Exception.Create(DllInitMsg);
end;

function _LastErrorText:string;
var S:string;
    l:integer;
begin
try
  result:='';
  if LastError <> 0 then
  begin
    LastErrorText(nil,L);
    setlength(s,L);
    if L>0 then
    if LastErrorText(@S[1],L)=0 then result:=copy(s,1,L) else result:='Unknown error in LastErrorText.';
  end;
except
  on e:exception do raise exception.Create('Error in calling LastErrorText.'#13#10+ e.Message);
end;
end;

procedure RaiseLastError(RaiseIfNoError:boolean=false);
var S:string;
    l:integer;
begin
  if (LastError <> 0) then
  begin
    raise exception.Create(_LastErrorText);
  end
   else
  begin
    if RaiseIfNoError
     then raise Exception.Create('Unknown error');
  end;
end;

function _GetConnectionStringDlg(var ConnectionString:string;Caption:string=''):boolean;
var s,dv:string;
    L:integer;
    R:longbool;
begin
  l:=256;
  result:=false;
  setlength(s,l);
  dv:=ConnectionString;
  if ciGetConnectionStringDlg(@s[1],L,R,pansichar(DV),pansichar(Caption))=0 then
  begin
    if R then
    begin
      setlength(s,l);
      ConnectionString:=s;
      if s<>'' then result:=true;
    end;
  end else raise Exception.Create(_LastErrorText);
end;

function _SndRcvSpin97(qHandle:THandle;Inst:byte;const Data:string;var RcvAck:byte;var RcvData:string;MaxTimeOut:integer=500):boolean;
var S:string;
    Len:integer;
    P:Pointer;
begin
  Len:=512;
  setlength(S,Len);
  if (length(Data)>0) then P:=@Data[1] else P:=nil;
  result:= qSndRcvSpin97(qHandle,Inst,P,length(Data),RcvAck,@S[1],Len,MaxTimeOut)=0;
  if result then
  begin
    setlength(S,Len);
    RcvData:=S;
  end;
end;


function QDllOK:boolean;  
{}procedure Map(var ProcAddr:Pointer;const Name:string);
{}begin
    ProcAddr:=GetProcAddress(hDll,pansichar(Name));
    if not assigned(ProcAddr) then raise Exception.Create('Can not map function '+Name+ ' in '+qdllname);
{}end;
begin
  result:=true;
  if DllInited then
  begin
    result:=(hDLL<>0);
  end else
  begin
    try
      DllInited:=true;
      result:=false;
      dllinitmsg:='';
      hDLL := LoadLibrary(pansichar(qdllname));
      if hDLL=0 then
      begin
        DllInitMsg := 'Can''t load library '+QDLLName + '.';
        exit;
      end;
      //Namapov�n� funkc�
      Map(@DllInfo,'DllInfo');
      Map(@ciHandlesCount,'ciHandlesCount');
      Map(@ciHandleByIndex,'ciHandleByIndex');
      Map(@qHandlesCount,'qHandlesCount');
      Map(@qHandleByIndex,'qHandleByIndex');
      Map(@qCreateQuidoCI,'qCreateQuidoCI');
      Map(@qCreateQuido,'qCreateQuido');
      Map(@qCreateQuidoCIEx,'qCreateQuidoCIEx');
      Map(@qCreateQuidoEx,'qCreateQuidoEx');
      Map(@qGetQuidoCIHandle,'qGetQuidoCIHandle');
      Map(@qOpen,'qOpen');
      Map(@qClose,'qClose');
      Map(@qIsOpened,'qIsOpened');
      Map(@qReleaseQuido,'qReleaseQuido');
      Map(@qInputsCount,'qInputsCount');
      Map(@qOutputsCount,'qOutputsCount');
      Map(@qInputCountersCount,'qInputCountersCount');
      Map(@qInputStateByIndex,'qInputStateByIndex');
      Map(@qOutputStateByIndex,'qOutputStateByIndex');
      Map(@qInputCounterValueByIndex,'qInputCounterValueByIndex');
      Map(@qGetOutputPWM,'qGetOutputPWM');
      Map(@qSetOutputPWM,'qSetOutputPWM');
      Map(@qGetInputPPS,'qGetInputPPS');
      Map(@qGetInputs,'qGetInputs');
      Map(@qGetOutputs,'qGetOutputs');
      Map(@qSetOutput,'qSetOutput');
      Map(@qSetOutputTimered,'qSetOutputTimered');
      Map(@qSetOutputs,'qSetOutputs');
      Map(@qGetRecentInputsState ,'qGetRecentInputsState');
      Map(@qGetRecentOutputsState,'qGetRecentOutputsState');
      Map(@qGetRecentInputByIndex,'qGetRecentInputByIndex');
      Map(@qGetRecentOutputByIndex,'qGetRecentOutputByIndex');
      Map(@qGetRecentInputCounterByIndex,'qGetRecentInputCounterByIndex');
      Map(@qGetRecentCounterSettingByIndex,'qGetRecentCounterSettingByIndex');
      Map(@qRefreshRecentStates,'qRefreshRecentStates');
      Map(@qGetAutoNotify,'qGetAutoNotify');
      Map(@qSetAutoNotify,'qSetAutoNotify');
      Map(@qRegisterMsgNotifications,'qRegisterMsgNotifications');
      Map(@qUnregisterMsgNotifications ,'qUnregisterMsgNotifications');
      Map(@qRegisterCallBackNotifications,'qRegisterCallBackNotifications');
      Map(@qUnregisterCallBackNotifications,'qUnregisterCallBackNotifications');
      Map(@qInfo,'qInfo');
      Map(@qReset,'qReset');
      Map(@qGetAddress,'qGetAddress');
      Map(@qSetAddress,'qSetAddress');
      Map(@qGetUserData,'qGetUserData');
      Map(@qSetUserData,'qSetUserData');
      Map(@qGetFactoryInfo,'qGetFactoryInfo');

      Map(@LastError,'LastError');
      Map(@LastErrorText,'LastErrorText');
      Map(@ciGetConnectionStringDlg,'ciGetConnectionStringDlg');
      Map(@qGetCounterSetting,'qGetCounterSetting');
      Map(@qSetCounterSetting,'qSetCounterSetting');

      Map(@qSndRcvSpin97,'qSndRcvSpin97');
      result:=true;
    except
      on e:exception do
      begin
        if hDll<>0 then
        begin
           FreeLibrary(hDLL);
           hDll := 0;
        end;
        DllInitMsg := e.Message;
      end;
    end;
  end;
end;

initialization
 //-- inicializace zaveden� knihovny
 DllInited := false;
 hDll := 0;
 {$IFDEF InitDLL}
 if not QDllOK then
  if MessageBox(0,pansichar(DllInitMsg+#13#10+'Terminate aplication?'),'Error in loading library',MB_YESNO+MB_ICONERROR)=IDYes
    then PostMessage(Application.Handle,WM_QUIT,0,0);
 {$ENDIF}
finalization
 if hDLL<>0 then FreeLibrary(hDll);
 hDll:=0;
end.
