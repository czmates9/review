-- not null a default nelze kombinovat
-- numeric - max 15, 5
-- datetime -> timestamp
-- ntext -> varchar(128)
-- GUID uniqueidentifier - a� od verze PSQL 9.5 (v Rokospolu OK)
-- desc je rezervovan� slovo (nutno tedy ps�t v uvozovk�ch)


CREATE TABLE CZPRO_VPH (
	CountEntries int DEFAULT 1, --��slo d�vky, 
	SOPNUMBE varchar (17) NOT NULL, --��slo v�r.zak�zky,
	SOPTYPE varchar (11) DEFAULT '', --typ zak�zky,
	SOPDESC varchar (51) NULL, -- popis zak�zky,
	VNDDOCNMH varchar (21) NULL, -- ��slo objednatele,
	BarcodeH varchar (31) NOT NULL, -- ��r. k�d zak�zky,
	LOCNCODE varchar (11) NULL, --lokace,
	DateProd smallint NOT NULL, --o�ek. Datum v�roby,
	Rez1 varchar(11) NOT NULL, --rezerva 1,
	Rez2 varchar(11) NOT NULL, --rezerva 2,
	TermID tinyint NOT NULL, --ID term. - posl. na�ten� dat,
	LSTMod TIMESTAMP NOT NULL, --�as.raz�tko posl. modifi.,
	DEX_ROW_ID IDENTITY ,
CONSTRAINT PK_CZPRO_VPH PRIMARY KEY
(
 SOPNUMBE, CountEntries
)
)

#

CREATE TABLE CZPRO_VPP (
	CountEntries int DEFAULT 1, -- ��slo d�vky,
	SOPNUMBE varchar (17) NOT NULL, -- ��slo v�r.zak�zky,
	ITEMNMBR varchar (31) NOT NULL, -- ID polo�ky,
	ITEMTYPE varchar (11) DEFAULT '',-- typ polo�ky,
	ITEMDESC varchar (51) NULL, -- popis polo�ky,
	ITEMMJ varchar (5) NULL, -- m�rn� jednotka polo�ky
	VNDDOCNMP varchar (21) NULL, -- ��slo dok. extern�,
	VNDITNUM varchar (31) NULL, --��slo polo�ky extern�,
	ORD int DEFAULT 0, --po�ad� polo�ky (operace),
	BarcodeP varchar (31) NOT NULL, --��rov� k�d polo�ky,
	LOCNCODE varchar (11) NULL, -- lokace,
	QTYSHPPD numeric(15, 5) NOT NULL, -- mno�stv�,
	QTYDOKON numeric(15, 5) DEFAULT 0, -- mno�stv� dokoncene rucnim odvodem,
	QTYPACK numeric(15, 5) NOT NULL, -- mno�stv� v balen�(p�epo�tov� koeficent)
	QTYPACKMJ varchar (5) NULL, --m�rn� jednotka balen�,
	TIMEPREP real NOT NULL, -- p��pravn� �as v minutach,
	TIMEUNIT real NOT NULL, -- jednotkov� �as v minutach,
	DtProdT tinyint NOT NULL, -- sledovat dat.vyr.,
	DtProdL smallint NOT NULL, -- rozsah p. dat.v�r.,
	SerNumT tinyint NOT NULL, -- sledovat SN,
	SerNumL smallint NOT NULL, -- rozsah p. SN,
	VerT tinyint NOT NULL, -- sledovat verzi,
	VerL smallint NOT NULL, -- rozsah p. verze,
	TermID tinyint NOT NULL, -- p��znak p�evzet�,
	LSTMod timestamp NOT NULL, -- �as.raz�tko posl. modifi.,
	DEX_ROW_ID IDENTITY NOT NULL,
CONSTRAINT PK_CZPRO_VPP PRIMARY KEY
(
 SOPNUMBE,
 ITEMNMBR,
 CountEntries
)
)

#

CREATE TABLE Production(
	CountEntries int NOT NULL, -- ��slo d�vky,
	SOPNUMBE varchar(17) NULL, -- zak�zka,
	ITEMNMBR varchar (31) NOT NULL, -- ID polo�ky,
	ITEMTYPE varchar (11) DEFAULT '',-- typ polo�ky,
	ITEMMJ varchar (5) NULL, -- m�rn� jednotka polo�ky
	ORD int NOT NULL, --po�ad� polo�ky (operace),
	TIMEPREP real NOT NULL, -- p��pravn� �as v minutach,
	TIMEUNIT real NOT NULL, -- jednotkov� �as v minutach,
	TIMESTART timestamp NULL, -- start �as zahajeni operace,
	TIMESTOP timestamp NOT NULL, -- stop �as ukonceni operace,
	TIMECOR real NOT NULL, -- korekce �asu v minutach,
	TIMECRID int NULL, -- ID korekce �asu,
	id IDENTITY NOT NULL, -- ID ud�losti,
	loginid varchar(10) NOT NULL, -- id u�ivatele (smeny). uzivatel, ktery prihlasil smenu,
	machineid varchar(16) NOT NULL, -- id stroje,
	dateeve timestamp NOT NULL, -- datum a �as,
	qty numeric(15, 5) NOT NULL, -- po�et kus� zadan� u�iv.,
	qtyReal numeric(15, 5) NOT NULL, -- po�et kus� sejmuto,
	QTYPACK numeric(15, 5) NOT NULL, -- mno�stv� v balen�(p�epo�tov� koeficent)
	QTYPACKMJ varchar (5) NULL, --m�rn� jednotka balen�,
	description varchar(128) NULL, -- popis,
	BarcodeP varchar (31) NOT NULL, -- ��rov� k�d polo�ky,
	UserID  varchar (10) NOT NULL, -- ID prac. kter� provedl operaci,
	TermID tinyint NOT NULL, --ID term, ktery zaznamenal provedeni operace,
	ISOK   timestamp NULL, -- �as. p�evzet� do IS,
	GUID uniqueidentifier not null, --jedinecna idetifikace zaznamu, slouzi pro update do db, v pripade vicenasobneho prenosu
CONSTRAINT PK_Events PRIMARY KEY  
(
	id 
)
)

#

CREATE TABLE UserEvents(
	id IDENTITY NOT NULL, -- ID u�ivatele
	loginid varchar(10) NOT NULL, -- id smeny (uzivatel, ktery prihlasil smenu)
	machineid varchar(16) NULL, -- machineid
	dateeve timestamp NOT NULL, -- datum a �as ud�losti
	statusid varchar(10) NOT NULL, -- status id
	UserID  varchar (10) NOT NULL, -- ID pracovnika, ke kteremu se udalost vaze,
	TermID tinyint NOT NULL, --ID term, ktery zaznamenal vlozeni udalosti,
	REZ1 varchar (20) NULL, --Dop�uj�c� �daj ud�losti obsluhy (nap�. �.v�robn�ho p��kazu)
	GUID varchar(38) not null, --jedinecna idetifikace zaznamu, slouzi pro update do db, v pripade vicenasobneho prenosu
 CONSTRAINT PK_UserEvents PRIMARY KEY 
(
	id 
)
)

#

CREATE TABLE Logins(
	id varchar(10) NOT NULL, -- ID osoby (�K)
	firstname varchar(20) NOT NULL, -- k�estn� jm�no
	surname varchar(50) NOT NULL, -- p��jmen�
	psswd varchar(10) NOT NULL, -- heslo
 CONSTRAINT PK_Logins PRIMARY KEY 
(
	id 
)
)

#

CREATE TABLE Machines(
	id varchar(16) NOT NULL, -- ID stroje
	name varchar(20) NOT NULL, -- jm�no stroje
	description varchar(50) NOT NULL, -- popis
 CONSTRAINT PK_Machines PRIMARY KEY 
(
	id 
)
)

#

CREATE TABLE StatusTypes(
	statusid varchar(10) NOT NULL, -- ID
	statusdesc varchar(100) NULL, -- popis
	--statustype varchar (1) NULL DEFAULT (''), -- type statusu udalosti ()
 CONSTRAINT PK_StatusTypes PRIMARY KEY 
(
	statusid 
)
)

#

CREATE TABLE Corrects(
	id int NOT NULL, -- ID korekce
	"desc" varchar(10) NOT NULL, -- popis korekce
	TMFrom real DEFAULT 0, -- minimalni doba trvani korekce operace(je-li NULL, pak min=0),
	TMTo real NULL, -- maximalni doba trvani korekce operace(je-li NULL, pak neni omezeno),
CONSTRAINT PK_correct PRIMARY KEY  
(
	id
)
)

#

CREATE VIEW ProductionSum_View
AS
SELECT CountEntries, SOPNUMBE, ITEMNMBR, SUM(qty) AS QTYODVEDENO, Count(*) AS CNTODVEDENO --, MAX(dateeve) as LSTMod
FROM   Production
GROUP BY CountEntries, SOPNUMBE, ITEMNMBR

#

CREATE VIEW CZPRO_VPP_View
AS
SELECT    
	vpp.CountEntries, 
	vpp.SOPNUMBE, 
	vpp.ITEMNMBR, 
	vpp.ITEMTYPE, 
	vpp.ITEMDESC, 
	vpp.VNDDOCNMP, 
	vpp.VNDITNUM, 
	vpp.ORD, 
	vpp.BarcodeP, 
	vpp.LOCNCODE, 
	vpp.QTYSHPPD, 
	vpp.QTYPACK, 
	vpp.TIMEPREP, 
	vpp.TIMEUNIT, 
	vpp.DtProdT, 
	vpp.DtProdL, 
	vpp.SerNumT, 
	vpp.SerNumL, 
	vpp.VerT, 
	vpp.VerL, 
	vpp.TermID, 
	vpp.LSTMod, --psum.LSTMod, 
	vpp.DEX_ROW_ID, 
	vpp.QTYDOKON + isNull(psum.QTYODVEDENO, 0) AS QTYODVEDENO, --Pocet kusu odvedenych automaticky terminaly a pripadnym rucnim odvodem ze systemu
	isNull(psum.CNTODVEDENO, 0) AS CNTODVEDENO	--Slouzi k informaci, zda zapocitat pripravny cas do dalsiho vystupu(>0 => nezapocitat pripravny cas)
FROM         
	CZPRO_VPP AS vpp 
LEFT OUTER JOIN ProductionSum_View AS psum ON psum.CountEntries = vpp.CountEntries and psum.SOPNUMBE = vpp.SOPNUMBE AND psum.ITEMNMBR = vpp.ITEMNMBR

