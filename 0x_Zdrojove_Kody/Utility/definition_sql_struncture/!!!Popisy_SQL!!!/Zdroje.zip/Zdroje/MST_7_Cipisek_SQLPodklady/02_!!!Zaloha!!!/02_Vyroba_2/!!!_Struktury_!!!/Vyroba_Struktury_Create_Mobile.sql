DROP TABLE CZPRO_VPH;
DROP TABLE CZPRO_VPP;
DROP TABLE CORRECTS;
DROP TABLE LOGINS;
DROP TABLE MACHINES;
DROP TABLE PRODUCTION;
DROP TABLE STATUSTYPES;
DROP TABLE USEREVENTS;

CREATE TABLE CZPRO_VPH (
	CountEntries int NOT NULL DEFAULT ('1'), --��slo d�vky, 
	SOPNUMBE nvarchar (17) NOT NULL, --��slo v�r.zak�zky,
	SOPTYPE nvarchar (11) NOT NULL DEFAULT (''), --typ zak�zky,
	SOPDESC nvarchar (51) NULL, -- popis zak�zky,
	VNDDOCNMH nvarchar (21) NULL, -- ��slo objednatele,
	BarcodeH nvarchar (31) NOT NULL, -- ��r. k�d zak�zky,
	LOCNCODE nvarchar (11) NULL, --lokace,
	DateProd smallint NOT NULL, --o�ek. Datum v�roby,
	Rez1 nvarchar(11) NOT NULL, --rezerva 1,
	Rez2 nvarchar(11) NOT NULL, --rezerva 2,
	TermID tinyint NOT NULL, --ID term. � posl. na�ten� dat,
	LSTMod datetime NOT NULL, --�as.raz�tko posl. modifi.,
	DEX_ROW_ID int IDENTITY (1, 1) NOT NULL ,
CONSTRAINT PK_CZPRO_VPH PRIMARY KEY
(
 SOPNUMBE, CountEntries 
)
)
;

CREATE NONCLUSTERED INDEX IX_CZPRO_VPH ON CZPRO_VPH 
(
	BarcodeH ASC
);
			


CREATE TABLE CZPRO_VPP (
	CountEntries int NOT NULL DEFAULT ('1'), -- ��slo d�vky,
	SOPNUMBE nvarchar (17) NOT NULL, -- ��slo v�r.zak�zky,
	ITEMNMBR nvarchar (31) NOT NULL, -- ID polo�ky,
	ITEMTYPE nvarchar (11) NOT NULL DEFAULT (''),-- typ polo�ky,
	ITEMDESC nvarchar (51) NULL, -- popis polo�ky,
	ITEMMJ nvarchar (5) NULL, -- m�rn� jednotka polo�ky,
	VNDDOCNMP nvarchar (21) NULL, -- ��slo dok. extern�,
	VNDITNUM nvarchar (31) NULL, --��slo polo�ky extern�,
	ORD int NOT NULL DEFAULT (0), --po�ad� polo�ky (operace),
	BarcodeP nvarchar (31) NOT NULL, --��rov� k�d polo�ky,
	LOCNCODE nvarchar (11) NULL, -- lokace,
	QTYSHPPD numeric(19, 5) NOT NULL, -- mno�stv�,
	QTYPACK numeric(19, 5) NOT NULL, -- mno�stv� v balen�(p�epo�tov� koeficent),
	QTYPACKMJ nvarchar (5) NULL, --m�rn� jednotka balen�,
	TIMEPREP real NOT NULL, -- p��pravn� �as v minutach,
	TIMEUNIT real NOT NULL, -- jednotkov� �as v minutach,
	DtProdT tinyint NOT NULL, -- sledovat dat.vyr.,
	DtProdL smallint NOT NULL, -- rozsah p. dat.v�r.,
	SerNumT tinyint NOT NULL, -- sledovat SN,
	SerNumL smallint NOT NULL, -- rozsah p. SN,
	VerT tinyint NOT NULL, -- sledovat verzi,
	VerL smallint NOT NULL, -- rozsah p. verze,
	TermID tinyint NOT NULL, -- p��znak p�evzet�,
	LSTMod datetime NOT NULL, -- �as.raz�tko posl. modifi.,
	DEX_ROW_ID int IDENTITY (1, 1) NOT NULL,
	QTYODVEDENO numeric(19, 5) NOT NULL DEFAULT(0), --Pocet kusu odvedenych automaticky terminaly a pripadnym rucnim odvodem ze systemu
	CNTODVEDENO	numeric(19, 5) NOT NULL DEFAULT(0), --Slouzi k informaci, zda zapocitat pripravny cas do dalsiho vystupu(>0 => nezapocitat pripravny cas)
CONSTRAINT PK_CZPRO_VPP PRIMARY KEY
(
 SOPNUMBE ,
 ITEMNMBR ,
 CountEntries
)
) 
;

CREATE NONCLUSTERED INDEX IX_CZPRO_VPP ON CZPRO_VPP
(
	BarcodeP ASC
);

 
--Vystupni data


CREATE TABLE Production(
	CountEntries int NOT NULL, -- ��slo d�vky,
	SOPNUMBE nvarchar(17) NULL, -- zak�zka,
	ITEMNMBR nvarchar (31) NOT NULL, -- ID polo�ky,
	ITEMTYPE nvarchar (11) NOT NULL DEFAULT (''),-- typ polo�ky,
	ITEMMJ nvarchar (5) NULL, -- m�rn� jednotka polo�ky,
	ORD int NOT NULL, --po�ad� polo�ky (operace),
	TIMEPREP real NOT NULL, -- p��pravn� �as v minutach,
	TIMEUNIT real NOT NULL, -- jednotkov� �as v minutach,
	TIMESTART datetime NULL, -- start �as zahajeni operace,
	TIMESTOP datetime NOT NULL, -- stop �as ukonceni operace,
	TIMECOR real NOT NULL, -- korekce �asu v minutach,
	TIMECRID int NULL, -- ID korekce �asu,
	id int IDENTITY(1,1) NOT NULL, -- ID ud�losti,
	loginid nvarchar(10) NOT NULL, -- id u�ivatele (smeny). uzivatel, ktery prihlasil smenu,
	machineid nvarchar(16) NOT NULL, -- id stroje,
	dateeve datetime NOT NULL, -- datum a �as,
	qty numeric(19, 5) NOT NULL, -- po�et kus� zadan� u�iv.,
	qtyReal numeric(19, 5) NOT NULL, -- po�et kus� sejmuto,
	QTYPACK numeric(19, 5) NOT NULL, -- mno�stv� v balen�(p�epo�tov� koeficent),
	QTYPACKMJ nvarchar (5) NULL, --m�rn� jednotka balen�,
	description ntext NULL, -- popis,
	BarcodeP nvarchar (31) NOT NULL, -- ��rov� k�d polo�ky,
	UserID  nvarchar (10) NOT NULL, -- ID prac. kter� provedl operaci,
	TermID tinyint NOT NULL, --ID term, ktery zaznamenal provedeni operace,
	ISOK   datetime NULL, -- �as. p�evzet� do IS,
	GUID uniqueidentifier not null, --jedinecna idetifikace zaznamu, slouzi pro update do db, v pripade vicenasobneho prenosu
CONSTRAINT PK_PRODUCTION PRIMARY KEY  
(
	id 
)
)
;

CREATE NONCLUSTERED INDEX IX_PRODUCTION ON PRODUCTION
(
	SOPNUMBE,
	ITEMNMBR
);



CREATE TABLE UserEvents(
	id int IDENTITY(1,1) NOT NULL, -- ID u�ivatele
	loginid nvarchar(10) NOT NULL, -- id smeny (uzivatel, ktery prihlasil smenu)
	machineid nvarchar(16) NULL, -- machineid
	dateeve datetime NOT NULL, -- datum a �as ud�losti
	statusid nvarchar(10) NOT NULL, -- status id
	UserID  nvarchar (10) NOT NULL, -- ID pracovnika, ke kteremu se udalost vaze,
	TermID tinyint NOT NULL, --ID term, ktery zaznamenal vlozeni udalosti,
	REZ1 nvarchar (20) NULL, --Dopl�uj�c� �daj ud�losti obsluhy (nap�. �.v�robn�ho p��kazu)
	GUID uniqueidentifier not null, --jedinecna idetifikace zaznamu, slouzi pro update do db, v pripade vicenasobneho prenosu
 CONSTRAINT PK_UserEvents PRIMARY KEY  
(
	id 
)
) 
;

--��seln�ky:


CREATE TABLE Logins(
	id nvarchar(10) NOT NULL, -- ID osoby (�K)
	firstname nvarchar(20) NOT NULL, -- k�estn� jm�no
	surname nvarchar(50) NOT NULL, -- p��jmen�
	psswd nvarchar(10) NOT NULL, -- heslo
 CONSTRAINT PK_Logins PRIMARY KEY  
(
	id 
)
) 
;


CREATE TABLE Machines(
	id nvarchar(16) NOT NULL, -- ID stroje
	name nvarchar(20) NOT NULL, -- jm�no stroje
	description nvarchar(50) NOT NULL, -- popis
 CONSTRAINT PK_Machines PRIMARY KEY  
(
	id 
)
) 
;


CREATE TABLE StatusTypes(
	statusid nvarchar(10) NOT NULL, -- ID
	statusdesc nvarchar(100) NULL, -- popis
	--statustype nvarchar (1) NULL DEFAULT (''), -- type statusu udalosti ()
 CONSTRAINT PK_StatusTypes PRIMARY KEY  
(
	statusid 
)
) 
;


CREATE TABLE Corrects(
	id int NOT NULL, -- ID korekce
	[desc] nvarchar(10) NOT NULL, -- popis korekce
	TMFrom real NULL DEFAULT (0), -- minimalni doba trvani korekce operace(je-li NULL, pak min=0),
	TMTo real NULL, -- maximalni doba trvani korekce operace(je-li NULL, pak neni omezeno),
CONSTRAINT PK_correct PRIMARY KEY  
(
	id 
)
) 
;

