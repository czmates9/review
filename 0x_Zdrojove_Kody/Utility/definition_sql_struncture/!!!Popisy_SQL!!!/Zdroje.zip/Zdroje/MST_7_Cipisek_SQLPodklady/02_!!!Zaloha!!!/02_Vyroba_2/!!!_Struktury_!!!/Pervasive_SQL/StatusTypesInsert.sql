INSERT into StatusTypes (statusid, statusdesc) VALUES ('1', 'Smena login')#
INSERT into StatusTypes (statusid, statusdesc) VALUES ('2', 'Smena logout')#
INSERT into StatusTypes (statusid, statusdesc) VALUES ('3', 'Prihlaseni pracovn�ka')#
INSERT into StatusTypes (statusid, statusdesc) VALUES ('4', 'Odhlaseni pracovn�ka')#
INSERT into StatusTypes (statusid, statusdesc) VALUES ('5', 'Tisk Etiketa')#
