/* tabulka uzivatelu */
CREATE TABLE FASK_CONS_Logins
(
	id varchar(10) primary key NOT NULL, -- ID uzivatele 
	firstname varchar(20) NOT NULL, -- k�estn� jm�no
	surname varchar(50) NOT NULL, -- p��jmen�
	psswd varchar(10) NOT NULL -- heslo
)

/* pristupova prava do konzole ... nyni se vyuziva pouze ADM pro pristup do konfigurace aplikace */
CREATE TABLE FASK_CONS_LoginsAuth
(
	id varchar(10) primary key NOT NULL, -- ID osoby
	ADM smallint DEFAULT 0 NOT NULL,	-- administrator
	opr_select smallint,	-- u�ivatel m� opr�vn�n� zobrazovat z�znamy
	opr_insert smallint,	-- u�ivatel m� opr�vn�n� vytv��et nov� z�znamy
	opr_edit smallint,	-- u�ivatel m� opr�vn�n� upravovat z�znamy
	opr_delete smallint	-- u�ivatel m� opr�vn�n� zobrazovat data
)