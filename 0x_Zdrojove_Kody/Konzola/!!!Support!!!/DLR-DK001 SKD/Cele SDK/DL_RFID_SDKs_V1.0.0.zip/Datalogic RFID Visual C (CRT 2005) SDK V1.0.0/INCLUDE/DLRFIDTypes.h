

#ifndef _WINSOCK2API_
#include <winsock2.h>
#endif

#define MAX_ID_LENGTH							64
#define XPC_LENGTH								4
#define PC_LENGTH								2
#define MAX_ARG_SIZE							50
#define MAX_CLIENT_SUPPORTED					20
#define MAX_READPOINT_NAME						5
#define MAX_LOGICAL_SOURCE_NAME					30
#define MAX_TID_SIZE							64
#define MAX_FWREL_LENGTH						201	//stringa che rappresenta il fw release (SOLO solo nella libreria C)
#define MAX_SWREL_LENGTH						6	//stringa che rappresenta il sw release	(SOLO nella libreria C)
#define MAX_MODEL_LENGTH						10	//stringa che rappresenta il modello del reader
#define MAX_SERIAL_LENGTH						100 //stringa che rappresenta il numero seriale del reader
#define evUnknown                               0
#define evGlimpsed                              1
#define EvNew                                   2
#define evObserved                              3
#define evLost                                  4
#define evPurged                                5
#define TWOBITE									2
#define TIMELENGTH								19

typedef int DLRFIDHandle;

/*
        Error codes
*/


typedef enum {
	// -------------------- GENERAL ERROR CODES 
	DLRFID_StatusOK					       =  0,  // Operation completed successfully 
    DLRFID_TooManyClientsError			   = -1,  // To many clients open 
	DLRFID_PortError					       = -2,  // Error on selected port
	DLRFID_LibraryError				       = -3,  // Can't open winsock 2.2 Library
	DLRFID_SocketError				       = -4,  // Can't open socket
	DLRFID_InvalidHandleError				   = -5,   // Invalid Handle
	DLRFID_OutOfMemoryError			       = -6,
	DLRFID_CommunicationError			       = -7,
	DLRFID_CommunicationTimeOut		       = -8,
	DLRFID_ChannelExist				       = -9,
	DLRFID_GenericError				       = -10, // Generic error
	DLRFID_InvalidParam				       = -11,  // Invalid parameter error
	DLRFID_ReaderBusy						   = -12,
	DLRFID_EOF							   = -13,	
	//--------------------- FIRMWARE ERROR CODES (communication specific)
	DLRFID_ChanNameExistsError			   = 100,
	DLRFID_AddrAlreadyInUseError			   = 101,
	DLRFID_UnknowError					   = 102,
	DLRFID_BadChannelError				   = 103,
	DLRFID_InvalidSourceNamError			   = 104,
	DLRFID_InvalidChannelNameError		   = 105,
	DLRFID_TooManyChannelError			   = 106,
	DLRFID_TooManySourceError				   = 107,
	DLRFID_SourceNotInChannelError		   = 109,
	DLRFID_BadTimerValueError				   = 110,
	DLRFID_TriggerNameExistError			   = 111,
	DLRFID_TooManyTriggerError			   = 112,
	DLRFID_BadTriggerError				   = 113,
	DLRFID_BadAddressError				   = 114,
	DLRFID_InvalidProtocolError			   = 115,
	DLRFID_BadPortAddressError			   = 116,
	DLRFID_CannotConnectToServerError		   = 117,
	DLRFID_InvalidTriggerNameError		   = 118,
	DLRFID_InvalidTimeError				   = 119,
	DLRFID_SourceNotFoundError			   = 120,
	DLRFID_TriggerNotFoundError			   = 121,
	DLRFID_ChannelNotFoundError			   = 122,
	DLRFID_BadReadPointError				   = 123,
	DLRFID_ChannelBusyError				   = 124,
	DLRFID_TriggerBusyError				   = 125,
	DLRFID_InternalFilesystemError		   = 126,
	DLRFID_InvalidCommand					   = 127,
	DLRFID_BadParameterValueError			   = 128,
	DLRFID_NotifyServerNotReadyError		   = 129,
	DLRFID_PowerValueOutofRangeError		   = 183,
	DLRFID_InvalidParameterError			   = 200,
	DLRFID_LogicalSourceDisabledError		   = 201,
	DLRFID_TagNotPresentError				   = 202,
	DLRFID_WritingTagError				   = 203,
	DLRFID_ReadingTagError				   = 204,
	DLRFID_BadTagAddressError				   = 205,
	DLRFID_InvalidFunctionError			   = 206,
	DLRFID_SelectUnselectError			   = 207,
	DLRFID_TagLockedError				       = 209,
	DLRFID_UnsupportedError				   = 210,
	DLRFID_PowerError						   = 211,
	DLRFID_NonSpecificError				   = 212,
	DLRFID_KillTagError					   = 213,
	DLRFID_ChannelsFullError				   = 214,
	DLRFID_ErrorMatchReadpoint			   = 215
} DLRFIDErrorCodes;

/*
        Communication ports enum
*/

typedef enum { 
	DLRFID_RS232   = 0,
//	RS485   = 1, Obsolete
	DLRFID_TCP     = 2, 
	DLRFID_USB     = 3 
} DLRFIDPort;

typedef enum {
	DLRFID_ISO18000_6B   = 0,
	DLRFID_EPC_C1G1      = 1,
	DLRFID_ISO18000_6A   = 2,
	DLRFID_EPC_C1G2	   = 3,
	DLRFID_MULTIPROTOCOL = 4,
	DLRFID_EPC119		   = 5
} DLRFIDProtocol;

typedef enum {
        EPC_C1G2_SESSION_S0     = 0,
        EPC_C1G2_SESSION_S1     = 1,
        EPC_C1G2_SESSION_S2     = 2,
        EPC_C1G2_SESSION_S3     = 3,
        EPC_C1G2_TARGET_A       = 0,
        EPC_C1G2_TARGET_B       = 1,
        EPC_C1G2_SELECTED_YES   = 3,
        EPC_C1G2_SELECTED_NO    = 2,
        EPC_C1G2_ALL_SELECTED   = 0,
        ISO18006B_DESB_ON       = 1,
        ISO18006B_DESB_OFF		= 0,
}DLRFIDLogicalSourceConstants ;

typedef enum { 
	RESERVED   = 0,
	EPC        = 1,
	TID        = 2, 
	USER       = 3 
} DLRFIDMemBanks;

/*
        Tag identification struct: for each tag it contains 
        the ID, the length of the ID and the antenna used to 
        identify the tag.
*/

typedef struct {
    byte                ID[MAX_ID_LENGTH];
    short               Length;
    char				LogicalSource[MAX_LOGICAL_SOURCE_NAME];
	struct timeval		TimeStamp;
	char				ReadPoint[MAX_READPOINT_NAME];
	DLRFIDProtocol	Type;
	short				RSSI;
	byte				TID[MAX_TID_SIZE];
	short				TIDLen;
	byte				XPC[XPC_LENGTH];
	byte				PC[PC_LENGTH];
} DLRFIDTag;


typedef struct {
    byte                ID[MAX_ID_LENGTH];
	short               Length;
    int					EvtType;
	DLRFIDProtocol	Type;
    char				LogicalSource[MAX_LOGICAL_SOURCE_NAME];
	struct timeval		TimeStamp;
	short				RSSI;
	char				ReadPoint[MAX_READPOINT_NAME];
	byte				TID[MAX_TID_SIZE];
	short				TIDLen;
	byte				XPC[XPC_LENGTH];
	byte				PC[PC_LENGTH];
} DLRFIDNotify;


typedef DLRFIDErrorCodes (__stdcall *DLRFID_INVENTORY_CALLBACK)(const DLRFIDNotify* Tags, const int Size);

typedef enum {
	STATUS_GOOD		= 0,
	STATUS_POOR		= 1,
	STATUS_BAD		= 2
} DLRFIDReadPointStatus;

typedef enum {
        DLRS232_Parity_None      = 0,
        DLRS232_Parity_Odd       = 1,
        DLRS232_Parity_Even      = 2     
} DLRFID_RS232_Parity;

typedef enum {

        DLRFID_RS232_FlowControl_XonXoff    = 2,
        DLRFID_RS232_FlowControl_Hardware   = 1,
        DLRFID_RS232_FlowControl_None       = 0
}DLRFID_RS232_FlowControl;

/*obsolete*/
typedef enum {
		SEL_EQUAL			=	0x00,    /* comparazione di uguaglianza */
		SEL_NOT_EQUAL		=	0x01,    /* comparazione di disuguaglianza */
		SEL_GREATER_THAN	=	0x02,    /* comparazione di maggioranza */
		SEL_LOWER_THAN		=	0x03,    /* comparazione di maggioranza */
		UNS_EQUAL			=	0x04,    /* comparazione di uguaglianza */
		UNS_NOT_EQUAL		=	0x05,    /* comparazione di disuguaglianza */
		UNS_GREATER_THAN	=	0x06,    /* comparazione di maggioranza */
		UNS_LOWER_THAN		=	0x07    /* comparazione di maggioranza */
} DLRFID_SelUnsel_Op;

/*obsolete*/
typedef enum {
		CONFIG_READCYCLE			= 0,
		CONFIG_OBSERVEDTHRESHOLD	= 1,
		CONFIG_LOSTTHRESHOLD		= 2,
		CONFIG_G2_Q_VALUE			= 3,
		CONFIG_G2_SESSION			= 4,
		CONFIG_G2_TARGET			= 5,
		CONFIG_G2_SELECTED			= 6,
		CONFIG_ISO18006B_DESB		= 7,
		CONFIG_TID_LENGTH			= 13
} DLRFID_SOURCE_Parameter;

typedef enum {
		READCYCLE_MODE				= 0,
		TIME_MODE					= 1,
		NOEVENT_MODE				= 2 
} DLRFID_EventMode;

typedef enum {
	RSSI					=1,
	FRAMED					=2,
	CONTINUOS				=4,
	COMPACT					=8,
	TID_READING				=16,
	EVENT_TRIGGER			=32,
	XPC						=64,
	PC						=256
} DLRFID_InventoryFlag;

typedef enum {
		RFID_TFTP					= 1
} DLRFID_FWUpgradeType;

/*obsolete. USe DLRFID_EventInventoryParams instead.*/
typedef struct {
	char						*SourceName; 
	char						*Mask;
	unsigned char				MaskLength;
	unsigned char				Position;
	DLRFID_INVENTORY_CALLBACK	pCallBack;
	short						flag;
} DLRFID_ExtendedInventoryParams;

typedef struct {
	char						*SourceName; 
	char						*Mask;
	unsigned char				MaskLength;
	unsigned char				Position;
	DLRFID_INVENTORY_CALLBACK	pCallBack;
	short						flag;
} DLRFID_EventInventoryParams;

typedef struct {
    BOOL				ADError_i;
	unsigned int		RangeLimit_i;
	unsigned int		SensorValue_i;
} DLRFID_IDSTagData;

typedef enum{
	DSB_ASK_FM0_TX10RX40	=1,
	DSB_ASK_FM0_TX40RX40	=2,
	DSB_ASK_FM0_TX40RX160	=3,
	DSB_ASK_FM0_TX160RX400	=4,
	DSB_ASK_M2_TX40RX160	=5,
	PR_ASK_M4_TX40RX250		=6,
	PR_ASK_M4_TX40RX300		=7,
	PR_ASK_M2_TX40RX250		=8,
	//PR_ASK_FM0_TX40RX40,
    /// DSB-ASK transmission modulation, Miller (M=4) return link encoding, 
    /// 40 Kbit in transmission, 256 Kbit in reception.
    DSB_ASK_M4_TX40RX256	=10,
    //PR_ASK_M4_TX40RX320
    //PR_ASK_FM0_TX40RX640
    //PR_ASK_M4_TX80RX320
    //PR_ASK_M4_TX40RX256
}DLRFID_Bitrate;

typedef enum{

	ETSI_302208		=0,
	ETSI_300220		=1,
	FCC_US			=2,
	MALAYSIA		=3,
	JAPAN			=4,
	KOREA			=5,
	AUSTRALIA		=6,
	CHINA			=7,
	TAIWAN			=8,
	SINGAPORE		=9,
	BRAZIL			=10,
	JAPAN_STD_T106	= 11,
	JAPAN_STD_T107	= 12,
	PERU			= 13,
	SOUTH_AFRICA	= 14

}DLRFIDRegulations;

typedef enum{

	RPCMATCHRFALG =14

}DLRFIDMatchingParams;

/*Obsolete defines*/
#define	ETSI302208 0
#define	ETSI300220 1
#define	FCCUS      2
#define	MALAYSIA   3
#define	JAPAN      4
#define	KOREA      5
#define	AUSTRALIA  6
#define CHINA      7
#define TAIWAN     8
#define SINGAPORE  9
