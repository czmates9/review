#include <windows.h>
#include <winioctl.h>


#ifdef DLRFID

#define DLRFIDlib_API __declspec(dllexport) // DLRFIDErrorCodes __stdcall

#else

#define DLRFIDlib_API __declspec(dllimport) // DLRFIDErrorCodes __stdcall

#endif