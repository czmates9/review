/*
    -----------------------------------------------------------------------------

                   --- DataLogic Automation SpA - Computing Systems Division ---

    -----------------------------------------------------------------------------
*/
#define deprecate_msg(message) __declspec(deprecated(message))  

#ifndef __DLRFIDLIB_H
#define __DLRFIDLIB_H
#define byte unsigned char

#include "DLRFIDoslib.h"
#include "DLRFIDTypes.h"

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus


/*
        DLRFID_Init
        -----------------------------------------------------------------------------
        Parameters:
            [in]  Port      : Communication port (see DLRFIDPort enum).
            [in]  Address   : Communication address (i.e.: "COM1" for RS232,
                              "USB0" for USB of IP address for TCP/IP etc.)
			[in]  Protocol  : 
            [out] Handle    : The handle that identifies the device.
        -----------------------------------------------------------------------------
        Returns:
            An error code about the execution of the function.
        -----------------------------------------------------------------------------
        Description:
            The function generates an opaque handle to identify a module
            attached to the PC.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Init (DLRFIDPort Port, char *Address, DLRFIDHandle *Handle, DLRFIDProtocol *Protocol);

/*
    DLRFID_End
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        Notifies the library the end of work and free the allocated
        resources.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_End(DLRFIDHandle Handle);

/*
    DLRFID_GetSWRelease
    -----------------------------------------------------------------------------
    Parameters:
        [out] SwRel : Returns the software release of the library.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        Permits to read the software release of the library.
*/
DLRFIDlib_API  deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_GetSWRelease(char *SwRel);

/*
    DLRFID_GetFWRelease.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [out] FWRel : Returns the firmware release of the device.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        Permits to read the firmware release loaded into the device.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_GetFWRelease(DLRFIDHandle Handle, char *FWRel);

/*
    DLRFID_GetFirmwareRelease.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [out] FWRel : Returns the firmware release of the device.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        Permits to read the firmware release loaded into the device.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetFirmwareRelease(DLRFIDHandle Handle, char *FWRel);


/*
    DLRFID_Inventory.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  LogicalSourceName : The name that identify the Logical Source
        [out] Tags  : Returns an array containing the tags read.
        [out] TagsNo    : Returns the number of tags in the array.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function returns all the IDs of the tags under the reader field
        using all the available antennae. The Tags array contains The IDs
        together with other information related to the single ID such as the
        antenna under which is the ID and the format of the ID itself (see
        DLRFIDTag struct for the details).
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_Inventory(DLRFIDHandle Handle, char *LogicalSourceName, DLRFIDTag **Tags, int *TagsNo);

/*
    DLRFID_SetPower.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
                [in]  Power     : RF field power expressed in mW.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to set the RF field power relative to the antenna
        socket.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SetPower(DLRFIDHandle Handle, unsigned int Power);

/*
    DLRFID_Read (DEPRECATED)
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  ID        : The tag ID.
        [in]  Address   : The address of the memory to read.
        [in]  Length    : The number of bytes to read.
        [out] Data      : The data read from the tag's memory.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to read Length bytes from the memory of a
        specific tag identified by the ID (regardless of its status) at the
        address specified by Address.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer supported.Use ReadTagData instead.") DLRFIDErrorCodes __stdcall
DLRFID_Read(DLRFIDHandle Handle, DLRFIDTag *ID, int Address, int Length, void *Data);

/*
    DLRFID_ReadTagData
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  ID        : The tag.
        [in]  Address   : The address of the memory to read.
        [in]  Length    : The number of bytes to read.
        [out] Data      : The data read from the tag's memory.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to read Length bytes from the memory of a
        specific tag identified by the ID (regardless of its status) at the
        address specified by Address.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_ReadTagData(DLRFIDHandle Handle, DLRFIDTag *ID, int Address, int Length, void *Data);

/*
    DLRFID_Write (DEPRECATED)
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  ID        : The tag ID.
        [in]  Address   : The address of the memory to write.
        [in]  Length    : The number of bytes to write.
        [in]  Data      : The data to write in the tag's memory.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to write Length bytes to the memory of a
        specific tag identified by the ID (regardless of its status) at the
        address specified by Address.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer supported.Use WriteTagData instead.") DLRFIDErrorCodes __stdcall
DLRFID_Write(DLRFIDHandle Handle, DLRFIDTag *ID, int Address, int Length, void *Data);

/*
    DLRFID_Write (DEPRECATED)
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  Tag        : The tag ID.
        [in]  Address   : The address of the memory to write.
        [in]  Length    : The number of bytes to write.
        [in]  Data      : The data to write in the tag's memory.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to write Length bytes to the memory of a
        specific tag identified by the ID (regardless of its status) at the
        address specified by Address.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_WriteTagData(DLRFIDHandle Handle, DLRFIDTag *Tag, int Address, int Length, void *Data);


/*
    DLRFID_Lock (DEPRECATED)
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  ID        : The tag ID.
        [in]  Address   : The address of the tag's memory.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to lockthe memory of a
        specific tag identified by the ID at the address specified by Address.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer supported.Use LockTag_ISO18006B instead.") DLRFIDErrorCodes __stdcall
DLRFID_Lock(DLRFIDHandle Handle, DLRFIDTag *ID, short Address);

/*
    DLRFID_Lock (DEPRECATED)
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  ID        : The tag ID.
        [in]  Address   : The address of the tag's memory.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to lockthe memory of a
        specific tag identified by the ID at the address specified by Address.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_LockTag_ISO180006B(DLRFIDHandle Handle, DLRFIDTag *ID, short Address);


/*
    DLRFID_SetModulation. (DEPRECATED)
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  TxRxCfg   : Modulation setting.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to control to choose the modulation (the bit
        rate of the transmission and receive).
*/
DLRFIDlib_API deprecate_msg("Deprecated function.Use DLRFID_SetBitRate instead.") DLRFIDErrorCodes  __stdcall
DLRFID_SetModulation(DLRFIDHandle Handle, unsigned short TxRxCfg);
/*
    DLRFID_SetBitrate.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  br   : Modulation setting.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to control to choose the modulation (the bit
        rate of the transmission and receive).
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.Use SetBitRate instead.")DLRFIDErrorCodes  __stdcall 
DLRFID_SetBitrate(DLRFIDHandle handle, DLRFID_Bitrate br);

/*
    DLRFID_SetBitRate.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  BitRate		: link-profile setting.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to control to choose the modulation (the bit
        rate of the transmission and receive).
*/
DLRFIDlib_API DLRFIDErrorCodes  __stdcall 
DLRFID_SetBitRate(DLRFIDHandle handle, DLRFID_Bitrate Bitrate);

/*
    DLRFID_GetModulation.(DEPRECATED)
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [out]  TxRxCfg  : Modulation setting.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to retrieve the modulation (the bit
        rate of the transmission and receive).
*/
DLRFIDlib_API deprecate_msg("Deprecated Function.Use DLRFID_GetBitRate instead.") DLRFIDErrorCodes  __stdcall
DLRFID_GetModulation(DLRFIDHandle handle, unsigned short *TxRx);

/*
    DLRFID_GetBitrate.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [out]  Bitrate  : Modulation setting.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to retrieve the modulation (the bit
        rate of the transmission and receive).
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.Use GetBitRate instead.") DLRFIDErrorCodes __stdcall
DLRFID_GetBitrate(DLRFIDHandle handle, DLRFID_Bitrate *Bitrate);

/*
    DLRFID_GetBitRate.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [out]  Bitrate  : Modulation setting.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to retrieve the modulation (the bit
        rate of the transmission and receive).
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetBitRate(DLRFIDHandle handle, DLRFID_Bitrate *Bitrate);

/*
    DLRFID_PrintScreen
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  Text  : An arbitrary ASCII string.
		[in]  TerminalType	: RFU parameter, default is 0 (VT100).
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        Print ASCII text on the reader's screen (if available).
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_PrintScreen(DLRFIDHandle handle, char * Text, unsigned short TerminalType);


/*
    DLRFID_AllocateChannel.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  ChannelName    : The Name of the Channel.
        [in]  ChannelAddress : The Address of the Channel.
                                in the form [TCP|USB|RS232]://[ip address:port]
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to allocate a notification Channel.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_AllocateChannel(DLRFIDHandle handle, char *ChannelName, char *ChannelAddress);

/*
    DLRFID_DeallocateChannel.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  ChannelName    : The Name of the Channel.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to Deallocate a Channel.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_DeallocateChannel(DLRFIDHandle handle, char *ChannelName);

/*
    DLRFID_AddSourceToChannel (DEPRECATED).
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  SourceName     : The Name of the Logical Source.
        [in]  ChannelName    : The Address of the Channel.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to add a LogicalSource to a notification Channel.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_AddSourceToChannel(DLRFIDHandle handle, char *SourceName, char *ChannelName);

/*
    DLRFID_RemoveSourceFromChannel.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  SourceName     : The Name of the Logical Source.
        [in]  ChannelName    : The Address of the Channel.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to remove a LogicalSource from a notification Channel.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_RemoveSourceFromChannel(DLRFIDHandle handle, char *SourceName, char *ChannelName);

/*
    DLRFID_AddReadPoint.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  SourceName     : The name of the Logical Source.
        [in]  ReadPoint      : The name of the Read Point.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to add a read point (antenna) to a logical source..
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_AddReadPoint(DLRFIDHandle handle, char *SourceName, char *ReadPoint);

/*
    DLRFID_RemoveReadPoint.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  SourceName     : The name of the Logical Source.
        [in]  ReadPoint      : The name of the Read Point.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to add a read point (antenna) to a logical source.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_RemoveReadPoint(DLRFIDHandle handle, char *SourceName, char *ReadPoint);

/*
    DLRFID_AllocateTrigger.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  TriggerName    : The name of the trigger.
        [in]  TriggerType    : The type of the trigger.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to create a trigger of the specified type.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_AllocateTrigger(DLRFIDHandle handle, char *TriggerName, char *TriggerType);

/*
    DLRFID_DeallocateTrigger.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  TriggerName    : The name of the trigger.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to destroy a trigger.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_DeallocateTrigger(DLRFIDHandle handle, char *TriggerName);

/*
    DLRFID_AddReadTrigger (DEPRECATED).
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  SourceName     : The name of the Logical Source.
        [in]  TriggerName    : The name of the trigger.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to associate a trigger to a source in order to
        start a read cycle.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_AddReadTrigger(DLRFIDHandle handle, char *SourceName, char *TriggerName);

/*
    DLRFID_RemoveReadTrigger.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  SourceName     : The name of the Logical Source.
        [in]  TriggerName    : The name of the trigger.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to remove the read trigger from the logical source.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_RemoveReadTrigger(DLRFIDHandle handle, char *SourceName, char *TriggerName);

/*
    DLRFID_AddNotifyTrigger (DEPRECATED).
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  ChannelName    : The Address of the Channel.
        [in]  TriggerName    : The name of the trigger.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to associate a trigger to a channel in order to
        start a notification.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_AddNotifyTrigger(DLRFIDHandle handle, char *ChannelName, char *TriggerName);

/*
    DLRFID_RemoveNotifyTrigger.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  ChannelName    : The Address of the Channel.
        [in]  TriggerName    : The name of the trigger.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to remove the notification trigger from a channel.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_RemoveNotifyTrigger(DLRFIDHandle handle, char *ChannelName, char *TriggerName);

/*
    DLRFID_GetNotification.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Skt            : The handle to the TCP socket.
        [out] Items          : A list of data items.
        [out] NoItems        : The number of data items in the list..
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to decode data coming from the notification channel.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_GetNotification(SOCKET Skt, DLRFIDNotify **Items, int *NumberItems);

/*
    DLRFID_GetPower.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [out] Power          : The ERP power of the reader.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function returns the value of the ERP power setting in the reader.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetPower(DLRFIDHandle Handle, unsigned int *Power);

/*
    DLRFID_GetBatteryLevel.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [out] Charge         : The percentage of battery's charge level.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function calculates the battery level of the reader expressed in %.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetBatteryLevel(DLRFIDHandle Handle, unsigned int *Charge);


/*
    DLRFID_SetProtocol.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  Protocol       : The tag protocol to be set in the reader.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to change the tag protocol used by the reader.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SetProtocol (DLRFIDHandle Handle, DLRFIDProtocol Protocol);

/*
    DLRFID_GetProtocol.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [out] Protocol       : The tag protocol to be set in the reader.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to know what tag protocol is used by the reader.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetProtocol(DLRFIDHandle Handle, int *Protocol);


  /// <summary>
        ///  MatchReadPointImpedance matches the antenna impedance passed in <para>ReadPoint</para>.
        /// </summary>
        /// <param name="ReadPoint">The antenna to be matched</param>
        /// <param name="MatchParam">A DLRFIDMatchingParams parameters for matching operation.</param>
        /// <param name="MatchParamValue">The value of the <para>MatchParam</para>.</param>
        /// <returns>A real number greater then one,that rapresent the return status of the matching operation</returns>

/*
    DLRFID_MatchReadPointImpedance.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle      : The handle that identifies the device.
		[in]  ReadPoint   : The antenna to be matched.
        [out] Value       : A real number greater then one,that rapresent the return status of the matching operation
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        MatchReadPointImpedance matches the antenna impedance passed in.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_MatchReadPointImpedance(DLRFIDHandle handle, char* ReadPoint, float* Value) ;


/*
    DLRFID_ParametrizedMatchReadPointImpedance.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle          : The handle that identifies the device.
		[in]  ReadPoint       : The antenna to be matched.
		[in]  MatchParam      : A DLRFIDMatchingParams parameters for matching operation.
		[in]  MatchParamValue : The value of the aram</para>.
        [out] Value           : A real number greater then one,that rapresent the return status of the matching operation
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        DLRFID_ParametrizedMatchReadPointImpedance matches the antenna impedance passed in.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_ParametrizedMatchReadPointImpedance(DLRFIDHandle handle, char* ReadPoint, DLRFIDMatchingParams MatchParam, int MatchParamValue, float* Value);




/*
    DLRFID_GetReadPointStatus.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  ReadPoint      : The name of the Read Point.
        [out] Status         : The status of the read point.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to check the status of a read point.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetReadPointStatus(DLRFIDHandle Handle, char *ReadPoint, DLRFIDReadPointStatus *Status);

/*
    DLRFID_MatchReadPointImpedance.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
		[in]  ReadPoint		 : The name of the ReadPoint to apply impedance automatching.
		[out] Status		 : The status of the automatching.
    -----------------------------------------------------------------------------
    Returns:
        A real number greater then one,that rapresent the return status of the matching operation
    -----------------------------------------------------------------------------
    Description:
		The function matches the antenna impedance passed in ReadPoint parameter.
*/

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_MatchReadPointImpedance(DLRFIDHandle Handle, char *ReadPoint, float *Status);

/*
    DLRFID_FlagMatchReadPointImpedance.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
		[in]  ReadPoint		 : The name of the ReadPoint to apply impedance automatching.
		[in]  Flag           : A DLRFIDMatchingParams parameters for matching operation.
		[out] Status		 : The status of the automatching.
    -----------------------------------------------------------------------------
    Returns:
        A real number greater then one,that rapresent the return status of the matching operation
    -----------------------------------------------------------------------------
    Description:
		The function matches the antenna impedance passed in ReadPoint parameter.
		It can receives a flag 
*/

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_FlagMatchReadPointImpedance(DLRFIDHandle Handle, char *ReadPoint, DLRFIDMatchingParams Flag, float *Status);

/*
    DLRFID_GetReadPoints.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
		[out] Antennas		 : The names of the Antenna avalaible on the reader.
		[out] numAnt		 : The number of string in Antennas.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
		The function permits to know the name of the antenna available on the reader.
		Names are formatted according to DL RFID communication protocol.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetReadPoints(DLRFIDHandle Handle, char **Antennas[], int *numAnt);

/*
    DLRFID_GetSourceNames.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
		[out] Sources		 : The names of the logical source avalaible on the reader.
		[out] numSrc		 : The number of string in logical sources.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
		The function permits to know the name of the logical source available on the reader.
		Names are formatted according to DL RFID communication protocol.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetSourceNames(DLRFIDHandle Handle, char **Sources[], int *numSrc);

/*
    DLRFID_GetSourceInChannel.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  SourceName     : The name of the Logical Source.
        [in]  ChannelName    : The name of the Channel.
        [out] isPresent      : A flag indicating if the source is associated to
                               the specified channel.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to check if a logical source is associated to a
        specified notification channel that is, the data read from the source is
        sent to the channel.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_GetSourceInChannel(DLRFIDHandle Handle, char *SourceName, char *ChannelName, short *isPresent);

/*
    DLRFID_GetSourceInTrigger.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  SourceName     : The name of the Logical Source.
        [in]  TriggerName    : The name of the Trigger.
        [out] isPresent      : A flag indicating if the source is associated to
                               the specified trigger.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to check if a logical source is associated to a
        specified trigger.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_GetSourceInTrigger(DLRFIDHandle Handle, char *SourceName, char *TriggerName, short *isPresent);

/*
    DLRFID_GetTriggerInChannel.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  TriggerName    : The name of the Trigger.
        [in]  ChannelName    : The name of the ChannelName.
        [out] isPresent      : A flag indicating if the trigger is associated to
                               the specified channel.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to check if a trigger is associated to a
        specified notification channel.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_GetTriggerInChannel(DLRFIDHandle Handle, char *TriggerName, char *ChannelName, short *isPresent);

/*
    DLRFID_GetChannelInTrigger.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  ChannelName    : The name of the ChannelName.
        [in]  TriggerName    : The name of the Trigger.
		[out] isPresent      : A flag indicating if the channel is associated to
                               the specified trigger.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to check if a channel is associated to a
        specified notification trigger.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_GetChannelInTrigger(DLRFIDHandle Handle, char *ChannelName, char *TriggerName, short *isPresent);


/*
    DLRFID_GetReadPointInSource.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  SourceName     : The name of the Logical Source.
        [in]  ReadPoint      : The name of the Read Point.
        [out] isPresent      : A flag indicating if the read point is associated
                               to the specified source.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to check if a read point is associated to a
        specified logical source that is, the read point is used within a read
        cycle performed in the source.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.Use GetReadPointPresent") DLRFIDErrorCodes __stdcall
DLRFID_GetReadPointInSource(DLRFIDHandle Handle, char *ReadPoint, char *SourceName, short *isPresent);

/*
    DLRFID_isReadPointPresent.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  SourceName     : The name of the Logical Source.
        [in]  ReadPoint      : The name of the Read Point.
        [out] isPresent      : A flag indicating if the read point is associated
                               to the specified source.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to check if a read point is associated to a
        specified logical source that is, the read point is used within a read
        cycle performed in the source.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_isReadPointPresent(DLRFIDHandle Handle, char *ReadPoint, char *SourceName, short *isPresent);

/*
    DLRFID_SetNetwork.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  IPAddress      : The IP address to set in the form XXX.XXX.XXX.XXX
        [in]  NetMask        : The netmask to set in the form XXX.XXX.XXX.XXX
        [in]  Gateway        : The Gateway to set in the form XXX.XXX.XXX.XXX
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to configure the network address, the netmask and
        the default gateway of the reader. The settings are activated after a
        reboot of the reader.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SetNetwork(DLRFIDHandle Handle, char *IPAddress, char *NetMask, char *Gateway);

/*
    DLRFID_SetDE_SB.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  Enable         : Enable flag.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to enable the use of the data exchange status bit in
        the ISO18000-6b anticollision algorithm.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.Use SetDESB_ISO180006B instead") DLRFIDErrorCodes __stdcall
DLRFID_SetDE_SB(DLRFIDHandle Handle, unsigned int Enable);

/*
    DLRFID_GetDE_SB.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [out] Status         : The status flag.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to know if the data exchange status bit is used in
        the ISO18000-6b anticollision algorithm.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_GetDE_SB(DLRFIDHandle handle, unsigned short *Status);

/*
    DLRFID_GetDESB_ISO180006B.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [out] Status         : The status flag.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to know if the data exchange status bit is used in
        the ISO18000-6b anticollision algorithm.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_GetDE_SB(DLRFIDHandle handle, unsigned short *Status);

/*
    DLRFID_SetDESB_ISO180006B.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
		[in]  SourceName	 : The source name.
        [in]  Enable         : Enable flag.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to enable the use of the data exchange status bit in
        the ISO18000-6b anticollision algorithm.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SetDESB_ISO180006B(DLRFIDHandle Handle, char * SourceName, int Enable);

/*
    DLRFID_GetDESB_ISO180006B.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
		[in]  SourceName	 : The source name.
        [out] Status         : The status flag.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to know if the data exchange status bit is used in
        the ISO18000-6b anticollision algorithm.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetDESB_ISO180006B(DLRFIDHandle handle,char * SourceName,int *Status);


/*
    DLRFID_ProgramID. (DEPRECATED)
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  TagID          : The EPC to program in the tag.
        [in]  Password       : The kill password to program in the tag.
        [in]  Lock           : Aflag indicating if the EPC has to be locked.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to program an EPC Class 1 Gen 1 tag.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.Use ProgramID_EPC_C1G1 instead.") DLRFIDErrorCodes __stdcall
DLRFID_ProgramID(DLRFIDHandle Handle, DLRFIDTag *TagID, char Password, unsigned short Lock);

/*
    DLRFID_ProgramID_EPC_C1G1. 
	-----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  TagID          : The EPC to program in the tag.
        [in]  Password       : The kill password to program in the tag.
        [in]  Lock           : Aflag indicating if the EPC has to be locked.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to program an EPC Class 1 Gen 1 tag.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_ProgramID_EPC_C1G1(DLRFIDHandle Handle, DLRFIDTag *Tag, char Password, unsigned short Lock);

/*
    DLRFID_KillTag. (DEPRECATED)
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  TagID          : The EPC of the tag.
        [in]  Password       : The kill password for the tag.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to kill an EPC Class 1 Gen 1 tag.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.Use KillTag_EPC_C1G1 instead.") DLRFIDErrorCodes __stdcall
DLRFID_KillTag(DLRFIDHandle Handle, DLRFIDTag *TagID, char Password);

/*
    DLRFID_KillTag_EPC_C1G1.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  Tag            : The tag to kill.
        [in]  Password       : The kill password for the tag.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to kill an EPC Class 1 Gen 1 tag.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_KillTag_EPC_C1G1(DLRFIDHandle Handle, DLRFIDTag *Tag, char Password);


/*
    _DLRFID_RFControl. **** EXPERIMENTAL ****
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  RFOn			 : 0 Disable RF >0 Enable
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to turn on/off the RF field.

		**** ATTENTION ****
		This function is for experimantal use only
		DL may delete it in the next release.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
_DLRFID_RFControl(DLRFIDHandle handle, unsigned int RFOn);


/*
    DLRFID_BlockWrite(DEPRECATED)
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  ID        : The tag ID.
        [in]  Address   : The address of the memory to write.
        [in]  Length    : The number of bytes to write.
        [in]  Data      : The data to write in the tag's memory.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to write Length bytes to the memory of a
        specific tag identified by the ID (regardless of its status) at the
        address specified by Address.
		This function doesn't work with semi-passive tags
*/

DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.Use BlockWriteTagData instead.") DLRFIDErrorCodes __stdcall
DLRFID_BlockWrite(DLRFIDHandle handle, DLRFIDTag *ID, int Address, int Length, void *Data);


/*
    DLRFID_BlockWriteTagData
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  ID        : The tag ID.
        [in]  Address   : The address of the memory to write.
        [in]  Length    : The number of bytes to write.
        [in]  Data      : The data to write in the tag's user memory.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
		This method can be used to write a portion of the user memory in a ISO18000-6B tag
        using blocks of four bytes for each command.
*/

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_BlockWriteTagData(DLRFIDHandle handle, DLRFIDTag *ID, int Address, int Length, void *Data);

/*
    DLRFID_FilterBlockWriteTagData
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  ID        : The tag ID.
        [in]  Address   : The address of the memory to write.
		[in]  Mask		: A bitmask that permit to select which of the four bytes have to be written
						  (i.e. mask 0x05 writes the bytes on position Address + 1 and Address + 3)
        [in]  Length    : The number of bytes to write.
        [in]  Data      : The data to write in the tag's user memory.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
		This method can be used to write a portion of the user memory in a ISO18000-6B tag
        using blocks of four bytes for each command.You can provides a mask to select which
		of the four bytes has to be written.Only the 4 lsb are considered.
*/

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_FilterBlockWriteTagData(DLRFIDHandle handle, DLRFIDTag *ID, int Address, short Mask, int Length, void *Data);


/*
    DLRFID_SetRS232.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle		    : The handle that identifies the device.
        [in]  baud			    : The baudrate value.
        [in]  datab		        : The databit value.
        [in]  stopb             : The stopbit value.
        [in]  parity		    : The parity value.
        [in]  flowc		        : The flowcontrol value.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to configure the serial communication of the reader
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SetRS232(DLRFIDHandle handle, unsigned long baud, unsigned long datab, unsigned long stopb, DLRFID_RS232_Parity parity, DLRFID_RS232_FlowControl flowc);

/*
    DLRFID_SetAdminPassword.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  SecurePassword : The administrator password for the reader.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to set the admin password in the reader.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SetAdminPassword(DLRFIDHandle handle, int SecurePassword);

/*
    DLRFID_DoLogin.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
		[in]  SecurePassword : The administrator password for the reader.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function grants the administrator's reader permission of the reader.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_DoLogin(DLRFIDHandle handle, int SecurePassword);

/*
    DLRFID_DoLogout.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function revokes the administrator's reader permission of the reader.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_DoLogout(DLRFIDHandle handle);


/*
    DLRFID_SetDateTime.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  datetime       : The current date ed time.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to set the date e the time in the reader.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SetDateTime(DLRFIDHandle handle, char *datetime);

/*
	DLRFID_GetBufferedData.
	-----------------------------------------------------------------------------
	Parameters:
		[in] handle			: The handle that identifies the devices.
		[in] source			: The source channel to retrieve data from.
		[out]	Receive		: The Tags readed from the source.
		[out]	Size		: The number of tags readed.
	-----------------------------------------------------------------------------
	Returns:
		An error code about the execution of the function.
	-----------------------------------------------------------------------------
	Description:
		The function retrieves all the tags contained in the internal buffer of
		reader.The reader should have an embedded buffer.See the reader's tech
		manual for relative details.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetBufferedData(DLRFIDHandle handle,char * source,DLRFIDTag **Receive, int *Size);

/*
	DLRFID_GetBufferedDataRange.
	-----------------------------------------------------------------------------
	Parameters:
		[in] handle			: The handle that identifies the devices.
		[in] source			: The source channel to retrieve data from.
		[in] address		: The zero-based position in the internal buffer from
		                      which starts to read.
	    [in] length			: The number of records to retrive starting from the
							  address parameter.
		[out] Receive		: The Tags readed from the source.
		[out] Size			: The number of tags readed.
	-----------------------------------------------------------------------------
	Returns:
		An error code about the execution of the function.
	-----------------------------------------------------------------------------
	Description:
		The function retrieves all the tags contained in the internal buffer of
		reader starting from a certain record's offset and for a certain number.
		The reader should have an embedded buffer.See the reader's tech manual 
		for relative details.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetBufferedDataRange(DLRFIDHandle handle,char * source, int address, int length, DLRFIDTag **Receive, int *Size);

/*
	DLRFID_GetBufferSize.
	-----------------------------------------------------------------------------
	Parameters:
		[in]  handle		: The handle that identifies the devices.
		[out] Size			: The number of records contained in the internal buffer. 
	-----------------------------------------------------------------------------
	Returns:
		An error code about the execution of the function.
	-----------------------------------------------------------------------------
	Description:
		The function retrieves the number tags stored in the internal buffer of
		the reader.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetBufferSize (DLRFIDHandle handle, unsigned int *size);

/*
	DLRFID_ClearBuffer.
	-----------------------------------------------------------------------------
	Parameters:
		[in] handle			: The handle that identifies the devices.
	-----------------------------------------------------------------------------
	Returns:
		An error code about the execution of the function.
	-----------------------------------------------------------------------------
	Description:
		The function clear all the records contained in the internal's internal
		buffer.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_ClearBuffer (DLRFIDHandle handle);



DLRFIDlib_API DLRFIDErrorCodes __stdcall
_DLRFID_GroupSelUnsel(DLRFIDHandle handle, char *SourceName, DLRFID_SelUnsel_Op code, int Address, int BitMask, void *data, DLRFIDTag *ID);


/*
    DLRFID_GetIO.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [out] IORegister     : The current IO Register.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to read the IO register.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetIO(DLRFIDHandle handle, unsigned int *IORegister);

/*
    DLRFID_SetIO.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  IORegister     : The IO Register value.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to write the IO register.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SetIO(DLRFIDHandle handle, unsigned int IORegister);

/*
	DLRFID_GetChannelStatus
	-----------------------------------------------------------------------------
	Parameters:
	[in]  Handle         : The handle that identifies the device.
	[in]  channelname    : The name of the channel
	[out] status		 : The status of the channel
	-----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        Check if the notification channel is busy or not.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_GetChannelStatus(DLRFIDHandle handle,char *channelname , unsigned short *status);

/*
    DLRFID_GetIODirection.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [out] IODirection     : The current IO Direction.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to read the IO direction of IORegister.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetIODirection(DLRFIDHandle handle, unsigned int *IODirection);

/*
    DLRFID_SetIODirection.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  IODirection     : The IO Direction value.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to set the IO Direction for the IORegister.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SetIODirection(DLRFIDHandle handle, unsigned int IODirection);

/*
    DLRFID_SetSourceConfiguration.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  SourceName     : The Name of the Logical Source.
        [in]  parameter      : The parameter of Logical Source to configure.
        [in]  value          : The the value of the parameter.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to configure the Logical Source.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes  __stdcall
DLRFID_SetSourceConfiguration(DLRFIDHandle handle, char *SourceName, DLRFID_SOURCE_Parameter parameter, int value);

/*
		THIS function is NOT exported.
        The function permits to configure the Logical Source.
*/
DLRFIDErrorCodes  __stdcall
DLRFID_SetSourceConf(DLRFIDHandle handle, char *SourceName, DLRFID_SOURCE_Parameter parameter, int value);


/*
    DLRFID_GetSourceConfiguration.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  SourceName     : The Name of the Logical Source.
        [in]  parameter      : The parameter of Logical Source to configure.
        [out] value          : The the value of the parameter.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to get the value of the Logical Source configuration.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_GetSourceConfiguration(DLRFIDHandle handle, char *SourceName, DLRFID_SOURCE_Parameter parameter, int *pvalue);

/*
	 THIS function is NOT exported.The function permits to get the value 
	 of the Logical Source configuration.
*/
DLRFIDErrorCodes __stdcall
DLRFID_GetSourceConf(DLRFIDHandle handle, char *SourceName, DLRFID_SOURCE_Parameter parameter, int *pvalue);

/*
    DLRFID_GetAllocatedTriggers.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [out] TriggerNum     : The number of triggers allocated.
        [out] Triggers       : The Triggers's names of allocated triggers.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to get the allocated triggers.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_GetAllocatedTriggers(DLRFIDHandle handle, int *TriggerNum, char **Triggers);

/*
    DLRFID_GetAllocatedChannels.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [out] ChannelNum     : The number of channels allocated.
        [out] Channels       : The channels's names of allocated channels.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to get the allocated channels.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_GetAllocatedChannels(DLRFIDHandle handle, int *ChannelNum, char **Channels);


/*
    DLRFID_SetEventMode. (DEPRECATED)
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  EMode			 : The Event Mode.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to set the Event Generation Mode of the reader.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_SetEventMode(DLRFIDHandle handle, DLRFID_EventMode EMode);

/*
    DLRFID_GetEventMode. (DEPRECATED)
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [out] EMode			 : The Event Mode of the reader.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to get the Event Generation Mode of the reader.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_GetEventMode(DLRFIDHandle handle, DLRFID_EventMode *EMode);


/*
    DLRFID_FirmwareUpgrade.(DEPRECATED)
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  type			 : The kind of upgrading
        [in]  arg			 : The argument for the upgrading
								in the form '[tftpserver ip]:[filename]'
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to upgrade the reader's firmware.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_FirmwareUpgrade(DLRFIDHandle handle, DLRFID_FWUpgradeType type, char *arg);

/*
    DLRFID_ResetSession_EPC_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  SourceName	 : The name of the logical suorce where reset the session.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This method can be used to reset the Session status for EPC Class1 Gen2 tags.
        After the execution of this method all the tags in the field of the antennas belonging
        to this logical source are back in the default Session.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_ResetSession_EPC_C1G2(DLRFIDHandle handle, char *SourceName);
/*
    DLRFID_Lock_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  ID        : The tag ID.
        [in]  Payload   : The payload of the tag's memory.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to lock the memory of a
        specific tag identified by the ID and by Payload.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.Use LockTag_EPC_C1G2") DLRFIDErrorCodes __stdcall
DLRFID_Lock_C1G2(DLRFIDHandle handle, DLRFIDTag *ID, int payload);

/*
    DLRFID_LockTag_EPC_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  ID        : The tag to lock.
        [in]  Payload   : The payload of the tag's memory.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to lock the memory of a
        specific tag identified by the ID and by Payload.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_LockTag_EPC_C1G2(DLRFIDHandle Handle, DLRFIDTag *Tag, int Payload);

/*
    DLRFID_BankFilteredLock_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle		: The handle that identifies the device.
		[in]  SourceName	: The source where the tag has been detected.
        [in]  BankMask		: The bank where apply the mask filter.
		[in]  PositionMask	: The position where start the mask (bit oriented).
		[in]  LengthMask	: The number of significant bits of Mask from its start.
		[in]  Mask			: The mask filter array.
		[in]  MaskLen		: The length in bytes of Mask.
		[in]  Payload		: The Payload bitmask.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to lock the memory of a specific tag identified 
		by the bank parameters using Payload bitmask.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_BankFilteredLock_C1G2(DLRFIDHandle handle,char * SourceName, short BankMask, short PositionMask, short LengthMask, char * Mask, int MaskLen, int Payload);

/*
    DLRFID_KillTag_C1G2.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  TagID          : The EPC of the tag.
        [in]  Password       : The password for the tag.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to kill an EPC Class 1 Gen 2 tag.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.Use KillTag_EPC_C1G2 instead.") DLRFIDErrorCodes __stdcall
DLRFID_KillTag_C1G2(DLRFIDHandle handle, DLRFIDTag *ID, int password);

/*
    DLRFID_KillTag_C1G2.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  Tag            : The tag to kill.
        [in]  Password       : The password for the tag.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to kill an EPC Class 1 Gen 2 tag.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_KillTag_EPC_C1G2(DLRFIDHandle handle, DLRFIDTag *Tag, int password);

/*
    DLRFID_BankFilteredKillTag_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle		: The handle that identifies the device.
		[in]  SourceName	: The source where the tag has been detected.
        [in]  BankMask		: The bank where apply the mask filter.
		[in]  LengthMask	: The number of significant bits of Mask from its start.
		[in]  Mask			: The mask filter array.
		[in]  MaskLen		: The length in bytes of Mask.
		[in]  KillPassword	: The Kill password.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to kill an EPC Class 1 Gen 2 tag, identified
		by bank parameters.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_BankFilteredKillTag_EPC_C1G2(DLRFIDHandle handle,char * SourceName, short BankMask, short PositionMask, short LengthMask, char * Mask, int MaskLen, int KillPassword);


/*
    DLRFID_SetReadCycle.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  SourceName	 : The logical source where set the readcyle paramter.
        [in]  value			 : The number of read cycles.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        Sets the number of read cycles to be performed by the logical source 
         during the inventory algorithm execution.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SetReadCycle(DLRFIDHandle handle, char * SourceName, int value);
/*
    DLRFID_GetReadCycle.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  SourceName	 : The logical source where get the readcyle paramter.
        [out]  value			 : The number of read cycles.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        Gets the number of read cycles performed by the logical source 
         during the inventory algorithm execution.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetReadCycle(DLRFIDHandle handle, char * SourceName, int * value);


/*
    DLRFID_SetSelected_EPC_C1G2.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  SourceName	 : The logical source where set the readcyle paramter.
        [in]  value			 : The Selected flag value.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This method can be used to set the Selected flag (see EPC Class1 Gen2 protocol specification)
        used by the anticollision algorithm when called on this logical source.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SetSelected_EPC_C1G2(DLRFIDHandle handle, char * SourceName, DLRFIDLogicalSourceConstants value);
/*
    DLRFID_GetSelected_EPC_C1G2.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  SourceName	 : The logical source where get the readcyle paramter.
        [out]  value		 : The Selected flag value.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This method can be used to get the Selected flag (see EPC Class1 Gen2 protocol specification)
        used by the anticollision algorithm when called on this logical source.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetSelected_EPC_C1G2(DLRFIDHandle handle, char * SourceName, DLRFIDLogicalSourceConstants * value);

/*
    DLRFID_SetSession_EPC_C1G2.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  SourceName	 : The logical source where set the readcyle paramter.
        [in]  value			 : The Session value.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This method can be used to set the Session (see EPC Class1 Gen2 protocol specification)
        used by the anticollision algorithm when called on this logical source.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SetSession_EPC_C1G2(DLRFIDHandle handle, char * SourceName, DLRFIDLogicalSourceConstants value);
/*
    DLRFID_GetSession_EPC_C1G2.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  SourceName	 : The logical source where get the readcyle paramter.
        [out]  value		 : The Session value.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This method can be used to get the Session (see EPC Class1 Gen2 protocol specification)
        used by the anticollision algorithm when called on this logical source.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetSession_EPC_C1G2(DLRFIDHandle handle, char * SourceName, DLRFIDLogicalSourceConstants * value);

/*
    DLRFID_SetTarget_EPC_C1G2.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  SourceName	 : The logical source where set the readcyle paramter.
        [in]  value			 : The Target value.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This method can be used to set the Target setting (see EPC Class1 Gen2 protocol specification)
        used by the anticollision algorithm when called on this logical source.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SetTarget_EPC_C1G2(DLRFIDHandle handle, char * SourceName, DLRFIDLogicalSourceConstants value);
/*
    DLRFID_GetTarget_EPC_C1G2.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  SourceName	 : The logical source where get the readcyle paramter.
        [out]  value		 : The Target value.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This method can be used to get the Target setting (see EPC Class1 Gen2 protocol specification)
        used by the anticollision algorithm when called on this logical source.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetTarget_EPC_C1G2(DLRFIDHandle handle, char * SourceName, DLRFIDLogicalSourceConstants * value);

/*
    DLRFID_ProgramID_EPC119.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  ID			 : The actual ID of the tag.
        [in]  NewID			 : The new ID for the specified tag.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to program an EPC 119 tag.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_ProgramID_EPC119(DLRFIDHandle handle, DLRFIDTag *ID, char *NewID );

/*
    DLRFID_ProgramID_C1G2.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  ID			 : The EPC to program in the tag.
        [in]  nsi            : The NSI value for the EPC C1G2.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to program an EPC Class 1 Gen 2 tag.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.Use ProgramID_EPC_C1G2 instead.") DLRFIDErrorCodes __stdcall
DLRFID_ProgramID_C1G2(DLRFIDHandle handle, DLRFIDTag *ID, unsigned short nsi );

/*
    DLRFID_ProgramID_EPC_C1G2.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  ID			 : The EPC to program in the tag.
        [in]  nsi            : The NSI value for the EPC C1G2.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to program an EPC Class 1 Gen 2 tag.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_ProgramID_EPC_C1G2(DLRFIDHandle Handle, DLRFIDTag *Tag, unsigned short nsi );

/*
    DLRFID_Read_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  ID        : The tag ID.
		[in]  membank	: The memory Bank of EPC C1G2 Tag
        [in]  Address   : The address of the memory to read.
        [in]  Length    : The number of bytes to read.
        [out] Data      : The data read from the tag's memory.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to read Length bytes from the bank memory,
		specified by membank, of a specific tag identified by the
		ID (regardless of its status) at the address specified by Address.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.Use ReadTagData_EPC_C1G2 instead.") DLRFIDErrorCodes __stdcall
DLRFID_Read_C1G2(DLRFIDHandle handle, DLRFIDTag *ID, short membank, int Address, int Length, void *Data);

/*
    DLRFID_Read_EPC_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  ID        : The tag.
		[in]  membank	: The memory Bank of EPC C1G2 Tag
        [in]  Address   : The address of the memory to read.
        [in]  Length    : The number of bytes to read.
        [out] Data      : The data read from the tag's memory.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to read Length bytes from the bank memory,
		specified by membank, of a specific tag identified by the
		ID (regardless of its status) at the address specified by Address.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_ReadTagData_EPC_C1G2(DLRFIDHandle Handle, DLRFIDTag *Tag, short Membank, int Address, int Length, void *Data);

/*
    DLRFID_Write_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  ID        : The tag ID.
		[in]  membank	: The memory Bank of EPC C1G2 Tag
        [in]  Address   : The address of the memory to write.
        [in]  Length    : The number of bytes to write.
        [in]  Data      : The data to write in the tag's memory.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to write Length bytes to the bank memory,
		specified by membank, of a specific tag identified by the
		ID (regardless of its status) at the address specified by Address.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.Use WriteTagData_EPC_C1G2 instead.") DLRFIDErrorCodes __stdcall
DLRFID_Write_C1G2(DLRFIDHandle handle, DLRFIDTag *ID, short membank,int Address, int Length, void *Data);

/*
    DLRFID_WriteTagData_EPC_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  Tag        : The tag ID.
		[in]  membank	: The memory Bank of EPC C1G2 Tag
        [in]  Address   : The address of the memory to write.
        [in]  Length    : The number of bytes to write.
        [in]  Data      : The data to write in the tag's memory.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to write Length bytes to the bank memory,
		specified by membank, of a specific tag identified by the
		ID (regardless of its status) at the address specified by Address.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_WriteTagData_EPC_C1G2(DLRFIDHandle handle, DLRFIDTag *Tag, short membank,int Address, int Length, void *Data);


/*
    DLRFID_BankFilteredRead_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle		: The handle that identifies the device.
        [in]  SourceName	: The source where the tag has been detected.
		[in]  BankMask		: The bank where apply the mask filter.
		[in]  PositionMask	: The position where start the mask (bit oriented).
		[in]  LengthMask	: The lenght of the meaning bits of Mask from its start.
		[in]  Mask			: The mask filter array
		[in]  MaskLen		: The number of bytes passed in Mask.
		[in]  Membank		: The memory Bank of EPC C1G2 Tag
        [in]  Address		: The address of the memory to read.
        [in]  Length		: The number of bytes to read.
        [out] Data			: The data read from the tag's memory.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to read Length bytes from the bank memory of a tag,
		specified by Membank, identified by BankMask,PositionMask,LengthMask and Mask,from the 
		address specified by Address.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_BankFilteredReadTagData_EPC_C1G2(DLRFIDHandle Handle,char * SourceName, short BankMask, short PositionMask, short LengthMask, char * Mask, int MaskLen, short MemBank, int Address, int Length, void *Data);

/*
    DLRFID_BankFilteredWrite_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle		: The handle that identifies the device.
		[in]  SourceName	: The source where the tag has been detected.
        [in]  BankMask		: The bank where apply the mask filter.
		[in]  PositionMask	: The position where start the mask (bit oriented).
		[in]  LengthMask	: The meaning length in bit of Mask from its start.
		[in]  Mask			: The mask filter array
		[in]  MaskLen		: The length in bytes of passed Mask.
		[in]  membank		: The memory Bank of EPC C1G2 Tag
        [in]  Address		: The address of the memory to write.
        [in]  Length		: The number of bytes to write.
        [in]  Data			: The data to write in the tag's memory.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to write Length bytes to the bank memory,
		specified by membank, of a specific tag identified by the 
		bank paramters(bankMask,PositionMask,LengthMask,Mask) at the 
		address specified by Address.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_BankFilteredWriteTagData_EPC_C1G2(DLRFIDHandle handle,char * SourceName, short BankMask, short PositionMask, short LengthMask, char * Mask, int MaskLen, short MemBank,int Address, int Length, void *Data);

/*
    DLRFID_QueryTag_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  SourceName     : The Name of the Logical Source.
        [out] isPresent      : A flag indicating if the tag answered at Query command
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to perform the Query command of C1G2 protocol
*/

DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.Use QueryTag_EPC_C1G2 instead.") DLRFIDErrorCodes __stdcall
DLRFID_QueryTag_C1G2(DLRFIDHandle handle, char *SourceName, short *isPresent);

/*
    DLRFID_QueryTag_EPC_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  SourceName     : The Name of the Logical Source.
        [out] isPresent      : A flag indicating if the tag answered at Query command
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to perform the Query command of C1G2 protocol
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_QueryTag_EPC_C1G2(DLRFIDHandle handle, char *SourceName, short *isPresent);

/*
    DLRFID_SetQ_C1G2 (DEPRECATED)
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Q     : The value of Q.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to set the Q parameter of C1G2 protocol
*/

DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.Use DLRFID_SetQValue_EPC_C1G2 instead") DLRFIDErrorCodes __stdcall
DLRFID_SetQ_C1G2(DLRFIDHandle handle, int Q);

/*
    DLRFID_GetQ_C1G2 (DEPRECATED)
    -----------------------------------------------------------------------------
    Parameters:
        [out]  Q     : The value of Q.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to get the Q parameter of C1G2 protocol
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.Use DLRFID_GetQValue_EPC_C1G2 instead") DLRFIDErrorCodes __stdcall
DLRFID_GetQ_C1G2(DLRFIDHandle handle, int *Q);

/*
    DLRFID_SetQValue_EPC_C1G2
    -----------------------------------------------------------------------------
    Parameters:
		[in]  SourceName     : The Name of the Logical Source.
        [in]  Q     : The value of Q.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to set the Q parameter of C1G2 protocol
*/

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SetQValue_EPC_C1G2(DLRFIDHandle handle, char *SourceName, int Q);

/*
    DLRFID_GetQValue_EPC_C1G2
    -----------------------------------------------------------------------------
    Parameters:
		[in]  SourceName     : The Name of the Logical Source.
        [out]  Q     : The value of Q.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to get the Q parameter of C1G2 protocol
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetQValue_EPC_C1G2(DLRFIDHandle handle, char *SourceName, int *Q);

/*
	DLRFID_SetTIDLength
    -----------------------------------------------------------------------------
    Parameters:
		[in]  SourceName     : The Name of the Logical Source.
        [out]  initLength     : The initial TID Length.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to set the initial TID length. When used on inventory, 
		with TID_READING flag enable, the reader try to read TID memory from initLength
		to the max length reaches with no TID membank reading error.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SetTIDLength(DLRFIDHandle handle, char *SourceName, int initLength);

/*
	DLRFID_GetTIDLength
    -----------------------------------------------------------------------------
    Parameters:
		[in]  SourceName     : The Name of the Logical Source.
        [out]  initLength     : The initial TID Length.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to get the initial TID length. When used on inventory, 
		with TID_READING flag enable, the reader try to read TID memory from initLength
		to the max length reaches with no TID membank reading error.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetTIDLength(DLRFIDHandle handle, char *SourceName, int *initLength);



/*
    DLRFID_GetReaderInfo
    -----------------------------------------------------------------------------
    Parameters:
        [out] Model : 		Returns the model of the reader.
        [out] SerialNum : 	Returns the Serial number of the reader.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        Permits to read the Model and the Serial number of the Reader.
*/

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetReaderInfo(DLRFIDHandle handle,char *Model, char *SerialNum);

/*
    DLRFID_InventoryTag.(DEPRECATED)
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  LogicalSourceName : The name that identify the Logical Source
        [out] Receive  : Returns an array containing the tags read.
        [out] Size     : Returns the number of tags in the array.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function returns all the IDs of the tags under the reader field
        using all the available antennae. The Tags array contains The IDs
        together with other information related to the single ID such as the
        antenna under which is the ID and the format of the ID itself (see
        DLRFIDTag struct for the details).
*/

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_InventoryTag (DLRFIDHandle handle, char *SourceName, DLRFIDTag **Receive, int *Size);

/*
    DLRFID_GetLBTMode.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [out] LBTMode		 : The ListenBeforeTalk Mode of the reader.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to get the The ListenBeforeTalk Mode of the reader.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetLBTMode(DLRFIDHandle handle, unsigned short *LBTMode);

/*
    DLRFID_SetLBTMode.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle         : The handle that identifies the device.
        [in]  LBTMode        : The ListenBeforeTalk Mode of the reader.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to change the The ListenBeforeTalk Mode of the reader.
*/

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SetLBTMode(DLRFIDHandle handle, unsigned short LBTMode);

/*
    DLRFID_GetChannelData.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  handle         : The handle that identifies the device.
		[in]  ChannelName    : The name of the ChannelName that is memorizing the data.
        [out] TagsDetected   : A list of data items.
        [out] NumberItemsNotified : The number of data items in the list..
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to retrieve the data memorized by a Channel (Memory Mode).
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_GetChannelData(DLRFIDHandle handle, char *ChannelName, DLRFIDNotify **TagsDetected, int *NumberItemsNotified);

/*
    DLRFID_FreeTagsMemory.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Tags         : Reference to DLRFIDTag obtained from DLRFIDInventory 
							 or DLRFID_InventoryTag.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to free the allocated by DLRFIDInventory or 
		by DLRFID_InventoryTag.
*/
DLRFIDlib_API void __stdcall
DLRFID_FreeTagsMemory(DLRFIDTag **Tags);

/*
    DLRFID_GetRFChannel.
    -----------------------------------------------------------------------------
    Parameters:
		[in]  handle    : The handle that identifies the device.
        [out] RFChannel : The RFChannel
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to retrieve the RFChanel.
*/

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetRFChannel(DLRFIDHandle handle, unsigned short *RFChannel);

/*
    DLRFID_SetRFChannel.
    -----------------------------------------------------------------------------
    Parameters:
		[in]  handle    : The handle that identifies the device.
        [in]  RFChannel : The RFChannel
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to set the RFChanel.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SetRFChannel(DLRFIDHandle handle, unsigned short RFChannel);

/*
    DLRFID_GetRFRegulation.
    -----------------------------------------------------------------------------
    Parameters:
		[in]  handle		: The handle that identifies the device.
        [out] RFRegulation  : The RFRegulation
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to retrieve the RFRegulation.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_GetRFRegulation(DLRFIDHandle handle, DLRFIDRegulations *RFRegulation);

/*
    DLRFID_SetRFRegulation.
    -----------------------------------------------------------------------------
    Parameters:
		[in]  handle		: The handle that identifies the device.
        [in]  RFRegulation  : The RFRegulation
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to set the RFRegulation.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SetRFRegulation(DLRFIDHandle handle, DLRFIDRegulations RFRegulation);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_EM4325_GetUID(DLRFIDHandle handle, DLRFIDTag *Tag, byte *UID, int *UIDLength);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SecureEM4325_GetUID(DLRFIDHandle handle, DLRFIDTag *Tag, byte *UID, int *UIDLength,int SecurePassword);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_EM4325_GetSensorData(DLRFIDHandle handle, DLRFIDTag *Tag, BOOL UIDEnable, byte *UID, int *UIDLength, BOOL NewSample, byte *Sensor, byte *UTC);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_EM4325_SendSPI(DLRFIDHandle handle, DLRFIDTag *Tag, byte SPIConfig, byte *SPICmd, int SPICmdLen, int SlaveSPILength, char *TRData);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SecureEM4325_SendSPI(DLRFIDHandle handle, DLRFIDTag *Tag, byte SPIConfig, byte* SPICmd, int SPICmdLen, int SlaveSPILength, int SecurePassword, char *TRData);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SecureEM4325_ResetAlarms(DLRFIDHandle handle, DLRFIDTag *Tag, int SecurePassword);    

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_ISO180006C_BroadcastSync(DLRFIDHandle handle, byte *UTC);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_IDS_SL900A_Initialize(DLRFIDHandle handle, DLRFIDTag *Tag, unsigned short DelayTime, unsigned short  ApplicationData);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_IDS_SL900A_SetLog(DLRFIDHandle handle, DLRFIDTag *Tag, unsigned int LogMode);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_IDS_SL900A_StartLog(DLRFIDHandle handle, DLRFIDTag *Tag, unsigned int StartTime);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_IDS_SL900A_EndLog(DLRFIDHandle handle, DLRFIDTag *Tag);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_IDS_SL900A_GetLogState(DLRFIDHandle handle, DLRFIDTag *Tag, BOOL ShelfLife, char * TRData);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Oridao_Begin(DLRFIDHandle handle, DLRFIDTag *Tag, unsigned short *result);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SecureOridao_Begin(DLRFIDHandle handle, DLRFIDTag *Tag, unsigned short *result,int SecurePassword);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Oridao_Command(DLRFIDHandle handle, DLRFIDTag *Tag, unsigned short cchandle, unsigned short WriteLengthBit, byte * WriteData, unsigned short ReplyLengthBit);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Oridao_End(DLRFIDHandle handle, DLRFIDTag *Tag);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_IDS_SL900A_GetSensorValue(DLRFIDHandle handle, DLRFIDTag *Tag, byte SensorType, DLRFID_IDSTagData * IDSTagData);



DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.Use QueryAck_EPC_C1G2 instead.")DLRFIDErrorCodes __stdcall
DLRFID_QueryAck_C1G2(DLRFIDHandle handle, char *SourceName, byte *id);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_QueryAck_EPC_C1G2(DLRFIDHandle Handle, char *SourceName, byte *id);

/*
    DLRFID_FreeNotifyMemory.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  ItemsNotified : Reference to DLRFIDNotify obtained from 
							  DLRFID_GetNotification or DLRFID_GetChannelData.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to free the allocated by DLRFID_GetNotification or 
		DLRFID_GetChannelData functions.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") void __stdcall
DLRFID_FreeNotifyMemory(DLRFIDNotify **ItemsNotified);

/*
    DLRFID_SecureProgramID_C1G2.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle			: The handle that identifies the device.
        [in]  ID				: The EPC to program in the tag.
        [in]  nsi				: The NSI value for the EPC C1G2.
		[in]  Pwd				: The access Password
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to program an EPC Class 1 Gen 2 tag setting the secure password.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.Use SecureProgramID_EPC_C1G2 instead.") DLRFIDErrorCodes __stdcall
DLRFID_SecureProgramID_C1G2(DLRFIDHandle handle, DLRFIDTag *ID, unsigned short nsi, int Pwd);

/*
    DLRFID_SecureProgramID_EPC_C1G2.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle			: The handle that identifies the device.
        [in]  ID				: The EPC to program in the tag.
        [in]  nsi				: The NSI value for the EPC C1G2.
		[in]  Pwd				: The access Password
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function permits to program an EPC Class 1 Gen 2 tag setting the secure password.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SecureProgramID_EPC_C1G2(DLRFIDHandle handle, DLRFIDTag *Tag, unsigned short nsi, int AccessPassword);


/*
    DLRFID_SecureRead_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle			: The handle that identifies the device.
        [in]  ID				: The tag ID.
		[in]  membank			: The memory Bank of EPC C1G2 Tag
        [in]  Address			: The address of the memory to read.
        [in]  Length			: The number of bytes to read.
		[in]  Pwd				: The access Password
        [out] Data				: The data read from the tag's memory.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to Secure read Length bytes from the bank memory,
		specified by membank, of a specific tag identified by the
		ID (regardless of its status) at the address specified by Address.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.Use SecureReadTagData_EPC_C1G2 instead.") DLRFIDErrorCodes __stdcall
DLRFID_SecureRead_C1G2(DLRFIDHandle handle, DLRFIDTag *ID,short membank, int Address, int Length, int Pwd, void *Data);

/*
    DLRFID_SecureReadTagData_EPC_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle			: The handle that identifies the device.
        [in]  Tag				: The tag.
		[in]  membank			: The memory Bank of EPC C1G2 Tag
        [in]  Address			: The address of the memory to read.
        [in]  Length			: The number of bytes to read.
		[in]  AccessPassword				: The access Password
        [out] Data				: The data read from the tag's memory.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to Secure read Length bytes from the bank memory,
		specified by membank, of a specific tag identified by the
		ID (regardless of its status) at the address specified by Address.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SecureReadTagData_EPC_C1G2(DLRFIDHandle handle, DLRFIDTag *Tag,short membank, int Address, int Length, int AccessPassword, void *Data);


/*
    DLRFID_SecureWrite_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle			: The handle that identifies the device.
        [in]  ID				: The tag ID.
		[in]  membank			: The memory Bank of EPC C1G2 Tag
        [in]  Address			: The address of the memory to write.
        [in]  Length			: The number of bytes to write.
        [in]  Data				: The data to write in the tag's memory.
		[in]  Pwd				: The access Password
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to secure write Length bytes to the bank memory,
		specified by membank, of a specific tag identified by the
		ID (regardless of its status) at the address specified by Address.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.Use SecureWriteTagData_EPC_C1G2 instead.") DLRFIDErrorCodes __stdcall
DLRFID_SecureWrite_C1G2(DLRFIDHandle handle, DLRFIDTag *ID, short membank,int Address, int Length, void *Data, int Pwd);

/*
    DLRFID_SecureWriteTagData_EPC_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle			: The handle that identifies the device.
        [in]  Tag				: The tag ID.
		[in]  membank			: The memory Bank of EPC C1G2 Tag
        [in]  Address			: The address of the memory to write.
        [in]  Length			: The number of bytes to write.
        [in]  Data				: The data to write in the tag's memory.
		[in]  AccessPassword	: The access Password
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to secure write Length bytes to the bank memory,
		specified by membank, of a specific tag identified by the
		ID (regardless of its status) at the address specified by Address.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SecureWriteTagData_EPC_C1G2(DLRFIDHandle Handle, DLRFIDTag *Tag, short membank,int Address, int Length, void *Data, int AccessPassword);



/*
    DLRFID_SecureLock_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle			: The handle that identifies the device.
        [in]  ID				: The tag ID.
        [in]  Payload			: The payload of the tag's memory.
		[in]  Pwd				: The access Password
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to secure lockthe memory of a
        specific tag identified by the ID and by Payload.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.Use SecureLockTag_EPC_C1G2 instead.") DLRFIDErrorCodes __stdcall
DLRFID_SecureLock_C1G2(DLRFIDHandle handle, DLRFIDTag *ID, int payload, int Pwd);

/*
    DLRFID_SecureLockTag_EPC_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle			: The handle that identifies the device.
        [in]  Tag				: The tag.
        [in]  Payload			: The payload of the tag's memory.
		[in]  AccessPssword		: The access Password
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to secure lockthe memory of a
        specific tag identified by the ID and by Payload.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SecureLockTag_EPC_C1G2(DLRFIDHandle handle, DLRFIDTag *Tag, int payload, int AccessPassword);

/*
DLRFID_SecureBankFilteredLock_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle		: The handle that identifies the device.
        [in]  SourceName	: The source where the tag has been detected.
		[in]  BankMask		: The bank where apply the mask filter.
		[in]  PositionMask	: The position where start the mask (bit oriented).
		[in]  LengthMask	: The number of significant bits of Mask from its start.
		[in]  Mask			: The mask filter array.
		[in]  MaskLen		: The length in bytes of Mask.
		[in]  Payload		: the payload bitmask.
		[in]  Pwd			: The access Password.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to secure lock the memory of a
        specific tag, identified by the bank parameters, with Payload bitmask.
		This is the secure version.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SecureBankFilteredLockTag_EPC_C1G2(DLRFIDHandle Handle,char * SourceName, short BankMask, short PositionMask, short LengthMask, char * Mask, int MaskLen, int Payload,int AccessPassword);


/*
    DLRFID_SecureBankFilteredRead_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle		: The handle that identifies the device.
        [in]  SourceName	: The source where the tag has been detected.
		[in]  BankMask		: The bank where apply the mask filter.
		[in]  PositionMask	: The position where start the mask (bit oriented).
		[in]  LengthMask	: The length of the mask in word.
		[in]  Mask			: The mask filter array
		[in]  membank		: The memory Bank of EPC C1G2 Tag
        [in]  Address		: The address of the memory to read.
        [in]  Length		: The number of bytes to read.
        [out] Data			: The data read from the tag's memory.
		[in]  Pwd			: The access Password
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to read Length bytes from the bank memory,
		specified by membank, of a specific tag identified by the
		the bank paramters(bankMask,PositionMask,LengthMask,Mask) at the 
		address specified by Address.
		This is the secure version.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SecureBankFilteredReadTagData_EPC_C1G2(DLRFIDHandle handle,char * SourceName, short BankMask, short PositionMask, short LengthMask, char * Mask,int MaskLen, short membank, int Address, int Length, void *Data,int Pwd);

/*
    DLRFID_SecureBankFilteredWrite_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle		: The handle that identifies the device.
		[in]  SourceName	: The source where the tag has been detected.
        [in]  BankMask		: The bank where apply the mask filter.
		[in]  PositionMask	: The position where start the mask (bit oriented).
		[in]  LengthMask	: The meaning length in bit of Mask from its start.  
		[in]  Mask			: The mask filter array
		[in]  MaskLen		: The number of bytes of Mask.
		[in]  membank		: The memory Bank of EPC C1G2 Tag
        [in]  Address		: The address of the memory to write.
        [in]  Length		: The number of bytes to write.
        [in]  Data			: The data to write in the tag's memory.
		[in]  AccessPassword: The access Password
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        This function allows to write Length bytes to the bank memory,
		specified by membank, of a specific tag identified by the 
		bank paramters(bankMask,PositionMask,LengthMask,Mask) at the 
		address specified by Address.
		This is the secure version.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SecureBankFilteredWriteTagData_EPC_C1G2(DLRFIDHandle handle,char * SourceName, short BankMask, short PositionMask, short LengthMask, char * Mask, int MaskLen, short membank,int Address, int Length, void *Data, int Pwd);

/*
    DLRFID_CustomCmd_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle			: The handle that identifies the device.
        [in]  ID				: The tag ID.
        [in]  SubCmd			: The subcommand.
        [in]  RTLength			: The number of bytes to send to the tag.
        [in]  RTData			: The data to be sent to the tag.
        [in]  TRLength			: The number of bytes to be received from the tag.
        [out] TRData			: The data received from the tag.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
		Special function to implement custom commands.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.Use CustomCommand_EPC_C1G2 instead.")DLRFIDErrorCodes __stdcall
DLRFID_CustomCmd_C1G2(DLRFIDHandle handle, DLRFIDTag *ID, unsigned char subcmd, 
						int RTLength, void *RTData, int TRLength, void *TRData);

/*
    DLRFID_CustomCommand_EPC_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle			: The handle that identifies the device.
        [in]  Tag				: The tag.
        [in]  SubCmd			: The subcommand.
        [in]  RTLength			: The number of bytes to send to the tag.
        [in]  RTData			: The data to be sent to the tag.
        [in]  TRLength			: The number of bytes to be received from the tag.
        [out] TRData			: The data received from the tag.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
		Special function to implement custom commands.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_CustomCommand_EPC_C1G2(DLRFIDHandle handle, DLRFIDTag *Tag, unsigned char subcmd, 
						int RTLength, void *RTData, int TRLength, void *TRData);


/*
    DLRFID_SecureCustomCmd_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle			: The handle that identifies the device.
        [in]  ID				: The tag ID.
        [in]  SubCmd			: The subcommand.
        [in]  RTLength			: The number of bytes to send to the tag.
        [in]  RTData			: The data to be sent to the tag.
        [in]  TRLength			: The number of bytes to be received from the tag.
		[in]  Pwd				: The access Password
        [out] TRData			: The data received from the tag.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
		Special function to implement custom commands.
*/
DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.Use SecureCustomCommand_EPC_C1G2 instead.") DLRFIDErrorCodes __stdcall
DLRFID_SecureCustomCmd_C1G2(DLRFIDHandle handle, DLRFIDTag *ID, unsigned char subcmd,
							  int RTLength, void *RTData, int TRLength, int Pwd, void *TRData);

/*
    DLRFID_SecureCustomCommand_EPC_C1G2
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle			: The handle that identifies the device.
        [in]  Tag				: The tag.
        [in]  SubCmd			: The subcommand.
        [in]  RXLen  			: The number of bytes to send to the tag.
        [in]  Data				: The data to be sent to the tag.
        [in]  TXLen 			: The number of bytes to be received from the tag.
		[in]  AccessPassword	: The access Password
        [out] TRData			: The data received from the tag.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
		Special function to implement custom commands.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_SecureCustomCommand_EPC_C1G2(DLRFIDHandle handle, DLRFIDTag *Tag, unsigned char subcmd,
							  int RXLen, void *Data, int TXLen, int AccessPassword, void *TRData);

/* 
	DLRFID_LockBlockPermaLock_EPC_C1G2.
	-----------------------------------------------------------------------------
	Parameters:
        [in]  Handle			: The handle that identifies the device.
        [in]  ID				: The tag ID.
        [in]  MemBank			: The memory bank where to write the data.
        [in]  BlockPtr			: The address where to start writing the data.</param>
        [in]  BlockRange		: The number of word of the mask</param>
        [in]  Mask				: A bitmask that permit to select which of the four bytes have to be locked
								 (i.e. mask 0x05 write the bytes on position Address + 1 and Address + 3)
		[in]  MaskLength		: The effective length in byte of the mask.Usually BlockRange * 2
        [in]  SecurePassword	: The access password
	-----------------------------------------------------------------------------
	Returns:
		An error code about the execution of the function.
	-----------------------------------------------------------------------------
	Description:
		This method implements the BLockPermaLock with ReadLock=1 as specified in EPCC1G2 rev. 1.2.0 protocol.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_LockBlockPermaLock_EPC_C1G2( DLRFIDHandle handle, DLRFIDTag *Tag, short MemBank, short BlockPtr, short BlockRange, void * Mask, int MaskLength, int AccessPassword);
/* 
	DLRFID_LockBlockPermaLock_EPC_C1G2.
	-----------------------------------------------------------------------------
	Parameters:\
        [in]  Handle			: The handle that identifies the device.
        [in]  ID				: The tag ID.
        [in]  MemBank			: The memory bank where to read the data.
        [in]  BlockPtr			: The address where to start reading the data.</param>
        [in]  BlockRange		: The number of word to read</param>
		[out] Data				: The bytes read. The number of bytes read are BlockRange*2.
        [in]  SecurePassword	: The access password
	-----------------------------------------------------------------------------
	Returns:
		An error code about the execution of the function.
	-----------------------------------------------------------------------------
	Description:
		This method implements the BLockPermaLock with ReadLock=0 as specified in EPCC1G2 rev. 1.2.0 protocol.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_ReadBlockPermalock_EPC_C1G2( DLRFIDHandle handle, DLRFIDTag *Tag, short MemBank, short Blockptr, short BlockRange, void * Data, int AccessPassword);

/*
    DLRFID_FilteredInventoryTag.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  LogicalSourceName : The name that identify the Logical Source
		[in]  Mask		: The array containing the ID Mask
		[in]  MaskLength : The length in bit of the significative part of the Mask
		[in]  Position	: The position in bit from where starting to compare the mask to the ID
        [out] Receive  : Returns an array containing the tags read.
        [out] Size     : Returns the number of tags in the array.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function returns all the IDs of the tags under the reader field
        using all the available antennae. The Tags array contains The IDs
        together with other information related to the single ID such as the
        antenna under which is the ID and the format of the ID itself (see
        DLRFIDTag struct for the details).
*/

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_FilteredInventoryTag (DLRFIDHandle handle, char *SourceName, char* Mask, unsigned char MaskLength, unsigned char Position, DLRFIDTag **Receive, int *Size);

/*
    DLRFID_FlagInventoryTag.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  LogicalSourceName : The name that identify the Logical Source
		[in]  Mask		: The array containing the ID Mask
		[in]  MaskLength : The length in bit of the significative part of the Mask
		[in]  Position	: The position in bit from where starting to compare the mask to the ID
		[in]  Flag		: A bitmask that indicates the compact mode inventory and the retriving of rssi and TID values
        [out] Receive  : Returns an array containing the tags read.
        [out] Size     : Returns the number of tags in the array.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function returns all the IDs of the tags under the reader field
        using all the available antennae. The Tags array contains The IDs
        together with other information related to the single ID such as the
        antenna under which is the ID and the format of the ID itself (see
        DLRFIDTag struct for the details).
		NOTE: Bit 1 and 2 of Falg parameter are ignored.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_FlagInventoryTag (DLRFIDHandle handle, char *SourceName, char* Mask, unsigned char MaskLength, unsigned char Position,unsigned char flag,DLRFIDTag **Receive, int *Size);

/*
    DLRFID_BankFilteredFlagInventoryTag.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle			: The handle that identifies the device.
        [in]  LogicalSourceName : The name that identify the Logical Source
		[in]  Bank				: The bank where apply the mask
		[in]  Position			: The position in bit from where starting to compare the mask to the choosen bank
		[in]  MaskLength		: The length in bit of the significative part of the Mask
		[in]  Mask				: The array containing the ID Mask
		[in]  MaskLen			: The number of bytes passed in Mask.
		[in]  Flag				: A bitmask that indicates the compact mode inventory and the retriving of rssi and TID values
        [out] Receive			: Returns an array containing the tags read.
        [out] Size				: Returns the number of tags in the array.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function returns all the IDs of the tags under the reader field
        using all the available antennae. The Tags array contains The IDs
        together with other information related to the single ID such as the
        antenna under which is the ID and the format of the ID itself (see
        DLRFIDTag struct for the details).
		It applies the mask parameters to the founded tags, retrieving only 
		tags where relative bank matches with the mask.
        In this case bit 1 and 2 of Flag (continuos and framed mode) are ignored.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_BankFilteredFlagInventoryTag (DLRFIDHandle handle, char *SourceName, short bank, short Position, short MaskLength, char * Mask, int MaskLen, unsigned char flag, DLRFIDTag **Receive, int *Size);

/*
    DLRFID_BankFilteredInventoryTag.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle			: The handle that identifies the device.
        [in]  LogicalSourceName : The name that identify the Logical Source
		[in]  Bank				: The bank where apply the mask
		[in]  MaskLength		: The length in bit of the significative part of the Mask from its start
		[in]  Mask				: The array containing the ID Mask
		[in]  MaskLen			: The number of bytes passed in Mask.
		[in]  Position			: The position in bit from where starting to compare the mask to the choosen bank
        [out] Receive			: Returns an array containing the tags read.
        [out] Size				: Returns the number of tags in the array.
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function returns all the IDs of the tags under the reader field
        using all the available antennae. The Tags array contains The IDs
        together with other information related to the single ID such as the
        antenna under which is the ID and the format of the ID itself (see
        DLRFIDTag struct for the details).
		It applies the mask parameters to the founded tags, retrieving only 
		tags where relative bank matches with the mask.
        In this case bit 1 and 2 of Flag (continuos and framed mode) are ignored.
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_BankFilteredInventoryTag (DLRFIDHandle handle, char *SourceName, short bank, short Position, short MaskLength, char * Mask, int MaskLen, DLRFIDTag **Receive, int *Size);

DLRFIDlib_API deprecate_msg("Deprecated function.Use DLRFID_EventInventoryTag instead.") DLRFIDErrorCodes __stdcall
DLRFID_ExtendedInventoryTag (DLRFIDHandle handle, DLRFID_ExtendedInventoryParams InvParams);
/*
    DLRFID_EventInventoryTag.
    -----------------------------------------------------------------------------
    Parameters:
        [in]  Handle    : The handle that identifies the device.
        [in]  LogicalSourceName : The struct representing the inventory parameters
    -----------------------------------------------------------------------------
    Returns:
        An error code about the execution of the function.
    -----------------------------------------------------------------------------
    Description:
        The function doesn't directly return anything. The tags inventoried by this
		function are passed passed to a user-definied callback passed in InvParams.pCallback
		as a DLRFID_INVENTORY_CALLBACK (see DLRFID_EventInventoryParams struct for details).
		The run mode of this funcitons are two:non continuos and continuos.
		In the second case (continuos mode) we can choose to pass to the callback the tag in the RF field
		all in one call (expensive in output time terms), or one per call.
		In all case we can get the tag in compact version.
		
*/
DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_EventInventoryTag (DLRFIDHandle handle, DLRFID_EventInventoryParams InvParams);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_InventoryAbort(DLRFIDHandle handle);

//----------------------------Custom Command-----------------------------//

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Hitachi_ReadLock(DLRFIDHandle handle, DLRFIDTag *Tag, short Payload);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Hitachi_SecureReadLock(DLRFIDHandle handle, DLRFIDTag *Tag, short Payload, int SecurePassword);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Hitachi_WriteMultipleWords(DLRFIDHandle handle, DLRFIDTag *Tag, short membank, short address, short nbyte, char *twrite);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Hitachi_SecureWriteMultipleWords(DLRFIDHandle handle, DLRFIDTag *Tag, short membank, short address, short nbyte, char *twrite, int SecurePassword);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Hitachi_BlockLock(DLRFIDHandle handle, DLRFIDTag *Tag, char BlockNum, int UserPassword, char PayLoad);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Hitachi_SecureBlockLock(DLRFIDHandle handle, DLRFIDTag *Tag, char BlockNum, int UserPassword, char PayLoad, int SecurePassword);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Hitachi_BlockReadLock(DLRFIDHandle handle, DLRFIDTag *Tag, byte BlockNum, int UserPassword, byte PayLoad);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Hitachi_SecureBlockReadLock(DLRFIDHandle handle, DLRFIDTag *Tag, byte BlockNum, int UserPassword, byte PayLoad, int SecurePassword);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Hitachi_GetSystemInformation(DLRFIDHandle handle, DLRFIDTag *Tag, char *TRData);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Hitachi_SecureGetSystemInformation(DLRFIDHandle handle, DLRFIDTag *Tag, char *TRData, int SecurePassword);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Hitachi_SecureSetAttenuate(DLRFIDHandle handle, DLRFIDTag *Tag, char Level, char LevelLock, int SecurePassword);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Hitachi_SetAttenuate(DLRFIDHandle handle, DLRFIDTag *Tag, char Level, char LevelLock);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Fujitsu_Refresh(DLRFIDHandle handle, DLRFIDTag *Tag, char option);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Fujitsu_SecureRefresh(DLRFIDHandle handle, DLRFIDTag *Tag, char option, int SecurePassword);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Fujitsu_ChgWordLock(DLRFIDHandle handle, DLRFIDTag *Tag, char MemBank, short WordPtr, char Payload, int UserPassword);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Fujitsu_SecureChgWordLock(DLRFIDHandle handle, DLRFIDTag *Tag, char MemBank, short WordPtr, char Payload, int UserPassword, int SecurePassword);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Fujitsu_ChgBlockLock(DLRFIDHandle handle, DLRFIDTag *Tag, char BlockGroupPtr, int Payload, int UserPassword);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Fujitsu_SecureChgBlockLock(DLRFIDHandle handle, DLRFIDTag *Tag, char BlockGroupPtr, int Payload, int UserPassword, int SecurePassword);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Fujitsu_ReadBlockLock(DLRFIDHandle handle, DLRFIDTag *Tag, char BlockGroupPtr, char *TRData);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Fujitsu_SecureReadBlockLock(DLRFIDHandle handle, DLRFIDTag *Tag, char BlockGroupPtr, char *TRData, int SecurePassword);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Fujitsu_ChgBlockGroupPassword(DLRFIDHandle handle, DLRFIDTag *Tag, char BlockGroupPtr, int NewPassword, int CurrentPassword);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Fujitsu_SecureChgBlockGroupPassword(DLRFIDHandle handle, DLRFIDTag *Tag, char BlockGroupPtr, int NewPassword, int CurrentPassword, int SecurePassword);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Fujitsu_BurstWrite(DLRFIDHandle handle, DLRFIDTag *Tag, char MemBank, short address, char nbyte, char *data, char *TRData);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Fujitsu_SecureBurstWrite(DLRFIDHandle handle, DLRFIDTag *Tag, char MemBank, short address, char nbyte, char *data, char *TRData, int SecurePassword);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Fujitsu_BurstErase(DLRFIDHandle handle, DLRFIDTag *Tag, char MemBank, short address, char nbyte, char *TRData);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_Fujitsu_SecureBurstErase(DLRFIDHandle handle, DLRFIDTag *Tag, char MemBank, short address, char nbyte, char *TRData, int SecurePassword);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_NXP_ReadProtect(DLRFIDHandle handle, DLRFIDTag *Tag);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_NXP_SecureReadProtect(DLRFIDHandle handle, DLRFIDTag *Tag, int SecurePassword);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_NXP_ResetReadProtect(DLRFIDHandle handle, DLRFIDTag *Tag, int Password);

DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_NXP_SecureResetReadProtect(DLRFIDHandle handle, DLRFIDTag *Tag, int Password, int SecurePassword);

DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_NXP_ChangeEAS(DLRFIDHandle handle, DLRFIDTag *Tag, char EAS);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_NXP_SecureChangeEAS(DLRFIDHandle handle, DLRFIDTag *Tag, char EAS, int SecurePassword);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_NXP_EAS_Alarm(DLRFIDHandle handle, char * SourceName, char *TRData);

DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_NXP_SecureEAS_Alarm(DLRFIDHandle handle, char * SourceName, char *TRData, int SecurePassword);

DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_NXP_Calibrate(DLRFIDHandle handle, DLRFIDTag *Tag);

DLRFIDlib_API deprecate_msg("Deprecated function.No longer support.") DLRFIDErrorCodes __stdcall
DLRFID_NXP_SecureCalibrate(DLRFIDHandle handle, DLRFIDTag *Tag, int SecurePassword);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_NXP_ChangeConfig(DLRFIDHandle handle, DLRFIDTag *Tag, short ConfigWord, char *TRData);

DLRFIDlib_API DLRFIDErrorCodes __stdcall
DLRFID_NXP_SecureChangeConfig(DLRFIDHandle handle, DLRFIDTag *Tag, short ConfigWord, char *TRData, int SecurePassword);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // __DLRFIDLIB_H
